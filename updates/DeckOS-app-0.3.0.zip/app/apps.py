"""The App Library + dock: finds apps Deck OS can open, in four groups.

  services  - web apps running in Docker on this machine (Jellyfin, Nextcloud...)
  computer  - desktop apps installed on the machine Deck OS runs on (from their
              .desktop files, like the Linux app menu does)
  phone     - common phone apps, opened through their app links
  links     - anything the user adds themselves

Desktop apps open ON THE MACHINE running Deck OS (your PC now, the cyberdeck
later) - so server.py only allows launching them from that machine itself.
"""
import configparser
import json
import os
import subprocess
from pathlib import Path

# Web UIs of popular self-hosted apps, for containers that don't publish their
# port to Docker (host networking). image text -> (name, port, path, icon)
KNOWN_SERVICES = {
    "home-assistant": ("Home Assistant", 8123, "/", "🏠"),
    "pihole": ("Pi-hole", 80, "/admin/", "🛡"),
    "syncthing": ("Syncthing", 8384, "/", "🔄"),
    "music-assistant": ("Music Assistant", 8095, "/", "🎵"),
    "esphome": ("ESPHome", 6052, "/", "🔌"),
    "uptime-kuma": ("Uptime Kuma", 3001, "/", "📶"),
    "jellyfin": ("Jellyfin", 8096, "/", "🎞"),
    "nextcloud": ("Nextcloud", 8080, "/", "☁️"),
    "homepage": ("Homepage", 3000, "/", "🧭"),
    "portainer": ("Portainer", 9443, "/", "🐳"),
    "code-server": ("code-server", 8443, "/", "💻"),
    "plex": ("Plex", 32400, "/web", "🎬"),
    "sonarr": ("Sonarr", 8989, "/", "📺"),
    "radarr": ("Radarr", 7878, "/", "🎥"),
    "grafana": ("Grafana", 3000, "/", "📊"),
    "node-red": ("Node-RED", 1880, "/", "🧩"),
    "frigate": ("Frigate", 5000, "/", "📹"),
    "vaultwarden": ("Vaultwarden", 80, "/", "🔐"),
    "immich": ("Immich", 2283, "/", "🖼"),
    "adguard": ("AdGuard Home", 3000, "/", "🛡"),
}
NOT_WEB = ("whisper", "piper", "openwakeword", "watchtower", "linux-voice-assistant", "mosquitto", "postgres", "redis", "mariadb")

# Phone apps that can be opened from a web page. iPhone/Android open the real app.
PHONE_APPS = [
    ("Messages", "sms:", "💬"), ("Mail", "mailto:", "✉️"),
    ("Gmail", "https://mail.google.com/mail/", "📧"), ("Outlook", "https://outlook.live.com/mail/", "📨"),
    ("Maps", "https://maps.apple.com/", "🗺"), ("Waze", "https://waze.com/ul", "🚗"),
    ("YouTube", "https://www.youtube.com/", "▶️"), ("Spotify", "https://open.spotify.com/", "🎧"),
    ("Tubi", "https://tubitv.com/", "🍿"), ("Pluto TV", "https://pluto.tv/", "📺"),
    ("Netflix", "https://www.netflix.com/", "🎬"), ("Instagram", "https://www.instagram.com/", "📸"),
    ("TikTok", "https://www.tiktok.com/", "🎵"), ("X", "https://x.com/", "𝕏"),
    ("Reddit", "https://www.reddit.com/", "👽"), ("Discord", "https://discord.com/app", "🎮"),
    ("GitHub", "https://github.com/", "🐙"), ("ChatGPT", "https://chatgpt.com/", "🤖"),
    ("Claude", "https://claude.ai/", "✳️"), ("Google", "https://www.google.com/", "🔎"),
    ("Weather", "https://weather.com/", "🌤"),
]

# The "Get apps" shelf: phone apps that go well with Deck OS. Deck OS can't install
# apps (phones don't allow it) - it sends you to the right store page, then opens
# the app for you after. needs: shown as "works with your home" when it's there.
# (name, emoji, section, why, app store id, play store package, open link, needs)
APP_STORE = [
    ("Tailscale", "🔐", "Deck OS", "Use Deck OS away from home, privately", "1470499037", "com.tailscale.ipn", None, "no-door"),
    ("Home Assistant", "🏠", "Your home", "Your home's full control panel", "1099568401", "io.homeassistant.companion.android", None, "home-assistant"),
    ("Jellyfin Mobile", "🎞", "Your home", "Your movies and shows, anywhere", "1480192618", "org.jellyfin.mobile", None, "jellyfin"),
    ("Nextcloud", "☁️", "Your home", "Your own cloud storage", "1125420102", "com.nextcloud.client", None, "nextcloud"),
    ("Roku Remote", "📺", "Your home", "Control your Roku TV from the phone", "482066631", "com.roku.remote", None, "roku"),
    ("Google Home", "🔊", "Your home", "Nest speakers, cameras and doorbells", "680819774", "com.google.android.apps.chromecast.app", None, "nest"),
    ("Aladdin Connect", "🚗", "Your home", "Open and close the Genie garage door", "1024722275", "com.geniecompany.AladdinConnect", None, None),
    ("Life360", "📍", "Family", "See where everyone is + arrival alerts", "384830320", "com.life360.android.safetymapd", "https://app.life360.com/", "life360"),
    ("Termius", "⌨️", "Tools", "Control your computer by SSH from your phone", "549039908", "com.server.auditor.ssh.client", None, None),
    ("Waze", "🚗", "Tools", "Driving directions with live traffic", "323229106", "com.waze", "https://waze.com/ul", None),
    ("Tubi", "🍿", "Watch & listen", "Free movies and TV", "886445756", "com.tubitv", "https://tubitv.com/", None),
    ("Pluto TV", "📺", "Watch & listen", "Free live TV channels", "751712884", "tv.pluto.android", "https://pluto.tv/", None),
    ("YouTube", "▶️", "Watch & listen", "Videos", "544007664", "com.google.android.youtube", "https://www.youtube.com/", None),
    ("Netflix", "🎬", "Watch & listen", "Shows and movies", "363590051", "com.netflix.mediaclient", "https://www.netflix.com/", None),
    ("Spotify", "🎧", "Watch & listen", "Music and podcasts", "324684580", "com.spotify.music", "https://open.spotify.com/", None),
    ("DoorDash", "🔴", "Food & shopping", "Works with Deck OS Food", "719972451", "com.dd.doordash", "https://www.doordash.com/", None),
    ("Uber Eats", "🟢", "Food & shopping", "Works with Deck OS Food", "1058959277", "com.ubercab.eats", "https://www.ubereats.com/", None),
    ("Grubhub", "🟠", "Food & shopping", "Works with Deck OS Food", "302920553", "com.grubhub.android", "https://www.grubhub.com/", None),
    ("Instacart", "🥕", "Food & shopping", "Works with Deck OS Lists", "545599256", "com.instacart.client", "https://www.instacart.com/", None),
    ("Amazon", "📦", "Food & shopping", "Works with Deck OS Lists", "297606951", "com.amazon.mShop.android.shopping", "https://www.amazon.com/", None),
    ("Discord", "🎮", "Tools", "Chat with friends", "985746746", "com.discord", "https://discord.com/app", None),
]


# Only these really need an app on the phone (location, the phone's own network, a TV remote...). Everything else
# with a web address is offered as a link first - no download, nothing more on your phone.
NEEDS_APP = {"Tailscale", "Home Assistant", "Roku Remote", "Google Home", "Aladdin Connect", "Life360", "Termius"}


def store_apps(platform: str, have: set[str], icons: dict[str, str]) -> list[dict]:
    """The Get apps shelf for this phone. platform: ios / android / computer.
    have: things this home has (jellyfin, roku...) so matching apps get a badge."""
    phone_names = {name for name, _, _ in PHONE_APPS}
    found = []
    for name, emoji, section, why, ios_id, android_pkg, open_url, needs in APP_STORE:
        if name in ("Jellyfin Mobile", "Nextcloud") and needs in have:
            continue  # your own server's web page is already in Apps -> Services - no app needed
        ios = f"https://apps.apple.com/us/app/id{ios_id}"
        android = f"https://play.google.com/store/apps/details?id={android_pkg}"
        store = android if platform == "android" else ios
        found.append({
            "kind": "phone", "id": f"phone:{name}" if name in phone_names else f"get:{name}",
            "name": name, "icon": emoji, "img": icons.get(ios_id), "section": section, "why": why,
            "store": store, "ios": ios, "android": android,
            # apps without a web link that opens them: their store page has an "Open" button
            "url": open_url or store,
            "web": None if name in NEEDS_APP else open_url,  # works in the browser - add it as a link instead
            "app_only": name in NEEDS_APP,
            "fits": (needs == "always" or needs in have or (needs == "no-door" and "family-door" not in have)) and name in NEEDS_APP,
        })
    return found


APP_DIRS = [Path("/usr/share/applications"), Path.home() / ".local/share/applications",
            Path("/var/lib/flatpak/exports/share/applications"), Path.home() / ".local/share/flatpak/exports/share/applications"]
ICON_DIRS = [Path("/usr/share/icons/hicolor"), Path("/usr/share/icons/Mint-Y"), Path("/usr/share/icons/Adwaita"),
             Path.home() / ".local/share/icons/hicolor", Path("/var/lib/flatpak/exports/share/icons/hicolor")]
DEV_CATEGORIES = {"Development", "IDE", "TerminalEmulator", "Debugger", "RevisionControl"}


def docker_services() -> list[dict]:
    """Web apps running in Docker here. Uses the docker command if it's available."""
    try:
        out = subprocess.run(["docker", "ps", "--format", "{{json .}}"], capture_output=True, text=True, timeout=5).stdout
    except (OSError, subprocess.TimeoutExpired):
        return []
    found = []
    for line in out.splitlines():
        c = json.loads(line)
        name, image, ports = c["Names"], c["Image"].lower(), c.get("Ports", "")
        if any(skip in name.lower() or skip in image for skip in NOT_WEB):
            continue
        known = next((v for key, v in KNOWN_SERVICES.items() if key in image or key in name.lower()), None)
        published = [p for p in ports.split(", ") if "->" in p and p.startswith("0.0.0.0")]
        if known:
            label, port, path, icon = known
            if published:  # prefer the port it's actually published on
                port = int(published[0].split("->")[0].rsplit(":", 1)[1])
        elif published:
            label, path, icon = name.replace("-", " ").title(), "/", "🧱"
            port = int(published[0].split("->")[0].rsplit(":", 1)[1])
        else:
            continue
        scheme = "https" if port in (443, 8443, 9443) else "http"
        found.append({"kind": "service", "id": f"service:{name}", "name": label, "icon": icon,
                      "scheme": scheme, "port": port, "path": path})
    return sorted(found, key=lambda a: a["name"].lower())


def desktop_apps() -> list[dict]:
    """Installed desktop apps, read from their .desktop files (what the app menu shows)."""
    apps = {}
    for folder in APP_DIRS:
        if not folder.is_dir():
            continue
        for file in folder.glob("*.desktop"):
            entry = configparser.ConfigParser(interpolation=None, strict=False)
            try:
                entry.read(file, encoding="utf-8")
                d = entry["Desktop Entry"]
            except (configparser.Error, KeyError, UnicodeDecodeError):
                continue
            if d.get("Type") != "Application" or d.get("NoDisplay", "").lower() == "true" or d.get("Hidden", "").lower() == "true":
                continue
            categories = set(filter(None, d.get("Categories", "").split(";")))
            apps[file.stem] = {
                "kind": "computer", "id": f"computer:{file.stem}", "name": d.get("Name", file.stem),
                "icon_name": d.get("Icon", ""), "developer": bool(categories & DEV_CATEGORIES),
                "category": next(iter(sorted(categories - {"GTK", "GNOME", "Qt", "KDE", "X-XFCE"})), "Other"),
            }
    return sorted(apps.values(), key=lambda a: a["name"].lower())


def phone_apps() -> list[dict]:
    return [{"kind": "phone", "id": f"phone:{name}", "name": name, "url": url, "icon": icon} for name, url, icon in PHONE_APPS]


_icon_index: dict[str, Path] | None = None


def _build_icon_index() -> dict[str, Path]:
    """Every icon picture on the system, by name - built once. Bigger PNGs and
    SVGs win, and the Mint/hicolor themes are preferred over the rest."""
    best: dict[str, tuple[int, Path]] = {}
    roots = [Path("/usr/share/icons"), Path.home() / ".local/share/icons",
             Path("/var/lib/flatpak/exports/share/icons"), Path("/usr/share/pixmaps")]
    for root in roots:
        if not root.is_dir():
            continue
        for path in root.rglob("*"):
            if path.suffix not in (".svg", ".png") or not path.is_file():
                continue
            text = str(path)
            size = 512 if path.suffix == ".svg" else next((int(n) for n in __import__("re").findall(r"/(\d{2,3})(?:x\d+)?(?:@2x)?/", text)), 32)
            if "/apps/" not in text and root.name != "pixmaps":
                size -= 400  # prefer real app icons over other icon types with the same name
            if "Mint" in text or "hicolor" in text:
                size += 50
            if path.stem not in best or size > best[path.stem][0]:
                best[path.stem] = (size, path)
    return {name: path for name, (_, path) in best.items()}


def icon_file(icon_name: str) -> Path | None:
    """Finds the picture file for a desktop app's icon."""
    global _icon_index
    if not icon_name:
        return None
    direct = Path(icon_name)
    if direct.is_absolute():
        return direct if direct.is_file() else None
    if _icon_index is None:
        _icon_index = _build_icon_index()
    return _icon_index.get(icon_name) or _icon_index.get(icon_name.lower())


def desktop_apps_supported() -> bool:
    """Linux with a desktop (a PC or the cyberdeck), installed directly - not inside
    Docker, which can't see or start the computer's apps. Windows/Mac: not yet."""
    import shutil
    import sys
    return sys.platform.startswith("linux") and shutil.which("gtk-launch") is not None and not Path("/.dockerenv").exists()


def launch_desktop_app(desktop_id: str) -> None:
    """Opens an installed app on this machine's screen, like clicking it in the menu."""
    env = {**os.environ, "DISPLAY": os.environ.get("DISPLAY", ":0")}
    subprocess.Popen(["gtk-launch", desktop_id], env=env, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, start_new_session=True)
