"""How Deck OS fits itself to whoever's Home Assistant it's plugged into.

Two layers:
  1. settings.json (optional) - anything you set here is used exactly as written.
  2. Auto-discovery - anything NOT in settings.json is found automatically from
     Home Assistant: every light, camera, scene, speaker, voice assistant, etc.

So a brand-new user with an empty settings.json gets a working screen built from
whatever they own, and it keeps up as they add devices ("upgrades with their setup").
"""
import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SETTINGS_FILE = Path(os.environ.get("DECKOS_SETTINGS") or HERE / "settings.json")  # (the Windows package keeps it in DeckOS\\data, outside app\\, so updates never touch it)

# Demo mode (DECKOS_DEMO=1) uses a made-up home and never reads or writes your real settings
DEMO = os.environ.get("DECKOS_DEMO") == "1"
DEMO_SETTINGS = {
    "alex": {"owner_name": "Alex"},
    "showcase": {"owner_name": os.environ.get("DECKOS_DEMO_NAME") or "Sam", "assistant_name": "Friday",
                 "theme": "sunset", "home_widget": "camera", "home_camera": "camera.doorbell"},
}

try:
    SETTINGS: dict = dict(DEMO_SETTINGS.get(os.environ.get("DECKOS_DEMO_HOME", "alex"), DEMO_SETTINGS["alex"])) \
        if DEMO else json.loads(SETTINGS_FILE.read_text())
except FileNotFoundError:
    SETTINGS = {}


# Settings that belong to each PERSON rather than the home: their names, pins,
# watchlist, links, cameras. Kept in data/profiles/<username>.json.
PERSONAL_KEYS = {"owner_name", "assistant_name", "dock", "app_links", "watchlist", "public_cameras", "commute",
                 "reminders", "routine_blocks", "calendar_token", "home_widget", "browser", "bookmarks", "hidden_markets", "ha_extra_markets", "ha_hidden_markets", "food_favorites", "food_meals", "food_log", "shopping_lists", "apps_installed", "theme", "notes", "status", "food_radius", "badges", "hungry_for", "about", "birthday", "badges_seen", "updates_posted", "likes", "dislikes", "quote", "effects_owned", "status_effect", "home_layout", "title", "banner", "ring", "notify_to", "notify_prefs", "tour_seen", "skip_pet", "onboarding_done", "rail", "taskbar", "presence", "meh", "dontcare", "notmuch", "chat_colors", "vibe", "potd_pin", "potd_skip", "home_cards", "topbar", "jarvis_memory", "contact", "whats_new_seen", "notify_quiet", "bd_calendar", "notify_via", "notify_sounds", "layouts", "wishes", "favs", "added_events", "whats_new_ids", "love", "hate", "allergic", "diet", "calorie_goal", "cal_log", "msg_colors", "scanners", "app_icon", "seen_challenges", "care_dismissed", "tree_order", "cal_colors", "cal_links", "easy_mode", "people_notes", "alarms", "voices", "calm_mode", "muted_chats", "ui_size", "ui_zoom", "ski_favs", "ski_custom", "teams", "activity_plans", "my_activities", "coupons", "layout_before", "rail_side", "arrange", "custom_theme", "theme_picked"}
PROFILES = Path(os.environ.get("DECKOS_DATA") or HERE / "data") / "profiles"


def _profile(username: str) -> dict:
    try:
        return json.loads((PROFILES / f"{username}.json").read_text())
    except (FileNotFoundError, ValueError):
        return {}


def setting(key: str, default=None):
    """A setting for whoever is using Deck OS right now. Personal settings come
    from their profile; the admin falls back to the home's settings.json (so
    everything set up before accounts existed carries over)."""
    import accounts
    user = accounts.current_user.get()
    if key in PERSONAL_KEYS and user:
        profile = _profile(user["username"])
        if key in profile:
            return profile[key]
        if key == "owner_name" and user["role"] != "admin":
            return user["name"].split()[0]
        return SETTINGS.get(key, default) if user["role"] == "admin" else default
    return SETTINGS.get(key, default)


def save_settings(changes: dict) -> None:
    """Personal changes go to the current person's profile; home settings go to
    settings.json and only the admin can change those."""
    import accounts
    user = accounts.current_user.get()
    personal = {k: v for k, v in changes.items() if k in PERSONAL_KEYS}
    home = {k: v for k, v in changes.items() if k not in PERSONAL_KEYS}
    if user and personal:
        PROFILES.mkdir(parents=True, exist_ok=True)
        profile = _profile(user["username"]) | personal
        path = PROFILES / f"{user['username']}.json"
        path.write_text(json.dumps(profile, indent=2))
        path.chmod(0o600)
    elif personal:
        home |= personal  # demo mode / no accounts yet
    if not home or (user and user["role"] != "admin"):
        return
    SETTINGS.update(home)
    if DEMO:
        return
    SETTINGS_FILE.write_text(json.dumps(SETTINGS, indent=2))
    try:
        SETTINGS_FILE.chmod(0o600)  # may hold a Home Assistant token - keep it private
    except OSError:
        pass


def home_assistant_login() -> tuple[str, str]:
    """Where Home Assistant is + the token to talk to it: the HA_URL / HA_TOKEN
    environment variables, or "home_assistant": {"url", "token"} in settings.json."""
    if DEMO:
        return "http://homeassistant.local:8123", "demo"
    url = os.environ.get("HA_URL") or SETTINGS.get("home_assistant", {}).get("url")
    token = os.environ.get("HA_TOKEN") or SETTINGS.get("home_assistant", {}).get("token")
    if not (url and token):
        sys.exit("Deck OS needs HA_URL and HA_TOKEN (environment variables or settings.json)")
    return url.rstrip("/"), token


def name_of(state: dict) -> str:
    return state.get("attributes", {}).get("friendly_name") or state["entity_id"].split(".", 1)[1].replace("_", " ").title()


def pick(states: dict, domain: str, setting: str, where=lambda s: True) -> dict[str, str]:
    """{entity_id: display name} - from settings.json if listed there, else every
    matching entity Home Assistant has."""
    chosen = SETTINGS.get(setting)
    if chosen:
        return {entity_id: label for entity_id, label in chosen.items() if entity_id in states}
    return {
        entity_id: name_of(s)
        for entity_id, s in sorted(states.items())
        if entity_id.startswith(domain + ".") and s["state"] != "unavailable" and where(s)
    }


def first(states: dict, setting: str, domain: str, skip: tuple = ()) -> str | None:
    """One entity: the one in settings.json, else the first of its kind found."""
    if SETTINGS.get(setting):
        return SETTINGS[setting] if SETTINGS[setting] in states else None
    for entity_id in sorted(states):
        if entity_id.startswith(domain + ".") and entity_id not in skip:
            return entity_id
    return None


def best_speaker(states: dict) -> str | None:
    """The speaker you most likely want the play/pause button for: one that's
    actually playing, then paused, then any speaker - never a TV if avoidable."""
    if SETTINGS.get("music_player"):
        return SETTINGS["music_player"] if SETTINGS["music_player"] in states else None
    players = [s for e, s in states.items() if e.startswith("media_player.") and s["state"] != "unavailable"]
    rank = {"playing": 0, "paused": 1, "idle": 2, "on": 3, "off": 4}
    players.sort(key=lambda s: (
        s["attributes"].get("device_class") == "tv",       # TVs last
        s["attributes"].get("device_class") != "speaker",  # speakers first
        rank.get(s["state"], 5),
        s["entity_id"],
    ))
    return players[0]["entity_id"] if players else None


def party_script(states: dict) -> str | None:
    if SETTINGS.get("party_script"):
        return SETTINGS["party_script"] if SETTINGS["party_script"] in states else None
    return next((e for e in sorted(states) if e.startswith("script.") and "party" in e), None)


# Home gadgets beyond lights: thermostats, locks, garage doors + blinds, robot vacuums,
# and energy (solar, home battery, EV). Energy sensors are picked by name so a
# home full of smart plugs and phone batteries doesn't flood the screen.
DEVICE_DOMAINS = ("climate", "lock", "cover", "vacuum")
ENERGY_WORDS = ("solar", "grid", "powerwall", "home_battery", "ev_", "car_", "charger")


def devices(states: dict) -> dict[str, str]:
    if SETTINGS.get("devices"):
        return {e: label for e, label in SETTINGS["devices"].items() if e in states}
    gadgets = {e: name_of(s) for e, s in sorted(states.items())
               if e.split(".")[0] in DEVICE_DOMAINS and s["state"] != "unavailable"}
    energy = [(e, name_of(s)) for e, s in sorted(states.items())
              if e.startswith("sensor.") and s["state"] not in ("unavailable", "unknown")
              and s["attributes"].get("device_class") in ("power", "battery") and any(w in e for w in ENERGY_WORDS)]
    return gadgets | dict(energy[:6])


def discover(states: dict) -> dict:
    """Everything Deck OS can show or control, for this Home Assistant, right now."""
    scene_prefix = SETTINGS.get("scene_prefix")
    return {
        "owner": setting("owner_name", ""),
        "assistant": setting("assistant_name", "Elara"),
        "lights": pick(states, "light", "lights"),
        "devices": devices(states),
        "cameras": pick(states, "camera", "cameras"),
        "scenes": {
            entity_id: (entity_id.removeprefix(scene_prefix).replace("_", " ").title() if scene_prefix and entity_id.startswith(scene_prefix) else name_of(s))
            for entity_id, s in sorted(states.items())
            if entity_id.startswith(scene_prefix or "scene.")
            or (entity_id.startswith("scene.") and str(s.get("attributes", {}).get("id", "")).startswith("deckos_"))  # ones you made in Deck OS
        },
        "markets": {k: v for k, v in pick(states, "sensor", "markets",
                                          where=lambda s: s["entity_id"].startswith("sensor.yahoofinance_")).items()
                    if k not in (setting("hidden_markets") or [])},
        # "servers": anything Home Assistant marks as a connectivity sensor
        "servers": pick(states, "binary_sensor", "servers",
                        where=lambda s: s["attributes"].get("device_class") == "connectivity"),
        "music_player": best_speaker(states),
        "party_script": party_script(states),
        "weather": first(states, "weather", "weather"),
        "voice_satellite": first(states, "voice_satellite", "assist_satellite"),
        # the smart (AI) agent if there is one, else Home Assistant's built-in one
        "voice_agent": first(states, "voice_agent", "conversation", skip=("conversation.home_assistant",))
        or "conversation.home_assistant",
        "home_camera": SETTINGS.get("home_camera"),
        "location": SETTINGS.get("location_entity") if SETTINGS.get("location_entity") in states else "zone.home",
        "phone_notify": SETTINGS.get("phone_notify"),
    }
