"""The family web: how any two people in the family are related.

Everyone is joined to the person who invited them ("Grandma is Mom's Mom"), and
memorials hang off someone the same way. From those links this works out what
anyone is to anyone else - Mom's Mom is your Grandma, your Grandma's other kid is
your Aunt or Uncle - and when it can't be sure, it says it plainly ("Kate's son").
"""
from collections import deque

# relation label -> (kind, gender)   (gender: f / m / None)
KIND = {
    "Great-grandma": ("great_grandparent", "f"), "Great-grandpa": ("great_grandparent", "m"),
    "Great-grandparent": ("great_grandparent", None),
    "Grandma": ("grandparent", "f"), "Grandpa": ("grandparent", "m"), "Grandparent": ("grandparent", None),
    "Great-aunt": ("great_pibling", "f"), "Great-uncle": ("great_pibling", "m"),
    "Mom": ("parent", "f"), "Dad": ("parent", "m"), "Parent": ("parent", None),
    "Stepmom": ("stepparent", "f"), "Stepdad": ("stepparent", "m"),
    "Aunt": ("pibling", "f"), "Uncle": ("pibling", "m"),
    "Mother-in-law": ("parent_in_law", "f"), "Father-in-law": ("parent_in_law", "m"),
    "Wife": ("partner", "f"), "Husband": ("partner", "m"), "Partner": ("partner", None),
    "Sister": ("sibling", "f"), "Brother": ("sibling", "m"), "Sibling": ("sibling", None),
    "Cousin": ("cousin", None),
    "Sister-in-law": ("sibling_in_law", "f"), "Brother-in-law": ("sibling_in_law", "m"),
    "Daughter": ("child", "f"), "Son": ("child", "m"), "Child": ("child", None),
    "Stepdaughter": ("stepchild", "f"), "Stepson": ("stepchild", "m"),
    "Daughter-in-law": ("child_in_law", "f"), "Son-in-law": ("child_in_law", "m"),
    "Niece": ("nibling", "f"), "Nephew": ("nibling", "m"),
    "Granddaughter": ("grandchild", "f"), "Grandson": ("grandchild", "m"), "Grandchild": ("grandchild", None),
    "Friend": ("friend", None), "Roommate": ("friend", None), "Other": ("other", None),
}

# how many generations above (+) or below (-) the other person
GEN = {"great_grandparent": 3, "grandparent": 2, "great_pibling": 2, "parent": 1, "stepparent": 1, "pibling": 1,
       "parent_in_law": 1, "partner": 0, "sibling": 0, "cousin": 0, "sibling_in_law": 0, "child": -1, "stepchild": -1,
       "child_in_law": -1, "nibling": -1, "grandchild": -2, "great_grandchild": -3, "great_nibling": -2,
       "friend": None, "other": None}

# if B is <kind> to A, then A is <INVERSE[kind]> to B
INVERSE = {"parent": "child", "child": "parent", "grandparent": "grandchild", "grandchild": "grandparent",
           "great_grandparent": "great_grandchild", "great_grandchild": "great_grandparent",
           "pibling": "nibling", "nibling": "pibling", "great_pibling": "great_nibling", "great_nibling": "great_pibling",
           "stepparent": "stepchild", "stepchild": "stepparent", "parent_in_law": "child_in_law", "child_in_law": "parent_in_law",
           "sibling": "sibling", "partner": "partner", "cousin": "cousin", "sibling_in_law": "sibling_in_law",
           "friend": "friend", "other": "other"}

# B is k1 to A, C is k2 to B  ->  C is COMPOSE[(k1, k2)] to A  (only the ones that are always true)
COMPOSE = {
    ("parent", "parent"): "grandparent", ("parent", "grandparent"): "great_grandparent", ("parent", "sibling"): "pibling",
    ("parent", "pibling"): "great_pibling", ("parent", "child"): "sibling", ("parent", "parent_in_law"): None,
    # (the path is always the shortest one, so "my grandparent's child" who isn't my parent is my aunt/uncle,
    #  and "my parent's partner" reads as my other parent - the everyday way families say it)
    ("grandparent", "child"): "pibling", ("parent", "partner"): "parent",
    ("grandparent", "parent"): "great_grandparent", ("grandparent", "sibling"): "great_pibling", ("grandparent", "partner"): "grandparent",
    ("sibling", "child"): "nibling", ("sibling", "sibling"): "sibling", ("sibling", "parent"): "parent",
    ("sibling", "partner"): "sibling_in_law", ("sibling", "grandchild"): "great_nibling", ("sibling", "grandparent"): "grandparent",
    ("child", "child"): "grandchild", ("child", "partner"): "child_in_law", ("child", "sibling"): "child",
    ("child", "grandchild"): "great_grandchild", ("grandchild", "child"): "great_grandchild", ("grandchild", "sibling"): "grandchild",
    ("partner", "parent"): "parent_in_law", ("partner", "sibling"): "sibling_in_law",
    ("pibling", "child"): "cousin", ("pibling", "partner"): "pibling", ("pibling", "parent"): "grandparent", ("pibling", "sibling"): "pibling",
    ("cousin", "sibling"): "cousin", ("nibling", "sibling"): "nibling", ("stepparent", "parent"): None,
    ("parent_in_law", "partner"): "parent_in_law",
}

# kind + gender -> how to say it
LABEL = {
    "great_grandparent": ("Great-grandma", "Great-grandpa", "Great-grandparent"),
    "grandparent": ("Grandma", "Grandpa", "Grandparent"), "great_pibling": ("Great-aunt", "Great-uncle", "Great-aunt/uncle"),
    "parent": ("Mom", "Dad", "Parent"), "stepparent": ("Stepmom", "Stepdad", "Stepparent"),
    "pibling": ("Aunt", "Uncle", "Aunt/uncle"), "parent_in_law": ("Mother-in-law", "Father-in-law", "Parent-in-law"),
    "partner": ("Wife", "Husband", "Partner"), "sibling": ("Sister", "Brother", "Sibling"), "cousin": ("Cousin", "Cousin", "Cousin"),
    "sibling_in_law": ("Sister-in-law", "Brother-in-law", "Sibling-in-law"),
    "child": ("Daughter", "Son", "Kid"), "stepchild": ("Stepdaughter", "Stepson", "Stepkid"),
    "child_in_law": ("Daughter-in-law", "Son-in-law", "Kid's partner"), "nibling": ("Niece", "Nephew", "Niece/nephew"),
    "grandchild": ("Granddaughter", "Grandson", "Grandkid"), "great_grandchild": ("Great-granddaughter", "Great-grandson", "Great-grandkid"),
    "great_nibling": ("Great-niece", "Great-nephew", "Great-niece/nephew"),
    "friend": ("Friend", "Friend", "Friend"), "other": ("Family", "Family", "Family"),
}


GENERIC = {"Kid", "Parent", "Sibling", "Partner", "Grandparent", "Grandkid", "Family", "Aunt/uncle", "Niece/nephew", "Cousin", "Friend"}


def label(kind: str, gender: str | None) -> str:
    f, m, n = LABEL.get(kind, ("Family", "Family", "Family"))
    return f if gender == "f" else m if gender == "m" else n


class Web:
    """nodes: {id: {"name", "to": id or None, "relation": label or None}} - "relation" is what
    this node is to "to" (the person who invited them / who they're remembered through)."""

    def __init__(self, nodes: dict[str, dict], root: str | None, ties: list | None = None):
        self.nodes, self.root = nodes, root
        self.links: dict[str, list[tuple[str, str]]] = {n: [] for n in nodes}  # id -> [(other, what other is to id)]
        for n, node in nodes.items():
            to, rel = node.get("to"), node.get("relation")
            if to in nodes and to != n and rel in KIND:
                kind = KIND[rel][0]
                self.links[to].append((n, kind))            # n is <kind> to "to"
                self.links[n].append((to, INVERSE[kind]))   # "to" is <inverse> to n
        # 💍 couples (married / engaged / partners) join people sideways too - Mom + Dad makes Dad's mom Mom's mother-in-law
        self.ties: list[tuple[str, str, str]] = []
        for a, b, status in ties or []:
            if a in nodes and b in nodes and a != b:
                self.ties.append((a, b, status))
                if status in ("married", "engaged", "partners"):
                    self.links[a].append((b, "partner"))
                    self.links[b].append((a, "partner"))

    def gender(self, n: str) -> str | None:
        rel = self.nodes.get(n, {}).get("relation")
        return KIND[rel][1] if rel in KIND else None

    def _path(self, a: str, b: str) -> list[tuple[str, str]] | None:
        """Shortest chain of links from a to b: [(next person, what they are to the one before)]."""
        if a not in self.links or b not in self.links:
            return None
        seen, queue = {a: None}, deque([a])
        while queue:
            cur = queue.popleft()
            if cur == b:
                break
            for other, kind in self.links[cur]:
                if other not in seen:
                    seen[other] = (cur, kind)
                    queue.append(other)
        if b not in seen:
            return None
        path, cur = [], b
        while seen[cur]:
            prev, kind = seen[cur]
            path.append((cur, kind))
            cur = prev
        return path[::-1]

    def relation(self, viewer: str, other: str) -> str | None:
        """What `other` is to `viewer`, as the viewer would say it ("Grandma", "Aunt", "Kate's son")."""
        if viewer == other:
            return None
        path = self._path(viewer, other)
        if not path:
            return None
        kind, known_through = path[0][1], path[0][0]
        for step, (person, step_kind) in enumerate(path[1:], 1):
            joined = COMPOSE.get((kind, step_kind))
            if joined is None:
                # can't be sure what they are to the viewer - say it through the last person we can name
                before = path[step - 1][0]
                return f"{self.nodes[before]['name'].split()[0]}'s {self._rest(path[step:]).lower()}"
            kind, known_through = joined, person
        return label(kind, self.gender(other))

    def _rest(self, path: list[tuple[str, str]]) -> str:
        """Say a chain as simply as it can be said for sure: combine steps while we know how ("mom's mom" =
        grandma), and where we don't, keep it as a chain ("grandma's uncle") rather than guess."""
        words, kind, last = [], path[0][1], path[0][0]
        for person, step_kind in path[1:]:
            joined = COMPOSE.get((kind, step_kind))
            if joined:
                kind, last = joined, person
            else:
                words.append(label(kind, self.gender(last)))
                kind, last = step_kind, person
        words.append(label(kind, self.gender(last)))
        return "'s ".join(w.lower() if i else w for i, w in enumerate(words))

    def generations(self) -> dict[str, int | None]:
        """Each person's row in the tree, counted from the root (0 = the root's generation)."""
        out: dict[str, int | None] = {n: None for n in self.nodes}
        if self.root not in self.nodes:
            return out
        out[self.root] = 0
        queue = deque([self.root])
        while queue:
            cur = queue.popleft()
            for other, kind in self.links[cur]:
                if out[other] is None and GEN.get(kind) is not None:
                    out[other] = out[cur] + GEN[kind]
                    queue.append(other)
        return out

    def _dist(self, start: str, skip: set[str]) -> dict[str, int]:
        """How many links from `start` to everyone, never walking through `skip`."""
        out, queue = {start: 0}, deque([start])
        while queue:
            cur = queue.popleft()
            for other, _ in self.links.get(cur, []):
                if other not in out and other not in skip:
                    out[other] = out[cur] + 1
                    queue.append(other)
        return out

    def sides(self, viewer: str) -> dict:
        """👩 Mom's side / 👨 Dad's side: everyone, by which of the viewer's parents they're closer to (not counting the
        viewer). Parents, siblings, partner and kids are "home" - they're both. Equal = "both" (e.g. a shared friend)."""
        if viewer not in self.links:
            return {"sides": {}, "mom": None, "dad": None}
        parents = [o for o, k in self.links[viewer] if k in ("parent", "stepparent")]
        mom = next((o for o in parents if self.gender(o) == "f"), None)
        dad = next((o for o in parents if self.gender(o) == "m"), None)
        if len(parents) == 2 and (mom is None) != (dad is None):  # one known: the other is the other one
            mom = mom or next(o for o in parents if o != dad)
            dad = dad or next(o for o in parents if o != mom)
        home = {viewer} | {o for o, k in self.links[viewer] if k in ("parent", "stepparent", "sibling", "partner", "child", "stepchild")}
        dm = self._dist(mom, {viewer}) if mom else {}
        dd = self._dist(dad, {viewer}) if dad else {}
        out = {}
        for n in self.nodes:
            if n in home:
                out[n] = "home"
            elif n in dm or n in dd:
                a, b = dm.get(n, 99), dd.get(n, 99)
                out[n] = "mom" if a < b else "dad" if b < a else "both"
        return {"sides": out, "mom": mom, "dad": dad}

    def explain(self, viewer: str, other: str) -> dict | None:
        """How `other` is related to `viewer`: the label, the "how" in words ("Mom's sister"), and the chain of people."""
        if viewer == other:
            return None
        path = self._path(viewer, other)
        if not path:
            return None
        chain = [{"name": self.nodes[viewer]["name"].split()[0], "is": None}]
        words = []
        for person, kind in path:
            said = label(kind, self.gender(person))
            chain.append({"name": self.nodes[person]["name"].split()[0], "is": said})
            if not words and said in GENERIC:  # "Kid's grandma" reads oddly - "the owner's grandma" doesn't
                words.append(self.nodes[person]["name"].split()[0])
            else:
                words.append(said if not words else said.lower())
        return {"label": self.relation(viewer, other), "how": "'s ".join(words) if len(words) > 1 else None, "chain": chain}


# ---------------------------------------------------------------- 🧩 Help fill in the tree
# Simple questions the family web can ask - one at a time, each with one-tap answers:
#   same    "Is Sam Lee the Sam on the tree?"                (a placeholder and an account are probably one person)
#   relink  "Is Sam Aunt Kate's son?"                        (a cousin with an aunt's last name...)
#   couple  "Are Mom and Dad a couple?"                        (two people who are both someone's parents)
#   parent  "Who is Dad's mom?" -> she's your Grandma          (gaps right around you)
#   sibs    "Does Mom have any brothers or sisters?"           -> they're your aunts & uncles
PARENTS = {"Mom": "f", "Dad": "m", "Parent": None}
SIBS = {"Sister", "Brother", "Sibling"}
CHILD_WORDS = {"Daughter", "Son", "Kid", "Child"}
TITLES = {"uncle", "aunt", "auntie", "grandma", "grandpa", "granny", "nana", "papa", "pop", "cousin", "great", "mr", "mrs", "ms", "dr"}


def name_words(full: str) -> list[str]:
    """"Uncle Alex" -> ["alex"] - the real name without the family title."""
    return [w for w in (full or "").lower().replace(".", "").split() if w not in TITLES]


def suggest(web: Web, viewer: str, full: dict[str, str], answered: set[str], can_edit=lambda node: False,
            limit: int = 6) -> list[dict]:
    """Questions for `viewer`, closest people first. full = {node: full name}; answered = keys never to ask again;
    can_edit(node) = may the viewer move this person in the tree."""
    if viewer not in web.nodes:
        return []
    tied = {frozenset((a, b)) for a, b, _ in web.ties}
    taken = {n for a, b, s in web.ties if s in ("married", "engaged") for n in (a, b)}
    rel = {}

    def r(a, b):  # what b is to a (cached - the tree asks a lot)
        if (a, b) not in rel:
            rel[a, b] = web.relation(a, b)
        return rel[a, b]

    def first(n):
        words = [w for w in web.nodes[n]["name"].split() if w.lower() not in TITLES]
        return (words or web.nodes[n]["name"].split() or ["?"])[0]

    def who(n):  # "you", "Mom", "Alex"
        return "you" if n == viewer else r(viewer, n) if r(viewer, n) in ("Mom", "Dad") else first(n)

    def poss(n):  # "your", "Mom's", "Alex's"
        return "your" if n == viewer else who(n) + "'s"

    def far(n):
        p = web._path(viewer, n)
        return len(p) if p is not None else 99

    def parents(n):
        return {p: r(n, p) for p in web.nodes if p != n and r(n, p) in PARENTS}

    def would_be(to, relation):  # what someone new would be to the viewer: Dad's Mom -> "Grandma"
        nodes = dict(web.nodes)
        nodes["?"] = {"name": "?", "to": to, "relation": relation}
        return Web(nodes, web.root, web.ties).relation(viewer, "?")

    out = []
    def add(key, kind, dist, **q):
        if key not in answered:
            out.append({"key": key, "kind": kind, "_d": dist, **q})

    people = [n for n in web.nodes if not n.startswith("mem:")]
    # same person twice: someone joined, and they were already on the tree as a "not on Deck OS yet" card
    for ph in (n for n in people if n.startswith("ph:")):
        pw = name_words(full.get(ph) or web.nodes[ph]["name"])
        for u in (n for n in people if not n.startswith("ph:")):
            uw = name_words(full.get(u, ""))
            if not pw or not uw or web.nodes[ph].get("to") == u or not can_edit(u):
                continue
            if pw == uw or (pw[0] == uw[0] and (len(pw) == 1 or len(uw) == 1 or pw[-1] == uw[-1])):
                spot = web.nodes[ph]
                add(f"same|{u}|{ph}", "same", 0, a=u, b=ph,
                    q=("Are you" if u == viewer else f"Is {full.get(u) or first(u)}") + f" the {web.nodes[ph]['name']} on the tree?",
                    why=f"{web.nodes[ph]['name']} is {poss(spot['to']) if spot.get('to') in web.nodes else 'the'} {(spot.get('relation') or 'family').lower()}"
                        + (" - say yes and you'll take that spot." if u == viewer else f" - say yes and {first(u)} takes that spot."))
    # a better link: Sam is your cousin, Aunt Kate has his last name - is he her son?
    for n in people:
        node = web.nodes[n]
        a, kind = node.get("to"), KIND.get(node.get("relation") or "", (None,))[0]
        last = (name_words(full.get(n) or node["name"]) or [""])[-1]
        if a not in web.nodes or not kind or len(name_words(full.get(n) or node["name"])) < 2 or not can_edit(n):
            continue
        for p in people:
            pw = name_words(full.get(p) or web.nodes[p]["name"])
            if p in (n, a) or len(pw) < 2 or pw[-1] != last or r(p, n) in CHILD_WORDS:  # (names first - they're cheap)
                continue
            kp = KIND.get(r(a, p) or "", (None,))[0]
            if kp not in (None, "parent", "partner") and COMPOSE.get((kp, "child")) == kind:
                g = web.gender(n)
                kid = label("child", g).lower()
                add(f"relink|{n}|{p}", "relink", far(n), a=n, b=p,
                    q=f"Are you {poss(p)} {kid}?" if n == viewer else f"Is {first(n)} {poss(p)} {kid}?",
                    why=(f"You're {poss(a)}" if n == viewer else f"{first(n)} is {poss(a)}") + f" {label(kind, g).lower()} and "
                        + ("have" if n == viewer else "has") + f" {poss(p)} last name.",
                    options=[x for x in (["Daughter"] if g != "m" else []) + (["Son"] if g != "f" else [])])
    # couples: both someone's parents, but not linked yet
    for kid in web.nodes:
        ps = sorted(parents(kid))
        for i, p in enumerate(ps):
            for q in ps[i + 1:]:
                if frozenset((p, q)) in tied or p in taken or q in taken:
                    continue
                gone = p.startswith("mem:") or q.startswith("mem:")
                add("couple|" + "|".join(sorted((p, q))), "couple", min(far(p), far(q)), a=p, b=q,
                    q=f"Are {who(p)} and {who(q)} a couple?", why=f"They're both {poss(kid)} parents.",
                    options=["married", "partners", "widowed" if gone else "divorced"])
                tied.add(frozenset((p, q)))
    # gaps right around you: your parents, your partner's parents, your parents' parents - and brothers & sisters
    partners = [b if a == viewer else a for a, b, s in web.ties if viewer in (a, b) and s in ("married", "engaged", "partners")]
    mine = parents(viewer)
    for n in [viewer] + sorted(mine) + partners:
        if n.startswith("mem:"):
            continue
        have = parents(n)
        if len(have) >= 2:
            pass
        else:
            genders = {PARENTS[x] for x in have.values()}
            for word, g in (("Mom", "f"), ("Dad", "m")):
                if g in genders or (None in genders and word == "Dad"):
                    continue
                said = would_be(n, word)
                # maybe they're already on the tree, just hooked up wrong ("Dad's grandma" who's really his mom)
                picks = [{"id": x, "name": web.nodes[x]["name"], "now": r(viewer, x) if x != viewer else None} for x in people
                         if x not in (n, viewer) and web.nodes[x].get("to") == n and x not in have and can_edit(x)
                         and web.gender(x) in (g, None) and (GEN.get(KIND.get(web.nodes[x].get("relation") or "", (0,))[0]) or 0) > 0
                         and KIND[web.nodes[x]["relation"]][0] != "stepparent"][:3]
                add(f"parent|{n}|{word}", "parent", far(n) + 1, to=n, relation=word, picks=picks,
                    q=f"Who is {poss(n)} {word.lower()}?" if n != viewer else f"Who is your {word.lower()}?",
                    you_call=said if n != viewer else None,
                    chain=[] if n == viewer else ["You", who(n), f"{who(n)}'s {word.lower()}"],
                    why=f"{poss(n).capitalize()} {word.lower()} is your {said.lower()}." if n != viewer and said and "'" not in said else "")
        if n in partners or n == viewer and not mine:
            continue
        if not any(r(n, x) in SIBS for x in web.nodes if x != n):
            add(f"sibs|{n}", "sibs", far(n) + 2, to=n, options=["Sister", "Brother"],
                q="Do you have any brothers or sisters?" if n == viewer else f"Does {who(n)} have any brothers or sisters?",
                why="" if n == viewer else "They'd be your aunts & uncles.", chain=[] if n == viewer else ["You", who(n), "brothers & sisters"])
    order = {"same": 0, "relink": 1, "couple": 2, "parent": 3, "sibs": 4}
    out.sort(key=lambda x: (order[x["kind"]], x["_d"]))
    for x in out:
        x.pop("_d")
    return out[:limit]
