"""📅 Change and delete iCloud calendar events (Home Assistant's CalDAV can only add them).

Turned on from Schedule → 🍎 Connect iCloud (the owner pastes an Apple app-specific password - appleid.apple.com →
Sign-In and Security → App-Specific Passwords). It's kept in ~/.config/deck-os/icloud.json, readable only by you,
and never sent back to the app. (ICLOUD_USER + ICLOUD_APP_PASSWORD in deck-os.env work too.) Talks CalDAV straight to iCloud and edits the
event's own iCalendar text. Without it, iCloud calendars stay add-only (through Home Assistant).
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import time
from datetime import datetime, timezone
from xml.etree import ElementTree as ET

import httpx

NS = {"d": "DAV:", "c": "urn:ietf:params:xml:ns:caldav", "a": "http://apple.com/ns/ical/"}
_cache: dict = {"at": 0, "cals": None}


class CalError(Exception):
    pass


LOGIN_FILE = Path.home() / ".config/deck-os/icloud.json"
BASE = "https://caldav.icloud.com"


def login() -> tuple[str, str, str] | None:
    user, pw = os.environ.get("ICLOUD_USER", "").strip(), os.environ.get("ICLOUD_APP_PASSWORD", "").strip()
    if not (user and pw):
        try:
            d = json.loads(LOGIN_FILE.read_text())
            user, pw = d.get("user", ""), d.get("password", "")
        except (OSError, ValueError):
            return None
    return (BASE, user, pw) if user and pw else None


def who() -> str | None:
    got = login()
    return got[1] if got else None


async def connect(user: str, password: str) -> int:
    """Try the login against iCloud; only saves it if iCloud says yes. Returns how many calendars it found."""
    user, password = user.strip(), re.sub(r"\s", "", password)
    if not user or not re.fullmatch(r"[a-z]{4}-?[a-z]{4}-?[a-z]{4}-?[a-z]{4}", password):
        raise CalError("That doesn't look like an app-specific password (it's 16 letters, like abcd-efgh-ijkl-mnop)")
    _cache.update(at=0, cals=None)
    found = await calendars((BASE, user, password))
    LOGIN_FILE.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(LOGIN_FILE.parent, 0o700)
    fd = os.open(LOGIN_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump({"user": user, "password": password}, f)
    return len(found)


def forget() -> None:
    LOGIN_FILE.unlink(missing_ok=True)
    _cache.update(at=0, cals=None)


def available() -> bool:
    return login() is not None


def _client(got: tuple[str, str, str] | None = None) -> tuple[httpx.AsyncClient, str]:
    got = got or login()
    if not got:
        raise CalError("iCloud isn't connected yet - Schedule → 🍎 Connect iCloud")
    url, user, pw = got
    return httpx.AsyncClient(auth=(user, pw), timeout=20, follow_redirects=True), url


async def _propfind(c: httpx.AsyncClient, url: str, body: str, depth: str = "0") -> ET.Element:
    r = await c.request("PROPFIND", url, content=body, headers={"Depth": depth, "Content-Type": "application/xml; charset=utf-8"})
    if r.status_code == 401:
        raise CalError("iCloud said no to the saved password - make a new app-specific password and connect again in Schedule")
    if r.status_code >= 400:
        raise CalError(f"iCloud said {r.status_code}")
    return ET.fromstring(r.content)


async def calendars(trying: tuple[str, str, str] | None = None) -> dict[str, dict]:
    """{display name (lowercase): {"href", "name", "color"}} - cached for 10 minutes."""
    if not trying and _cache["cals"] is not None and time.time() - _cache["at"] < 600:
        return _cache["cals"]
    c, base = _client(trying)
    async with c:
        x = await _propfind(c, base + "/", '<d:propfind xmlns:d="DAV:"><d:prop><d:current-user-principal/></d:prop></d:propfind>')
        principal = x.find(".//d:current-user-principal/d:href", NS).text
        host = str(httpx.URL(base).copy_with(path="/"))
        x = await _propfind(c, httpx.URL(host).join(principal), '<d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav"><d:prop><c:calendar-home-set/></d:prop></d:propfind>')
        home = x.find(".//c:calendar-home-set/d:href", NS).text
        home_url = httpx.URL(host).join(home)
        x = await _propfind(c, home_url, '<d:propfind xmlns:d="DAV:" xmlns:a="http://apple.com/ns/ical/"><d:prop><d:displayname/><d:resourcetype/><a:calendar-color/></d:prop></d:propfind>', "1")
        out = {}
        for resp in x.findall("d:response", NS):
            if resp.find(".//d:resourcetype/c:calendar", NS) is None:
                continue
            name = (resp.findtext(".//d:displayname", "", NS) or "").strip()
            color = (resp.findtext(".//a:calendar-color", "", NS) or "").strip()[:7]
            if name:
                out[name.lower()] = {"href": str(home_url.join(resp.findtext("d:href", "", NS))), "name": name,
                                     "color": color if re.fullmatch(r"#[0-9A-Fa-f]{6}", color) else None}
    _cache.update(at=time.time(), cals=out)
    return out


async def _find(c: httpx.AsyncClient, cal_href: str, uid: str) -> tuple[str, str, str]:
    """(event url, etag, iCalendar text) for the event with this UID."""
    body = f'''<c:calendar-query xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">
  <d:prop><d:getetag/><c:calendar-data/></d:prop>
  <c:filter><c:comp-filter name="VCALENDAR"><c:comp-filter name="VEVENT">
    <c:prop-filter name="UID"><c:text-match collation="i;octet">{uid.replace("&", "&amp;").replace("<", "&lt;")}</c:text-match></c:prop-filter>
  </c:comp-filter></c:comp-filter></c:filter></c:calendar-query>'''
    r = await c.request("REPORT", cal_href, content=body, headers={"Depth": "1", "Content-Type": "application/xml; charset=utf-8"})
    if r.status_code >= 400:
        raise CalError(f"iCloud said {r.status_code} looking for it")
    for resp in ET.fromstring(r.content).findall("d:response", NS):
        data = resp.findtext(".//c:calendar-data", "", NS)
        if data and f"UID:{uid}" in data.replace("\r\n ", ""):
            return str(httpx.URL(cal_href).join(resp.findtext("d:href", "", NS))), resp.findtext(".//d:getetag", "", NS), data
    raise CalError("Couldn't find that event in iCloud - it may have just been changed in the Calendar app")


def _esc(s: str) -> str:
    return s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def _rewrite(ics: str, ev: dict) -> str:
    """Swap the main VEVENT's summary / times / place / notes, keeping everything else (alarms, attendees, time zone)."""
    lines = ics.replace("\r\n ", "").replace("\r\n\t", "").replace("\r\n", "\n").split("\n")
    out, in_ev, depth, main_done, cur_tzid = [], False, 0, False, None
    for ln in lines:
        if ln == "BEGIN:VEVENT" and not main_done:
            in_ev, depth, cur_tzid = True, 0, None
            out.append(ln)
            continue
        if in_ev:
            if ln.startswith("BEGIN:"):
                depth += 1
            elif ln.startswith("END:") and ln != "END:VEVENT":
                depth -= 1
            elif ln == "END:VEVENT":
                if any(x.startswith("RECURRENCE-ID") for x in out[out.index("BEGIN:VEVENT"):]):
                    pass
                out += _fields(ev, cur_tzid)
                out.append(ln)
                in_ev, main_done = False, True
                continue
            if depth == 0:
                key = re.split(r"[;:]", ln, 1)[0]
                if key == "DTSTART":
                    m = re.search(r"TZID=([^;:]+)", ln)
                    cur_tzid = m.group(1) if m else None
                if key in ("SUMMARY", "DTSTART", "DTEND", "DURATION", "LOCATION", "DESCRIPTION", "LAST-MODIFIED", "DTSTAMP", "SEQUENCE"):
                    if key == "SEQUENCE":
                        ev["_seq"] = int(re.sub(r"\D", "", ln.split(":", 1)[1]) or 0) + 1
                    continue
        out.append(ln)
    return "\r\n".join(out).strip() + "\r\n"


def _fields(ev: dict, tzid: str | None) -> list[str]:
    now = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    f = [f"SUMMARY:{_esc(ev['summary'])}"]
    if ev["all_day"]:
        f += [f"DTSTART;VALUE=DATE:{ev['start']:%Y%m%d}", f"DTEND;VALUE=DATE:{ev['end']:%Y%m%d}"]
    elif tzid:  # keep their time zone (its VTIMEZONE block is still in the file)
        f += [f"DTSTART;TZID={tzid}:{ev['start']:%Y%m%dT%H%M%S}", f"DTEND;TZID={tzid}:{ev['end']:%Y%m%dT%H%M%S}"]
    else:
        f += [f"DTSTART:{ev['start'].astimezone(timezone.utc):%Y%m%dT%H%M%SZ}", f"DTEND:{ev['end'].astimezone(timezone.utc):%Y%m%dT%H%M%SZ}"]
    if ev.get("location"):
        f.append(f"LOCATION:{_esc(ev['location'])}")
    if ev.get("description"):
        f.append(f"DESCRIPTION:{_esc(ev['description'])}")
    f += [f"DTSTAMP:{now}", f"LAST-MODIFIED:{now}", f"SEQUENCE:{ev.get('_seq', 1)}"]
    return f


async def update(cal_name: str, uid: str, ev: dict) -> None:
    """ev: {summary, start: datetime (local, aware), end, all_day, location?, description?}"""
    cal = (await calendars()).get(cal_name.lower())
    if not cal:
        raise CalError(f"Couldn't find {cal_name} in iCloud")
    c, _ = _client()
    async with c:
        url, etag, ics = await _find(c, cal["href"], uid)
        if "RRULE" in ics:
            raise CalError("That's a repeating event - change the series in the Calendar app")
        r = await c.put(url, content=_rewrite(ics, dict(ev)).encode(), headers={"Content-Type": "text/calendar; charset=utf-8", **({"If-Match": etag} if etag else {})})
        if r.status_code >= 400:
            raise CalError(f"iCloud said {r.status_code} saving it")


async def delete(cal_name: str, uid: str) -> None:
    cal = (await calendars()).get(cal_name.lower())
    if not cal:
        raise CalError(f"Couldn't find {cal_name} in iCloud")
    c, _ = _client()
    async with c:
        url, etag, ics = await _find(c, cal["href"], uid)
        if "RRULE" in ics:
            raise CalError("That's a repeating event - delete it in the Calendar app")
        r = await c.delete(url, headers={"If-Match": etag} if etag else {})
        if r.status_code >= 400:
            raise CalError(f"iCloud said {r.status_code} deleting it")


async def set_color(cal_name: str, color: str) -> None:
    """Change the calendar's color in iCloud too (so it matches on the iPhone)."""
    cal = (await calendars()).get(cal_name.lower())
    if not cal:
        raise CalError(f"Couldn't find {cal_name} in iCloud")
    body = f'''<d:propertyupdate xmlns:d="DAV:" xmlns:a="http://apple.com/ns/ical/"><d:set><d:prop>
  <a:calendar-color>{color}FF</a:calendar-color></d:prop></d:set></d:propertyupdate>'''
    c, _ = _client()
    async with c:
        r = await c.request("PROPPATCH", cal["href"], content=body, headers={"Content-Type": "application/xml; charset=utf-8"})
    if r.status_code >= 400:
        raise CalError(f"iCloud said {r.status_code} changing the color")
    _cache.update(at=0, cals=None)


async def create_calendar(name: str, color: str) -> None:
    """A brand-new iCloud calendar (shows on every iPhone signed in to this Apple ID)."""
    import uuid
    cals = await calendars()
    if not cals:
        raise CalError("Couldn't find your iCloud calendars")
    any_href = next(iter(cals.values()))["href"]
    home = any_href.rstrip("/").rsplit("/", 1)[0] + "/"
    safe = name.replace("&", "&amp;").replace("<", "&lt;")
    body = f'''<?xml version="1.0" encoding="UTF-8"?>
<c:mkcalendar xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav" xmlns:a="http://apple.com/ns/ical/"><d:set><d:prop>
  <d:displayname>{safe}</d:displayname><a:calendar-color>{color.upper()}FF</a:calendar-color>
  <c:supported-calendar-component-set><c:comp name="VEVENT"/></c:supported-calendar-component-set>
</d:prop></d:set></c:mkcalendar>'''
    c, _ = _client()
    async with c:
        r = await c.request("MKCALENDAR", f"{home}{uuid.uuid4()}/", content=body, headers={"Content-Type": "application/xml; charset=utf-8"})
    if r.status_code >= 400:
        raise CalError(f"iCloud said {r.status_code} making the calendar")
    _cache.update(at=0, cals=None)
