"""The first-time setup wizard (what "Start Deck OS" shows before Deck OS is set up).

A tiny app of its own, served in the browser: a short tour of what Deck OS does, then
it finds Home Assistant on the home network, walks you through making a token (with a
button that opens the exact Home Assistant page), tests it, and saves it. The launcher
then swaps this for Deck OS itself, and the browser carries on to "create your account".
"""
import asyncio
import ipaddress
import json
import os
import socket
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

HERE = Path(__file__).resolve().parent
SETTINGS_FILE = Path(os.environ.get("DECKOS_SETTINGS") or HERE / "settings.json")
TERMS_VERSION = "2026-09-28"

app = FastAPI(title="Deck OS setup")
app.mount("/static", StaticFiles(directory=HERE / "static"), name="static")
done = asyncio.Event()  # set when setup is finished - the launcher then starts Deck OS


def load_settings() -> dict:
    try:
        return json.loads(SETTINGS_FILE.read_text())
    except (FileNotFoundError, ValueError):
        return {}


def save_settings(changes: dict) -> None:
    settings = load_settings() | changes
    SETTINGS_FILE.write_text(json.dumps(settings, indent=2))
    try:
        SETTINGS_FILE.chmod(0o600)  # it holds the Home Assistant token
    except OSError:
        pass


def tidy_url(url: str) -> str:
    url = url.strip().rstrip("/")
    if "://" not in url:
        url = "http://" + url
    host_part = url.split("://", 1)[1]
    if ":" not in host_part.split("/")[0]:  # no port typed - Home Assistant's usual one
        url += ":8123"
    return url


async def looks_like_home_assistant(client: httpx.AsyncClient, url: str) -> dict | None:
    """Home Assistant answers /api/ with 401 (no token yet) and has a manifest named "Home Assistant"."""
    try:
        api = await client.get(f"{url}/api/")
        if api.status_code not in (200, 401):
            return None
        manifest = await client.get(f"{url}/manifest.json")
        name = manifest.json().get("name", "") if manifest.status_code == 200 else ""
        if "home assistant" in name.lower() or api.status_code == 401:
            return {"url": url, "name": name or "Home Assistant"}
    except (httpx.HTTPError, ValueError):
        return None
    return None


def this_pc_network() -> ipaddress.IPv4Network | None:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(("192.0.2.1", 80))  # nothing is actually sent
            ip = probe.getsockname()[0]
        return ipaddress.ip_network(f"{ip}/24", strict=False)
    except OSError:
        return None


async def port_open(host: str, port: int = 8123) -> bool:
    try:
        _, writer = await asyncio.wait_for(asyncio.open_connection(host, port), 0.6)
        writer.close()
        return True
    except (OSError, asyncio.TimeoutError):
        return False


@app.get("/")
@app.get("/welcome")
async def welcome():
    return FileResponse(HERE / "static" / "welcome.html", headers={"Cache-Control": "no-cache"})


@app.get("/api/setup/state")
async def state():
    s = load_settings()
    return {"terms": s.get("terms_agreed") == TERMS_VERSION, "connected": bool(s.get("home_assistant", {}).get("token")),
            "setup_mode": True}


@app.post("/api/setup/terms")
async def terms():
    save_settings({"terms_agreed": TERMS_VERSION})
    return {"ok": True}


@app.get("/api/setup/find")
async def find():
    """Look for Home Assistant: its usual names first, then every address on the home network."""
    found: dict[str, dict] = {}
    async with httpx.AsyncClient(timeout=3, follow_redirects=True) as client:
        for guess in ("http://homeassistant.local:8123", "http://homeassistant:8123"):
            hit = await looks_like_home_assistant(client, guess)
            if hit:
                found[hit["url"]] = hit
        network = this_pc_network()
        if network and not found:
            hosts = [str(h) for h in network.hosts()]
            opened = await asyncio.gather(*(port_open(h) for h in hosts))
            for host, ok in zip(hosts, opened):
                if ok:
                    hit = await looks_like_home_assistant(client, f"http://{host}:8123")
                    if hit:
                        found[hit["url"]] = hit
    return {"found": list(found.values())}


@app.post("/api/setup/test")
async def test(body: dict):
    """Try the address + token; say what's wrong in plain words if it doesn't work."""
    url, token = tidy_url(str(body.get("url") or "")), str(body.get("token") or "").strip()
    if not token:
        raise HTTPException(400, "Paste the token first")
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            reply = await client.get(f"{url}/api/config", headers={"Authorization": f"Bearer {token}"})
    except httpx.HTTPError:
        raise HTTPException(400, f"Couldn't reach Home Assistant at {url}. Check the address, and that this PC is on the same Wi-Fi.")
    if reply.status_code == 401:
        raise HTTPException(400, "Home Assistant said that token isn't right. Make a new one and paste the whole thing (it's long!).")
    if reply.status_code != 200:
        raise HTTPException(400, f"Home Assistant answered with an error ({reply.status_code}). Double-check the address.")
    config = reply.json()
    return {"ok": True, "url": url, "home": config.get("location_name") or "your home", "version": config.get("version")}


@app.post("/api/setup/save")
async def save(body: dict):
    result = await test(body)
    save_settings({"home_assistant": {"url": result["url"], "token": str(body.get("token")).strip()}})
    done.set()  # the launcher now starts Deck OS itself
    return {"ok": True, "home": result["home"]}


@app.get("/terms")
async def full_terms():
    return FileResponse(HERE / "TERMS.txt", media_type="text/plain; charset=utf-8")


@app.get("/api/auth/state")
async def not_yet():
    # while setting up, Deck OS itself isn't running yet - the wizard page waits for this to answer
    return JSONResponse({"detail": "setup"}, status_code=503)
