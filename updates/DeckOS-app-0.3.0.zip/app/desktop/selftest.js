// Self-test for the desktop app (not shipped to anyone - run: DECKOS_URL=http://127.0.0.1:8797 npx electron selftest.js OUTDIR)
// Opens YouTube in the split pane and ChatGPT in a Deck OS window, checks real views line up with their slots, screenshots it all.
const { app, BrowserWindow } = require("electron");
const fs = require("fs"), path = require("path");
const OUT = process.argv[process.argv.length - 1];
app.commandLine.appendSwitch("disable-backgrounding-occluded-windows");
app.commandLine.appendSwitch("disable-renderer-backgrounding");
require("./main.js");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (...a) => console.log("[selftest]", ...a);
async function shot(wc, name) { try { const img = await wc.capturePage(); fs.writeFileSync(path.join(OUT, name), img.toPNG()); } catch (e) { log("shot failed", name, e.message); } }
function views(win) {
  return win.contentView.children.map((v) => ({ url: v.webContents.getURL(), title: v.webContents.getTitle(), b: v.getBounds(), vis: v.getVisible ? v.getVisible() : "?" , v }));
}
app.whenReady().then(async () => {
  await sleep(6000);
  const win = BrowserWindow.getAllWindows()[0];
  const js = (code) => win.webContents.executeJavaScript(code, true);
  log("deckDesktop in page:", await js("!!window.deckDesktop && desktopApp"));
  // split: YouTube
  await js(`localStorage.removeItem("deck_split"); splitOpen().then(() => splitShow("u:https://www.youtube.com/"))`);
  await sleep(9000);
  const slot = await js(`(() => { const r = document.getElementById("split-web").getBoundingClientRect(); return [r.x, r.y, r.width, r.height].map(Math.round); })()`);
  log("split slot rect:", slot, "views:", views(win).map(({ v, ...x }) => x));
  // a site opened from the Apps page (main side) -> a Deck OS window with a real view
  await js(`openOut("https://chatgpt.com/")`);
  await sleep(10000);
  log("after ChatGPT window, views:", views(win).map(({ v, ...x }) => x));
  await shot(win.webContents, "main.png");
  for (const [i, x] of views(win).entries()) await shot(x.v.webContents, `view${i}.png`);
  // resize split by moving the size, then check the view followed
  await js(`split.size = 0.3; splitSize()`); await sleep(800);
  const slot2 = await js(`(() => { const r = document.getElementById("split-web").getBoundingClientRect(); return [r.x, r.y, r.width, r.height].map(Math.round); })()`);
  log("after resize: slot", slot2, "views:", views(win).map(({ v, ...x }) => [x.url.slice(0, 30), x.b, x.vis]));
  // drag hides views
  await js(`document.body.classList.add("split-drag")`); await sleep(500);
  log("while dragging, visible:", views(win).map((x) => x.vis));
  await js(`document.body.classList.remove("split-drag")`); await sleep(500);
  // switching the pane to a Deck OS page hides the web view
  await js(`splitShow("p:notes")`); await sleep(1500);
  log("pane on Notes, views:", views(win).map(({ v, ...x }) => [x.url.slice(0, 30), x.vis]));
  // the split pane's Deck OS copy: Apps page -> tapping a site opens it in the pane
  await js(`splitShow("p:apps")`); await sleep(5000);
  await js(`document.getElementById("split-frame").contentWindow.openOut("https://www.servicetrade.com/")`); await sleep(8000);
  log("pane after an app tapped inside it:", await js(`split.what`), views(win).map(({ v, ...x }) => [x.url.slice(0, 40), x.vis, x.b]));
  await shot(win.webContents, "main2.png");
  log("done");
  app.quit();
});
