// 🖥 Deck OS desktop: Deck OS in its own window, plus REAL browser views for websites.
// A web page can't show YouTube, ChatGPT, ServiceTrade... inside itself (those sites forbid being framed), but a desktop
// app can: wherever Deck OS puts a "web slot" (the split screen pane, a pop-up window from Apps), this lays a real browser
// view exactly over it. Logins stay in this app's own profile (you sign in once per site, yourself).
// Run: npm start (or the "Deck OS" launcher). DECKOS_URL changes which Deck OS it opens (default http://localhost:8765).
const { app, BrowserWindow, WebContentsView, ipcMain, session, shell, Menu, clipboard } = require("electron");
const path = require("path");
const fs = require("fs");
const os = require("os");
const EXITFS = path.join(os.homedir(), ".cache", "deckos-exitfs");        // 🆘 touch this (Super+Shift+Esc) to force any in-window video out of fullscreen

const DECK_URL = process.env.DECKOS_URL || "http://localhost:8765";
const DECK_ORIGIN = new URL(DECK_URL).origin;
const WEB_PARTITION = "persist:web";                 // every website's cookies/logins (kept between runs)
const MIC_OK = /(^|\.)(chatgpt\.com|openai\.com|claude\.ai|meet\.google\.com|zoom\.us)$/;  // sites allowed the mic/camera
const IDLE_DROP_MS = 15 * 60 * 1000;                 // a site nobody has shown for 15 min is closed (frees memory)

app.setName("DeckOS");
if (!app.requestSingleInstanceLock()) app.quit();

let win = null;
const views = new Map();   // url -> { view, lastSeen, shown }
let order = [];            // urls in the order they're stacked right now (bottom -> top)
let fullscreenUrl = null;  // a site in HTML fullscreen (YouTube's ⛶) covers the whole window

// Sites see a normal Chrome, not "Electron" (some refuse to sign in otherwise)
const chromeUA = () => session.defaultSession.getUserAgent().replace(/\s(Electron|DeckOS|deckos)\/\S+/g, "");

function makeView(url) {
  const view = new WebContentsView({ webPreferences: { partition: WEB_PARTITION, sandbox: true, contextIsolation: true } });
  const wc = view.webContents;
  wc.setUserAgent(chromeUA());
  view.setBackgroundColor("#0b0f14");
  // pop-ups (sign in with Google/Microsoft, "open in new window") open as real windows in the same profile
  wc.setWindowOpenHandler(({ url: u }) => {
    if (!/^https?:/i.test(u)) { shell.openExternal(u); return { action: "deny" }; }
    return { action: "allow", overrideBrowserWindowOptions: { width: 900, height: 760, autoHideMenuBar: true,
      webPreferences: { partition: WEB_PARTITION, sandbox: true, contextIsolation: true } } };
  });
  wc.on("enter-html-full-screen", () => { fullscreenUrl = url; layoutFullscreen(); });
  wc.on("leave-html-full-screen", () => { fullscreenUrl = null; win.webContents.send("relayout"); });
  // keyboard: Alt+←/→ back/forward, Ctrl+R / F5 reload, Ctrl+L copies the address
  wc.on("before-input-event", (e, i) => {
    if (i.type !== "keyDown") return;
    const h = wc.navigationHistory;
    if (i.alt && i.key === "ArrowLeft" && h.canGoBack()) { h.goBack(); e.preventDefault(); }
    else if (i.alt && i.key === "ArrowRight" && h.canGoForward()) { h.goForward(); e.preventDefault(); }
    else if ((i.control && i.key.toLowerCase() === "r") || i.key === "F5") { wc.reload(); e.preventDefault(); }
    else if (i.control && i.key.toLowerCase() === "l") { clipboard.writeText(wc.getURL()); e.preventDefault(); }
    else if (i.key === "Escape" && fullscreenUrl) { wc.executeJavaScript("document.exitFullscreen && document.exitFullscreen()").catch(() => {}); e.preventDefault(); }
  });
  wc.on("context-menu", (_e, p) => {
    const h = wc.navigationHistory;
    Menu.buildFromTemplate([
      { label: "← Back", enabled: h.canGoBack(), click: () => h.goBack() },
      { label: "→ Forward", enabled: h.canGoForward(), click: () => h.goForward() },
      { label: "↻ Reload", click: () => wc.reload() },
      { type: "separator" },
      ...(p.linkURL ? [{ label: "Copy link", click: () => clipboard.writeText(p.linkURL) },
                       { label: "Open link in Chrome", click: () => shell.openExternal(p.linkURL) }] : []),
      ...(p.selectionText ? [{ role: "copy" }] : []),
      ...(p.isEditable ? [{ role: "cut" }, { role: "copy" }, { role: "paste" }, { role: "selectAll" }] : []),
      { type: "separator" },
      { label: "Open this page in Chrome", click: () => shell.openExternal(wc.getURL()) },
    ]).popup({ window: win });
  });
  wc.loadURL(url);
  return view;
}

function layoutFullscreen() {
  const v = views.get(fullscreenUrl);
  if (!v) return;
  const [w, h] = win.getContentSize();
  win.contentView.removeChildView(v.view); win.contentView.addChildView(v.view);  // on top
  v.view.setBounds({ x: 0, y: 0, width: w, height: h }); v.view.setVisible(true);
}

// The page tells us every web slot it can see: [{url, x, y, w, h}] bottom -> top, in CSS pixels.
ipcMain.on("slots", (e, slots, hide) => {
  if (!win || e.sender !== win.webContents) return;
  if (fullscreenUrl && views.has(fullscreenUrl)) return layoutFullscreen();
  const zoom = win.webContents.getZoomFactor(), now = Date.now();
  const want = hide ? [] : slots.filter((s) => /^https?:\/\//i.test(s.url) && s.w > 20 && s.h > 20).slice(0, 8);
  for (const s of want) if (!views.has(s.url)) views.set(s.url, { view: makeView(s.url), lastSeen: now, shown: false });
  const urls = want.map((s) => s.url);
  if (urls.join("\n") !== order.join("\n")) {   // restack only when the order changed (it flickers otherwise)
    for (const u of order) { const v = views.get(u); if (v) win.contentView.removeChildView(v.view); }
    for (const u of urls) win.contentView.addChildView(views.get(u).view);
    order = urls;
  }
  for (const [u, v] of views) {
    const s = want.find((x) => x.url === u);
    if (s) {
      v.view.setBounds({ x: Math.round(s.x * zoom), y: Math.round(s.y * zoom), width: Math.round(s.w * zoom), height: Math.round(s.h * zoom) });
      if (!v.shown) { v.view.setVisible(true); v.shown = true; }
      v.lastSeen = now;
    } else {
      if (v.shown) { v.view.setVisible(false); v.shown = false;
        v.view.webContents.executeJavaScript("document.querySelectorAll('video,audio').forEach(function(m){try{m.pause()}catch(e){}})").catch(function(){}); }  // 🔇 closing/hiding a pane stops its video+audio right away (not 15 min later)
      if (now - v.lastSeen > IDLE_DROP_MS) { v.view.webContents.close(); views.delete(u); }
    }
  }
});
// ← ↻ → buttons Deck OS draws for a web slot
ipcMain.on("nav", (e, url, how) => {
  const v = views.get(url);
  if (!v || e.sender !== win.webContents) return;
  const wc = v.view.webContents, h = wc.navigationHistory;
  if (how === "back" && h.canGoBack()) h.goBack();
  else if (how === "forward" && h.canGoForward()) h.goForward();
  else if (how === "reload") wc.reload();
  else if (how === "home") wc.loadURL(url);
  else if (how === "chrome") shell.openExternal(wc.getURL());
});

function createWindow() {
  win = new BrowserWindow({
    width: 1400, height: 900, title: "Deck OS", backgroundColor: "#07090c", autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true, sandbox: false },
  });
  win.loadURL(DECK_URL);
  win.setFullScreenable(false);                                 // 🎬 a video can never make the WHOLE window OS-fullscreen (title bar + minimize always stay)
  win.on("enter-full-screen", () => win.setFullScreen(false));  // belt & braces: bounce straight out of any OS fullscreen
  win.setMaximumSize(3840, 1200);                               // never grow past the screen so it can't go off the top
  // 🆘 Super+Shift+Esc (via the exit-fullscreen script) force-exits any in-window video stuck in fullscreen
  try { fs.writeFileSync(EXITFS, ""); } catch {}
  fs.watchFile(EXITFS, { interval: 300 }, () => {
    if (fullscreenUrl) { const v = views.get(fullscreenUrl); if (v) v.view.webContents.executeJavaScript("document.exitFullscreen&&document.exitFullscreen()").catch(() => {}); fullscreenUrl = null; }
    for (const [, v] of views) v.view.webContents.executeJavaScript("document.exitFullscreen&&document.exitFullscreen()").catch(() => {});
    if (win && win.webContents) { win.webContents.executeJavaScript("document.exitFullscreen&&document.exitFullscreen()").catch(() => {}); win.webContents.send("relayout"); win.show(); win.focus(); }
  });
  // Deck OS's own "Open ↗" (really leave) goes to Chrome; everything else stays inside
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: "deny" }; });
  win.webContents.on("will-navigate", (e, url) => {
    if (new URL(url).origin !== DECK_ORIGIN && !/^(tel|sms|mailto):/.test(url)) { e.preventDefault(); shell.openExternal(url); }
  });
  win.webContents.on("did-fail-load", (_e, code, desc, url, isMain) => {
    if (isMain && code !== -3) setTimeout(() => win && win.loadURL(DECK_URL), 3000);   // Deck OS restarting - try again
  });
  win.on("resize", () => win.webContents.send("relayout"));
  win.on("closed", () => { win = null; });
}

app.whenReady().then(() => {
  const ua = chromeUA();
  session.fromPartition(WEB_PARTITION).setUserAgent(ua);
  // Deck OS itself: mic (talk to Elara), camera (Sell stuff photos), notifications, clipboard
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb, d) =>
    cb(new URL(d.requestingUrl || wc.getURL()).origin === DECK_ORIGIN || ["fullscreen", "clipboard-sanitized-write"].includes(perm)));
  session.fromPartition(WEB_PARTITION).setPermissionRequestHandler((wc, perm, cb, d) => {
    let host = ""; try { host = new URL(d.requestingUrl || wc.getURL()).hostname; } catch {}
    if (["fullscreen", "clipboard-sanitized-write", "notifications", "pointerLock"].includes(perm)) return cb(true);
    if (perm === "media") return cb(MIC_OK.test(host));
    cb(false);
  });
  createWindow();
  setInterval(() => win && win.webContents.send("relayout"), 15 * 60 * 1000);   // (lets idle sites get closed)
});
app.on("second-instance", () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on("window-all-closed", () => app.quit());
