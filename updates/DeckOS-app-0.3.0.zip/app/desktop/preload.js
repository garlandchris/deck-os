// Runs inside the Deck OS page (desktop app only). Tells the app where every web slot sits on screen, so the real browser
// views line up with them - each animation frame, sent only when something moved. Views are hidden while you drag a
// window or the split edge (the page has to see the mouse), and while a Deck OS pop-up box is open (so it isn't covered).
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("deckDesktop", {
  version: 1,
  nav: (url, how) => ipcRenderer.send("nav", String(url), String(how)),
});

let last = "";
function visible(el) {
  if (!el.isConnected || !el.getClientRects().length) return false;
  for (let p = el; p; p = p.parentElement) if (p.hidden || getComputedStyle(p).visibility === "hidden") return false;
  return true;
}
// Is a Deck OS pop-up (banner, menu, Elara's chat...) lying over part of this slot? The real view would hide it, so the
// view steps aside until it's gone. Checked on a 6x6 grid; Elara's floating orb itself doesn't count (it's always there).
const covered = new WeakMap();
function isCovered(el, r) {
  let hits = 0;
  for (let i = 0; i < 6; i++) for (let j = 0; j < 6; j++) {
    const top = document.elementFromPoint(r.left + r.width * (i + 0.5) / 6, r.top + r.height * (j + 0.5) / 6);
    if (!top || top === el || el.contains(top) || (top.closest("#jfloat") && !top.closest("#jfloat-pop"))) continue;
    const w = top.closest(".app-win");
    if (w && w.querySelector("[data-webview]")) continue;   // another site's window: the real views stack in the right order themselves
    hits++;
  }
  return hits >= 2;
}
let frame = 0;
function measure() {
  const vw = innerWidth, vh = innerHeight, check = frame++ % 6 === 0;
  const slots = [...document.querySelectorAll("[data-webview]")].filter(visible).filter((el) => {
    if (check) covered.set(el, isCovered(el, el.getBoundingClientRect()));
    return !covered.get(el);
  }).map((el) => {
    const r = el.getBoundingClientRect();
    const x = Math.max(0, r.left), y = Math.max(0, r.top);
    const win = el.closest(".app-win");
    return { url: el.dataset.webview, x, y, w: Math.min(vw, r.right) - x, h: Math.min(vh, r.bottom) - y,
             z: win ? 1000 + (Number(win.style.zIndex) || 0) : 0 };
  }).sort((a, b) => a.z - b.z);
  const b = document.body;
  const hide = !b || b.classList.contains("split-drag") || !!document.querySelector(".app-win.moving")
    || !!document.querySelector('.modal:not([hidden]), [id$="-modal"]:not([hidden])') || document.hidden;
  const key = JSON.stringify([slots, hide]);
  if (key !== last) { last = key; ipcRenderer.send("slots", slots, hide); }
}
const loop = () => { try { measure(); } catch {} requestAnimationFrame(loop); };
addEventListener("DOMContentLoaded", loop);
ipcRenderer.on("relayout", () => { last = ""; });
