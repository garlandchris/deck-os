# Deck OS

Your whole home, on one simple screen — lights, cameras, the family calendar, your money, your routines — on your PC and phone,
running on **your** computer with **your** Home Assistant.

## It's yours. Change anything.
Deck OS is never finished — it's built to keep changing. Once you set it up, it's yours: your home, your money plans,
your family, your rules. Nothing you put in it leaves your computer.

Deck OS was built with **Claude Code** (Anthropic's AI coding assistant). Want something it doesn't do yet?

1. Install Claude Code (https://claude.com/claude-code).
2. Open a terminal in this Deck OS folder and run `claude`.
3. Describe what you want in plain words — *"add a page that tracks my dog's vet visits"*,
   *"make the money page warn me before a bill is due"* — and it builds it into your copy.

Tip: ask it to make a backup first ("copy server.py to server.py.bak before you change it").

## Support
Deck OS is sold as-is. The setup wizard walks you through everything; for anything beyond that, Claude Code (or any AI
coding assistant) can help you change your copy however you like.
