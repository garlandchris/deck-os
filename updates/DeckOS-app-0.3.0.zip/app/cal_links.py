"""🔗 Calendars you link by their private address: Google, Outlook, Samsung (through Google), school, sports teams...

Every big calendar can hand out a private "iCal" address (ends in .ics). Deck OS reads it every few minutes and shows
the events in the month view in that calendar's color. Reading only - Google and Outlook don't let an app change
events without a developer sign-up, so adding/changing still happens in their app (or in an iCloud/Deck OS calendar).
"""
from __future__ import annotations

import ipaddress
import re
import socket
import time
from datetime import date, datetime, timedelta, timezone
from urllib.parse import urlparse

import httpx

try:
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
except ImportError:  # pragma: no cover
    ZoneInfo = None
    ZoneInfoNotFoundError = Exception

_cache: dict[str, tuple[float, list[dict]]] = {}
DAYS = {"MO": 0, "TU": 1, "WE": 2, "TH": 3, "FR": 4, "SA": 5, "SU": 6}
# Windows time zone names some Outlook calendars use, for the common US ones
WINDOWS_TZ = {"Eastern Standard Time": "America/New_York", "Central Standard Time": "America/Chicago",
              "Mountain Standard Time": "America/Denver", "Pacific Standard Time": "America/Los_Angeles",
              "US Mountain Standard Time": "America/Phoenix", "Alaskan Standard Time": "America/Anchorage",
              "Hawaiian Standard Time": "Pacific/Honolulu", "GMT Standard Time": "Europe/London", "UTC": "UTC"}


class LinkError(Exception):
    pass


def tidy_url(url: str) -> str:
    url = url.strip()
    if url.startswith("webcal://"):
        url = "https://" + url[len("webcal://"):]
    return url


def check_url(url: str) -> str:
    """Only real internet addresses (https) - never something on the home network."""
    url = tidy_url(url)
    p = urlparse(url)
    if p.scheme != "https" or not p.hostname:
        raise LinkError("Paste the whole address - it starts with https:// (or webcal://)")
    try:
        for info in socket.getaddrinfo(p.hostname, 443):
            ip = ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
                raise LinkError("That address points inside a home network - use the calendar's internet address")
    except socket.gaierror:
        raise LinkError("Couldn't find that address - check it was copied completely")
    return url


def _unfold(text: str) -> list[str]:
    return text.replace("\r\n", "\n").replace("\n ", "").replace("\n\t", "").split("\n")


def _tz(name: str | None):
    if not name or ZoneInfo is None:
        return None
    name = WINDOWS_TZ.get(name.strip('"'), name.strip('"'))
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError, OSError):
        return None


def _when(prop: str, value: str) -> tuple[datetime | date, bool]:
    """(time, all_day) - local wall time for timed events."""
    if "VALUE=DATE" in prop and "DATE-TIME" not in prop or re.fullmatch(r"\d{8}", value):
        return datetime.strptime(value[:8], "%Y%m%d").date(), True
    m = re.search(r"TZID=([^;:]+)", prop)
    dt = datetime.strptime(value[:15], "%Y%m%dT%H%M%S")
    if value.endswith("Z"):
        dt = dt.replace(tzinfo=timezone.utc)
    elif m and _tz(m.group(1)):
        dt = dt.replace(tzinfo=_tz(m.group(1)))
    else:
        return dt, False  # floating time = local
    return dt.astimezone().replace(tzinfo=None), False


def _unesc(s: str) -> str:
    return s.replace("\\n", " ").replace("\\N", " ").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\").strip()


def parse(text: str) -> list[dict]:
    events, cur = [], None
    for ln in _unfold(text):
        if ln == "BEGIN:VEVENT":
            cur = {"exdates": set()}
        elif ln == "END:VEVENT" and cur is not None:
            if "start" in cur:
                events.append(cur)
            cur = None
        elif cur is not None and ":" in ln:
            prop, value = ln.split(":", 1)
            key = prop.split(";", 1)[0].upper()
            try:
                if key == "DTSTART":
                    cur["start"], cur["all_day"] = _when(prop, value)
                elif key == "DTEND":
                    cur["end"], _ = _when(prop, value)
                elif key == "SUMMARY":
                    cur["summary"] = _unesc(value)
                elif key == "LOCATION":
                    cur["location"] = _unesc(value)
                elif key == "UID":
                    cur["uid"] = value.strip()
                elif key == "RRULE":
                    cur["rrule"] = dict(x.split("=", 1) for x in value.split(";") if "=" in x)
                elif key == "EXDATE":
                    for v in value.split(","):
                        cur["exdates"].add(_when(prop, v)[0])
                elif key == "RECURRENCE-ID":
                    cur["recurrence_id"] = value
                elif key == "STATUS" and value.strip().upper() == "CANCELLED":
                    cur["cancelled"] = True
            except ValueError:
                pass
    return [e for e in events if not e.get("cancelled")]


def _step(d: datetime | date, freq: str, n: int) -> datetime | date:
    if freq == "DAILY":
        return d + timedelta(days=n)
    if freq == "WEEKLY":
        return d + timedelta(weeks=n)
    if freq == "MONTHLY":
        y, m = divmod(d.month - 1 + n, 12)
        try:
            return d.replace(year=d.year + y, month=m + 1)
        except ValueError:
            return None
    if freq == "YEARLY":
        try:
            return d.replace(year=d.year + n)
        except ValueError:
            return None
    return None


def expand(events: list[dict], start: datetime, end: datetime) -> list[dict]:
    """Every happening of every event between start and end (repeating ones included)."""
    out = []
    moved = {(e.get("uid"), e["start"]) for e in events if e.get("recurrence_id")}
    for e in events:
        s = e["start"]
        length = (e.get("end") or (s + timedelta(days=1) if e["all_day"] else s + timedelta(hours=1))) - s
        def keep(at):
            a = at if isinstance(at, datetime) else datetime.combine(at, datetime.min.time())
            if a + (length if isinstance(length, timedelta) else timedelta()) >= start and a < end and at not in e["exdates"]:
                out.append({"uid": e.get("uid"), "summary": e.get("summary") or "Event", "location": e.get("location") or "",
                            "all_day": e["all_day"], "start": at, "end": at + length, "rrule": bool(e.get("rrule"))})
        rule = e.get("rrule")
        if not rule or e.get("recurrence_id"):
            keep(s)
            continue
        freq, interval = rule.get("FREQ"), max(1, int(rule.get("INTERVAL", "1") or 1))
        count = int(rule["COUNT"]) if rule.get("COUNT", "").isdigit() else None
        until = None
        if rule.get("UNTIL"):
            try:
                until = _when("", rule["UNTIL"])[0]
            except ValueError:
                until = None
        days = [DAYS[d[-2:]] for d in rule.get("BYDAY", "").split(",") if d[-2:] in DAYS] if freq == "WEEKLY" else []
        made, i = 0, 0
        while i < 3000:
            base = _step(s, freq, i * interval)
            i += 1
            if base is None:
                if freq in ("MONTHLY", "YEARLY"):
                    continue
                break
            week = [base] if not days else [base + timedelta(days=(d - base.weekday()) % 7) for d in sorted(days, key=lambda d: (d - s.weekday()) % 7)]
            stop = False
            for at in week:
                if at < s:
                    continue
                cmp_at = at if isinstance(until, type(at)) else (at.date() if isinstance(at, datetime) else at)
                cmp_until = until if until is None or isinstance(until, type(cmp_at)) else (until.date() if isinstance(until, datetime) else until)
                if (cmp_until is not None and cmp_at > cmp_until) or (count is not None and made >= count):
                    stop = True
                    break
                made += 1
                if (e.get("uid"), at) not in moved:
                    keep(at)
            a = base if isinstance(base, datetime) else datetime.combine(base, datetime.min.time())
            if stop or a > end:
                break
    return out


async def fetch(url: str, fresh: bool = False) -> list[dict]:
    """The calendar's events (cached 10 minutes)."""
    hit = _cache.get(url)
    if hit and not fresh and time.time() - hit[0] < 600:
        return hit[1]
    try:
        async with httpx.AsyncClient(timeout=15, follow_redirects=True, headers={"User-Agent": "DeckOS-calendar/1.0"}) as c:
            r = await c.get(url)
    except httpx.HTTPError:
        raise LinkError("Couldn't reach that calendar right now")
    if r.status_code in (401, 403, 404):
        raise LinkError("That calendar address doesn't work anymore - it may have been reset. Copy a fresh one")
    if r.status_code >= 400 or "BEGIN:VCALENDAR" not in r.text[:2000]:
        raise LinkError("That address isn't a calendar - copy the one that ends in .ics (the 'iCal' address)")
    events = parse(r.text)
    _cache[url] = (time.time(), events)
    return events


def calendar_name(text: str) -> str | None:
    m = re.search(r"^X-WR-CALNAME:(.+)$", text.replace("\r\n", "\n"), re.M)
    return _unesc(m.group(1))[:40] if m else None
