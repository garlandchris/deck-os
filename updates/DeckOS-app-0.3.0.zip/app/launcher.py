"""Start Deck OS the easy way (what "Start Deck OS.bat" runs on Windows).

- First time: asks where Home Assistant is and for a token, checks they work,
  and saves them in settings.json.
- Every time: starts the server, opens the browser, and shows the address to
  type on your phone.
"""
import json
import os
import socket
import sys
import threading
import time
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
os.chdir(HERE)
SETTINGS_FILE = Path(os.environ.get("DECKOS_SETTINGS") or HERE / "settings.json")
PORT = int(os.environ.get("DECKOS_PORT", 8765))


def load_settings() -> dict:
    try:
        return json.loads(SETTINGS_FILE.read_text())
    except (FileNotFoundError, ValueError):
        return {}


def check_login(url: str, token: str) -> str | None:
    """None if Home Assistant answered and took the token, otherwise what went wrong."""
    import httpx
    try:
        reply = httpx.get(f"{url}/api/", headers={"Authorization": f"Bearer {token}"}, timeout=10)
    except httpx.HTTPError:
        return f"Couldn't reach Home Assistant at {url}. Check the address and that this PC is on the same network."
    if reply.status_code == 401:
        return "Home Assistant said that token is wrong. Make a new one and paste the whole thing."
    if reply.status_code != 200:
        return f"Home Assistant answered with an error ({reply.status_code}). Check the address."
    return None


TERMS_VERSION = "2026-09-28"


def agree_to_terms() -> None:
    """Once per version of the terms: show the short version, ask for a yes."""
    if load_settings().get("terms_agreed") == TERMS_VERSION:
        return
    print()
    print("  DECK OS - TERMS OF USE (full text: TERMS.txt in this folder)")
    print("   * Free for personal use at home. Deck OS Pro is paid.")
    print("   * It runs on your computer - your data stays with you.")
    print("   * It is NOT a security, alarm or life-safety system.")
    print("   * It comes as-is, with no guarantees.")
    print()
    while input("  Type YES to agree and continue: ").strip().lower() not in ("yes", "y"):
        print("  Deck OS can't start until you agree. Close this window to quit.")
    settings = load_settings()
    settings["terms_agreed"] = TERMS_VERSION
    SETTINGS_FILE.write_text(json.dumps(settings, indent=2))


def this_pc_address() -> str | None:
    """This PC's address on the home network, for opening Deck OS on a phone."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(("192.0.2.1", 80))  # nothing is actually sent
            return probe.getsockname()[0]
    except OSError:
        return None


def open_browser_when_ready(path: str = "", quiet: bool = False, open_tab: bool = True) -> None:
    for _ in range(60):
        try:
            socket.create_connection(("127.0.0.1", PORT), timeout=1).close()
            break
        except OSError:
            time.sleep(0.5)
    if open_tab:
        webbrowser.open(f"http://localhost:{PORT}{path}")
    if quiet:
        return
    print(f"  Deck OS is running:  http://localhost:{PORT}")
    address = this_pc_address()
    if address:
        print(f"  On your phone (same Wi-Fi):  http://{address}:{PORT}")
    print("\n  Keep this window open. Close it to stop Deck OS.\n")


def run_setup_wizard() -> None:
    """First time: the setup wizard in the browser (a tour, then finding Home Assistant and
    making a token). When it's done, this returns and Deck OS itself starts on the same address."""
    import asyncio
    import uvicorn
    import setup_wizard

    print()
    print("  Welcome to Deck OS! Setup opens in your browser - just follow the screens.")
    print(f"  (If it doesn't open: go to http://localhost:{PORT})")
    print()
    server = uvicorn.Server(uvicorn.Config(setup_wizard.app, host="0.0.0.0", port=PORT, log_level="warning"))

    async def finish_when_done():
        await setup_wizard.done.wait()
        await asyncio.sleep(1.5)  # let the browser hear "connected" first
        server.should_exit = True

    async def both():
        await asyncio.gather(server.serve(), finish_when_done())

    threading.Thread(target=lambda: open_browser_when_ready("/welcome", quiet=True), daemon=True).start()
    asyncio.run(both())
    print("  Connected! Starting Deck OS...\n")


def move_data_out_of_app() -> None:
    """The Windows package keeps your family's stuff in DeckOS\\data (next to app\\), so an update can swap app\\
    without touching it. If an older copy left it inside app\\, move it out once."""
    data = os.environ.get("DECKOS_DATA")
    if not data:
        return
    data = Path(data)
    data.mkdir(parents=True, exist_ok=True)
    old_data, old_settings = HERE / "data", HERE / "settings.json"
    if old_data.is_dir() and not any(data.glob("*.json")):
        for item in old_data.iterdir():
            if not (data / item.name).exists():
                item.rename(data / item.name)
    if old_settings.exists() and not SETTINGS_FILE.exists():
        old_settings.rename(SETTINGS_FILE)
    old_library = HERE / "library.json"
    if old_library.exists() and not (data / "library.json").exists():
        old_library.rename(data / "library.json")


def main() -> None:
    demo = os.environ.get("DECKOS_DEMO") == "1"
    if not demo:
        move_data_out_of_app()
    browser_open = os.environ.get("DECKOS_NO_BROWSER") == "1"  # (restarting after an update - the tab is already open)
    if not demo and not load_settings().get("home_assistant", {}).get("token"):
        run_setup_wizard()  # the terms are agreed to in the wizard too
        browser_open = True
    agree_to_terms()
    threading.Thread(target=open_browser_when_ready, kwargs={"open_tab": not browser_open}, daemon=True).start()
    import uvicorn
    import server
    uvicorn.run(server.app, host="0.0.0.0", port=PORT, log_level="warning")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
