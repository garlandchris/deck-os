// node tests/morning_pose_test.mjs - synthetic MediaPipe-style landmarks through the Morning Run pose logic (no camera needed)
import fs from "node:fs"; import vm from "node:vm"; import assert from "node:assert/strict";
vm.runInThisContext(fs.readFileSync(new URL("../static/morning-pose.js", import.meta.url), "utf8"));
const P = globalThis.MorningPose;
let T = 0; const clock = () => T;  // advanced per frame below (5 frames a second)
const pt = (x, y) => ({ x, y, visibility: 1 });
function body(o) {  // build 33 landmarks from a few named points (both sides the same unless given)
  const lm = Array.from({ length: 33 }, () => pt(0.5, 0.5));
  const set = (i, p) => { lm[i] = pt(p[0], p[1]); };
  set(0, o.nose); [11, 12].forEach((i) => set(i, o.sh)); [13, 14].forEach((i) => set(i, o.el)); [15, 16].forEach((i) => set(i, o.wr));
  [23, 24].forEach((i) => set(i, o.hip)); [25, 26].forEach((i) => set(i, o.kn)); [27, 28].forEach((i) => set(i, o.an));
  if (o.l) Object.entries(o.l).forEach(([i, p]) => set(+i, p));
  return lm;
}
const elbowAt = (deg) => { const d = 0.15 * Math.tan(((180 - deg) / 2) * Math.PI / 180); return [0.3 + d, 0.65]; };  // angle at the elbow
const pushup = (deg, sag = 0) => body({ nose: [0.22, 0.48], sh: [0.3, 0.5], el: elbowAt(deg), wr: [0.3, 0.8], hip: [0.6, 0.55 + sag], kn: [0.75, 0.58], an: [0.9, 0.61] });
let pass = 0; const ok = (name, fn) => { fn(); pass++; console.log("✓", name); };

ok("push-ups: 5 clean reps counted", () => {
  const c = P.twoState((lm) => { const a = P.ang(lm[11], lm[13], lm[15]); return a > 150 ? "A" : a < 90 ? "B" : null; }, clock);
  const f = P.formTracker("pushups"); let reps = 0;
  for (let i = 0; i < 3; i++) { c(pushup(170)); T += 200; }
  for (let r = 0; r < 5; r++) for (const deg of [70, 70, 70, 170, 170, 170]) { const lm = pushup(deg); f.frame(lm); T += 200; if (c(lm) === "rep") { reps++; f.rep(); } }
  assert.equal(reps, 5); assert.deepEqual(f.summary(), { clean: 5, of: 5, tip: "" });
});
ok("push-ups: sagging hips on reps 2-4 -> 2 of 5 clean, cue said once per 3 reps", () => {
  const c = P.COUNT.pushups(clock); const f = P.formTracker("pushups"); let reps = 0, said = [];
  for (let i = 0; i < 3; i++) { c(pushup(170)); T += 400; }
  for (let r = 0; r < 5; r++) { const sag = r >= 1 && r <= 3 ? 0.12 : 0;
    for (const deg of [70, 70, 70, 170, 170, 170]) { const lm = pushup(deg, deg < 100 ? sag : 0); /* hips sag at the bottom */ f.frame(lm); T += 400; if (c(lm) === "rep") { reps++; const s = f.rep(); if (s) said.push(s); } } }
  assert.equal(reps, 5); const s = f.summary(); assert.equal(s.clean, 2); assert.equal(s.of, 5); assert.equal(s.tip, "hips in line");
  assert.deepEqual(said, ["Hips in line"], "spoken once (reps 2-4 are within 3 reps)");
});
ok("push-ups: 88° at the bottom counts and is deep enough", () => {
  const c = P.COUNT.pushups(clock); const f = P.formTracker("pushups");
  for (let i = 0; i < 3; i++) { c(pushup(170)); T += 400; }
  for (let r = 0; r < 3; r++) for (const deg of [88, 88, 88, 170, 170, 170]) { const lm = pushup(deg); f.frame(lm); T += 400; if (c(lm) === "rep") f.rep(); }
  assert.equal(f.summary().clean, 3, "88° is past 90 - counts and is deep enough");
});
const squat = (down, kneesIn = false) => body({ nose: [0.5, 0.15], sh: [0.5, 0.25], el: [0.45, 0.33], wr: [0.5, 0.32],
  hip: down ? [0.5, 0.6] : [0.5, 0.5], kn: down ? [0.5, 0.58] : [0.5, 0.7], an: [0.5, 0.9],
  l: { 11: [0.42, 0.25], 12: [0.58, 0.25], 25: down ? [kneesIn ? 0.47 : 0.38, 0.58] : [0.44, 0.7], 26: down ? [kneesIn ? 0.53 : 0.62, 0.58] : [0.56, 0.7], 27: [0.4, 0.9], 28: [0.6, 0.9],
       23: down ? [0.44, 0.6] : [0.45, 0.5], 24: down ? [0.56, 0.6] : [0.55, 0.5] } });
ok("goblet squats: counted, knees caving flagged", () => {
  const c = P.COUNT.goblet(clock); const f = P.formTracker("goblet"); let reps = 0;
  for (let i = 0; i < 3; i++) { c(squat(0)); T += 400; }
  for (let r = 0; r < 4; r++) for (const d of [1, 1, 1, 0, 0, 0]) { const lm = squat(d, r === 3); f.frame(lm); T += 400; if (c(lm) === "rep") { reps++; f.rep(); } }
  const s = f.summary(); assert.ok(reps >= 3, "reps " + reps); assert.ok(s.clean < s.of); assert.equal(s.tip, "knees out");
});
ok("fan safety: wrist over head while standing warns; kneeling doesn't", () => {
  const standing = body({ nose: [0.5, 0.15], sh: [0.5, 0.25], el: [0.5, 0.15], wr: [0.5, 0.03], hip: [0.5, 0.5], kn: [0.5, 0.7], an: [0.5, 0.9] });
  const kneeling = body({ nose: [0.5, 0.35], sh: [0.5, 0.45], el: [0.5, 0.35], wr: [0.5, 0.22], hip: [0.5, 0.65], kn: [0.5, 0.7], an: [0.6, 0.72] });
  assert.equal(P.fanAlert(standing), true); assert.equal(P.fanAlert(kneeling), false);
});
ok("framing check needs the whole body for ~20 frames", () => {
  const fr = P.framer(20); const full = squat(0); let r = false; for (let i = 0; i < 19; i++) r = fr(full); assert.equal(r, false); assert.equal(fr(full), true);
  const cut = squat(0); cut[27] = { x: 0.4, y: 1.2, visibility: 0.2 }; assert.equal(fr(cut), false);
});
ok("debounce: a jittery double rep inside 350 ms counts once", () => {
  let t = 0; const c = P.twoState((lm) => lm.s, () => t); let reps = 0;
  for (const [s, dt] of [["A", 0], ["A", 50], ["B", 50], ["B", 50], ["A", 50], ["A", 50], ["B", 50], ["B", 50], ["A", 50], ["A", 50]]) { t += dt; if (c({ s }) === "rep") reps++; }
  assert.equal(reps, 1);
});
ok("plank: a sagging line gets the tip", () => {
  const f = P.formTracker("plank"); assert.equal(f.frame(pushup(170, 0.15)), "Straight line - squeeze your glutes"); assert.equal(f.frame(pushup(170, 0)), null);
});
ok("exercises without a form rule say so (grip / rice bucket)", () => { assert.equal(P.formTracker("rice_grab").has, false); assert.equal(P.formTracker("goblet").has, true); });
console.log(`\n${pass} passed`);
