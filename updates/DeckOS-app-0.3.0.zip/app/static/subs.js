// 🔁 Subscriptions (owner, home PC): repeat charges found in your bank history (read-only). "Still using it ✓" just
// remembers; "Cancel this ✗" only adds a to-do - Deck OS never cancels anything for you.
let subs = null;
const subsOk = () => typeof isOwnerHere === "function" && isOwnerHere() && !status.door;
const subUsd = (v) => "$" + Number(v || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const subDay = (d) => new Date(d + "T12:00").toLocaleDateString([], { month: "short", day: "numeric" });

async function loadSubsPage() {
  $("subs-body").innerHTML = '<p class="muted">Looking through your bank history…</p>';
  try { subs = await api("/api/subs"); } catch (err) { subs = { ok: false, say: err.message }; }
  drawSubs();
}

// The link on the Money page (owner only): "🔁 Subscriptions: 9 found · $310/mo →"
async function drawSubsLink() {
  const box = $("mn-subs-link"); if (!box) return;
  if (!status || status.demo || !subsOk()) { box.hidden = true; return; }
  let s; try { s = await api("/api/subs"); } catch { box.hidden = true; return; }
  box.hidden = !s.ok;
  // the bank list replaces the type-it-yourself list (kept only if you already typed some in)
  const manual = !s.ok || (typeof mn !== "undefined" && mn && mn.subs.length);
  for (const id of ["mn-subs-h", "mn-subs", "mn-sub-form"]) if ($(id)) $(id).hidden = !manual;
  if (!s.ok) return;
  const live = s.items.filter((x) => x.status !== "canceled"), fresh = live.filter((x) => x.status === "new").length;
  const alarm = s.items.some((x) => x.charged_after_cancel) ? " · ⚠️ a canceled one charged you" : "";
  box.innerHTML = `<button class="card subs-link" data-go="subs"><b>🔁 Subscriptions</b>
    <span>${live.length} found from your bank · ${subUsd(s.per_month)}/mo · ${subUsd(s.per_year)}/yr${fresh ? ` · ${fresh} to check` : ""}${alarm}</span><span class="muted">Open →</span></button>`;
}
if ($("mn-subs-link")) $("mn-subs-link").addEventListener("click", (e) => { if (e.target.closest("[data-go]")) go("subs"); });

function drawSubs() {
  const box = $("subs-body"), s = subs;
  if (!s || !s.ok) { box.innerHTML = `<p class="muted">${esc((s && s.say) || "Couldn't load this right now.")}</p>`; return; }
  const row = (x) => {
    const tag = x.status === "keep" ? '<span class="best-good">✓ still using</span>' : x.status === "cancel" ? "✗ on your to-do to cancel" : x.status === "canceled" ? esc(x.note || "You canceled this") : "";
    const warn = [x.charged_after_cancel ? `⚠️ <b>Charged ${subDay(x.last)}, after you canceled.</b> Ask them for a refund, or dispute it with the card.` : "",
      x.price_up_from ? `📈 Price went up: ${subUsd(x.price_up_from)} → ${subUsd(x.amount)}` : "",
      x.quiet ? `🤔 No charge since ${subDay(x.last)} - it was due about ${subDay(x.next)}. Maybe it's already canceled.` : ""].filter(Boolean);
    const btns = x.status === "canceled" ? "" : x.status === "new"
      ? `<button class="small-btn" data-sub-d="keep">Still using it ✓</button><button class="small-btn" data-sub-d="cancel">Cancel this ✗</button>`
      : `<button class="link-btn" data-sub-d="undo">change</button>`;
    return `<div class="card subs-item${x.status === "new" ? " subs-new" : ""}" data-key="${esc(x.key)}" data-name="${esc(x.name)}">
      <div class="subs-top"><b>${esc(x.name)}</b><b>${subUsd(x.amount)} <small class="muted">${x.cycle}</small></b></div>
      <p class="muted small">${subUsd(x.yearly)} a year · last charged ${subDay(x.last)} · seen ${x.times} times${x.cycle !== "yearly" && !x.quiet ? ` · next about ${subDay(x.next)}` : ""}</p>
      ${warn.map((w) => `<p class="small">${w}</p>`).join("")}
      <div class="quiz-row">${tag ? `<span class="small">${tag}</span>` : ""}${btns}</div></div>`;
  };
  const fresh = s.items.filter((x) => x.status === "new"), done = s.items.filter((x) => x.status === "keep" || x.status === "cancel"),
    gone = s.items.filter((x) => x.status === "canceled");
  const since = s.history_from ? new Date(s.history_from + "T12:00").toLocaleDateString([], { month: "long", day: "numeric" }) : "";
  box.innerHTML = `<div class="card"><h4>${subUsd(s.per_month)} a month · ${subUsd(s.per_year)} a year</h4>
      <p class="muted small">Charges that repeat for the same price, from your bank and cards (read only - nothing here can cancel or pay anything). Canceled ones aren't counted.</p>
      ${s.short_history ? `<p class="small">ℹ️ I only have your bank history since ${esc(since)} (${Math.round(s.history_days / 30)} months), so something billed once a year won't show up yet, and anything charged only once so far isn't listed. It gets surer every month.</p>` : ""}</div>
    ${fresh.length ? `<h3 class="cr-h">👀 Still using these? <small class="muted">${fresh.length}</small></h3>${fresh.map(row).join("")}` : ""}
    ${done.length ? `<h3 class="cr-h">✅ Decided</h3>${done.map(row).join("")}` : ""}
    ${gone.length ? `<h3 class="cr-h">🚫 You canceled - watching for sneaky charges</h3>${gone.map(row).join("")}` : ""}
    ${s.items.length ? "" : '<p class="muted">No repeating charges found in your bank history.</p>'}`;
}
if ($("subs-body")) $("subs-body").addEventListener("click", async (e) => {
  const b = e.target.closest("[data-sub-d]"); if (!b) return;
  const it = b.closest("[data-key]");
  b.disabled = true;
  try { subs = await post("/api/subs", { key: it.dataset.key, name: it.dataset.name, d: b.dataset.subD }); if (subs.say) toast(subs.say); }
  catch (err) { toast(err.message); b.disabled = false; return; }
  drawSubs();
});
