// 🎨 Creativity: say what you want to make -> the right tool opens with a head start.
// Four tools share one editor: draw + whiteboard (a canvas), flow (boxes and arrows), write (with a co-writer).
// Uses app.js's helpers ($, api, post, toast, esc, status, upload).

let crList = null;          // {mine, shared, ai, can_wall}
let cr = null;              // what's open: {id, owner, mine, mode, kind, title, shared, body}
let crDirty = false, crSaveTimer = null;
const CR_ICONS = { draw: "✏️", board: "🧑‍🏫", flow: "🔀", write: "📝" };
const CR_KIND_ICONS = { song: "🎵", rap: "🎤", poem: "✍️", story: "📖", script: "🎬", journal: "📓", other: "📝" };
const CR_MODE_NAMES = { draw: "Drawing", board: "Whiteboard", flow: "Flowchart", write: "Writing" };

async function loadCreate() {
  if (cr) return;  // keep whatever you were working on
  try { crList = await api("/api/create"); } catch (err) { return toast(err.message); }
  drawCreateHome();
}

function crCard(i) {
  const pic = i.picture ? `<img src="/api/create/${encodeURIComponent(i.owner)}/${i.id}/picture?v=${i.updated}" alt="" loading="lazy">`
    : `<p>${esc(i.preview || "")}</p>`;
  const icon = i.mode === "write" ? CR_KIND_ICONS[i.kind] || "📝" : CR_ICONS[i.mode];
  return `<button class="cr-card ${i.picture ? "pic" : ""}" data-cr-open="${esc(i.owner)}/${i.id}">
    <div class="cr-card-body">${pic}</div>
    <b>${icon} ${esc(i.title)}</b>
    <small class="muted">${i.mine ? (i.shared ? "👪 shared · " : "") : "by " + esc(i.owner_name) + " · "}${crAgo(i.updated)}</small></button>`;
}
function crAgo(t) {
  const m = Math.round((Date.now() / 1000 - t) / 60);
  return m < 1 ? "just now" : m < 60 ? `${m}m ago` : m < 1440 ? `${Math.round(m / 60)}h ago` : new Date(t * 1000).toLocaleDateString([], { month: "short", day: "numeric" });
}
function drawCreateHome() {
  $("cr-home").hidden = false; $("cr-edit").hidden = true;
  $("cr-mine").innerHTML = crList.mine.length ? crList.mine.map(crCard).join("")
    : `<p class="muted small">Nothing yet - make something! Everything saves by itself as you go.</p>`;
  $("cr-shared-h").hidden = !crList.shared.length;
  $("cr-shared").innerHTML = crList.shared.map(crCard).join("");
}

// ----- starting something -----
$("cr-go").addEventListener("click", crStartFromWords);
$("cr-ask").addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); crStartFromWords(); } });
async function crStartFromWords() {
  const text = $("cr-ask").value.trim();
  if (!text) return $("cr-ask").focus();
  $("cr-go").disabled = true; $("cr-thinking").hidden = false;
  try {
    const plan = await post("/api/create/start", { text });
    $("cr-ask").value = "";
    crOpenNew(plan.mode, plan.kind, plan);
  } catch (err) { toast(err.message); }
  finally { $("cr-go").disabled = false; $("cr-thinking").hidden = true; }
}
document.addEventListener("click", (e) => {
  const n = e.target.closest("[data-cr-new]");
  if (n) return crOpenNew(n.dataset.crNew, n.dataset.kind || null, {});
  const o = e.target.closest("[data-cr-open]");
  if (o) crOpen(...o.dataset.crOpen.split("/"));
});

function crOpenNew(mode, kind, plan) {
  const body = mode === "write" ? { text: plan.starter || "" }
    : mode === "flow" ? flowFromPlan(plan.nodes || [], plan.links || [])
    : { w: 1000, h: crCanvasHeight(), bg: mode === "board" ? "#ffffff" : "#fdfbf6", strokes: [] };
  cr = { id: null, owner: status.me ? status.me.username : "", mine: true, mode, kind: kind || (mode === "write" ? "other" : null),
         title: plan.title || "", shared: false, body };
  crShowEditor(plan);
  if (mode === "write" && plan.starter) crMarkDirty();
}
async function crOpen(owner, id) {
  try { cr = await api(`/api/create/${encodeURIComponent(owner)}/${id}`); } catch (err) { return toast(err.message); }
  crShowEditor({});
}
function crCanvasHeight() {  // paper shaped like the screen you start on (tall on a phone, wide on a tablet/PC)
  const w = Math.min($("panel-create").clientWidth || innerWidth, 1400), h = innerHeight - 190;
  return Math.round(Math.max(600, Math.min(1800, 1000 * h / Math.max(w, 300))));
}

function crShowEditor(plan) {
  $("cr-home").hidden = true; $("cr-edit").hidden = false; $("cr-menu").hidden = true;
  $("cr-title").value = cr.title || "";
  $("cr-title").placeholder = cr.mode === "write" ? `Untitled ${cr.kind && cr.kind !== "other" ? cr.kind : "piece"}` : `Untitled ${CR_MODE_NAMES[cr.mode].toLowerCase()}`;
  $("cr-title").readOnly = !cr.mine;
  $("cr-share").hidden = !cr.mine;
  $("cr-share").classList.toggle("on", !!cr.shared);
  $("cr-saved").textContent = cr.mine ? (cr.id ? "saved" : "") : "";
  $("cr-readonly").hidden = cr.mine;
  $("cr-readonly").textContent = cr.mine ? "" : `👀 ${cr.owner_name} shared this - ⋯ → Make a copy to work on your own version.`;
  document.querySelectorAll('#cr-menu [data-cr-act]').forEach((b) => {
    const a = b.dataset.crAct;
    b.hidden = (a === "delete" && !cr.mine) || (a === "wall" && (cr.mode === "write" || !crList || !crList.can_wall))
      || (a === "chat" && (!cr.mine || (status.blocked || []).includes("chat") || status.relative));
  });
  const ideas = plan.ideas || [];
  $("cr-ideas").hidden = !ideas.length && !(plan.starter && cr.mode !== "write");
  $("cr-ideas").innerHTML = (plan.starter && cr.mode !== "write" ? `<p>💡 ${esc(plan.starter)}</p>` : "")
    + (ideas.length ? `<b>Try this:</b><ul>${ideas.map((i) => `<li>${esc(i)}</li>`).join("")}</ul>` : "") + `<button class="link-btn" data-cr-ideas-x>hide</button>`;
  $("cr-canvas-wrap").hidden = !["draw", "board"].includes(cr.mode);
  $("cr-flow-wrap").hidden = cr.mode !== "flow";
  $("cr-write-wrap").hidden = cr.mode !== "write";
  if (cr.mode === "draw" || cr.mode === "board") canvasOpen();
  if (cr.mode === "flow") flowOpen();
  if (cr.mode === "write") writeOpen();
}
$("cr-ideas").addEventListener("click", (e) => { if (e.target.closest("[data-cr-ideas-x]")) $("cr-ideas").hidden = true; });

$("cr-back").addEventListener("click", async () => {
  if (crDirty) await crSave();
  cr = null; crDirty = false;
  crList = null; loadCreate();
});
$("cr-title").addEventListener("input", () => { cr.title = $("cr-title").value; crMarkDirty(); });
$("cr-share").addEventListener("click", async () => {
  cr.shared = !cr.shared;
  $("cr-share").classList.toggle("on", cr.shared);
  toast(cr.shared ? "👪 The family can see this now (they can't change it)" : "🔒 Just yours again");
  crMarkDirty(0);
});
$("cr-more-btn").addEventListener("click", () => { $("cr-menu").hidden = !$("cr-menu").hidden; });

// ----- saving (by itself, a moment after you stop) -----
function crMarkDirty(wait = 1500) {
  if (!cr || !cr.mine) return;
  crDirty = true;
  $("cr-saved").textContent = "…";
  clearTimeout(crSaveTimer);
  crSaveTimer = setTimeout(crSave, wait);
}
async function crSave() {
  clearTimeout(crSaveTimer);
  if (!cr || !cr.mine || !crDirty) return;
  crDirty = false;
  const payload = { id: cr.id, mode: cr.mode, kind: cr.kind, title: cr.title, shared: cr.shared, body: cr.body };
  try {
    if (cr.mode === "write") payload.preview = (cr.body.text || "").replace(/\[[^\]]*\]/g, "").trim().slice(0, 160);
    else payload.picture = await crPicture(500);
    if (cr.pendingBase) payload.base = cr.pendingBase;
    const saved = await post("/api/create/save", payload);
    if (cr) {
      cr.id = saved.id;
      if (payload.base && cr.pendingBase === payload.base) {  // the scan now lives on the server - same picture, keep showing it
        cr.pendingBase = null; cr.base = true;
        if (crBaseCache.key === "pending:" + payload.base.length) crBaseCache.key = `/api/create/${encodeURIComponent(cr.owner)}/${cr.id}/base`;
      }
      $("cr-saved").textContent = "saved ✓";
    }
  } catch (err) { crDirty = true; $("cr-saved").textContent = "not saved"; toast(err.message); }
}
addEventListener("pagehide", () => { if (crDirty) crSave(); });
document.addEventListener("visibilitychange", () => { if (document.hidden && crDirty) crSave(); });

// a picture of what's open: PNG data URL at most `maxW` wide (the gallery's thumbnail, the wall, downloads)
async function crPicture(maxW) {
  if (cr.mode === "flow") return flowPicture(maxW);
  const b = cr.body, scale = Math.min(1, maxW / b.w);
  const c = document.createElement("canvas");
  c.width = Math.round(b.w * scale); c.height = Math.round(b.h * scale);
  const g = c.getContext("2d");
  g.fillStyle = b.bg; g.fillRect(0, 0, c.width, c.height);
  const base = await crBaseImage();
  if (base) g.drawImage(base, 0, 0, c.width, c.height);
  const layer = document.createElement("canvas");
  layer.width = c.width; layer.height = c.height;
  paintStrokes(layer.getContext("2d"), b.strokes, scale);
  g.drawImage(layer, 0, 0);
  return c.toDataURL("image/png");
}

// ----- ⋯ menu -----
$("cr-menu").addEventListener("click", async (e) => {
  const act = e.target.closest("[data-cr-act]") && e.target.closest("[data-cr-act]").dataset.crAct;
  if (!act) return;
  $("cr-menu").hidden = true;
  try {
    if (act === "delete") {
      if (!e.target.dataset.sure) { e.target.dataset.sure = "1"; e.target.textContent = "🗑 Tap again to delete"; $("cr-menu").hidden = false; return; }
      if (cr.id) await post("/api/create/delete", { id: cr.id });
      cr = null; crDirty = false; crList = null; toast("Deleted"); return loadCreate();
    }
    if (act === "copy") {
      const baseCopy = cr.base || cr.pendingBase ? cr.pendingBase || await crImageData(await crBaseImage(), 0.9) : null;
      cr = { ...cr, id: null, owner: status.me ? status.me.username : "", mine: true, shared: false, base: false, pendingBase: baseCopy,
             title: (cr.title || "Untitled") + (cr.mine ? " (copy)" : ""), body: JSON.parse(JSON.stringify(cr.body)) };
      crShowEditor({}); crMarkDirty(0); return toast("📄 Your own copy - change anything");
    }
    if (act === "download") {
      const a = document.createElement("a");
      const name = (cr.title || "creation").replace(/[^\w\- ]+/g, "").trim() || "creation";
      if (cr.mode === "write") a.href = URL.createObjectURL(new Blob([(cr.title ? cr.title + "\n\n" : "") + cr.body.text], { type: "text/plain" })), a.download = name + ".txt";
      else a.href = await crPicture(2000), a.download = name + ".png";
      a.click(); return;
    }
    if (act === "chat") {
      const text = cr.mode === "write" ? `${CR_KIND_ICONS[cr.kind] || "📝"} ${cr.title || "Something I wrote"}\n\n${cr.body.text}`.slice(0, 1900)
        : `🎨 I made a ${CR_MODE_NAMES[cr.mode].toLowerCase()}: "${cr.title || "Untitled"}" - it's in More → Creativity`;
      if (cr.mode !== "write" && !cr.shared) { cr.shared = true; $("cr-share").classList.add("on"); crDirty = true; }
      await crSave();
      await post("/api/chat", { text }); return toast("💬 Sent to the family chat");
    }
    if (act === "wall") {
      const big = await crJpeg(1600), thumb = await crJpeg(420);
      const form = new FormData();
      form.append("photo", big.blob, "photo.jpg"); form.append("thumb", thumb.blob, "thumb.jpg");
      form.append("caption", cr.title || ""); form.append("w", big.w); form.append("h", big.h); form.append("announce", "1");
      await upload("/api/wall", form); toast("📸 On the photo wall!");
    }
  } catch (err) { toast(err.message); }
});
async function crJpeg(maxW) {
  const img = new Image();
  img.src = await crPicture(maxW);
  await img.decode();
  const c = document.createElement("canvas");
  c.width = img.width; c.height = img.height;
  const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0);
  const blob = await new Promise((r) => c.toBlob(r, "image/jpeg", 0.88));
  return { blob, w: c.width, h: c.height };
}

// =========================================================================
// ✏️ Draw + 🧑‍🏫 Whiteboard: strokes kept as shapes (so undo, resizing and saving are exact)
// =========================================================================
const CR_COLORS_LIGHT = ["#111111", "#e53935", "#fb8c00", "#fdd835", "#43a047", "#1e88e5", "#8e24aa", "#6d4c41", "#ffffff"];
const CR_BGS = ["#ffffff", "#fdfbf6", "#1e1e24", "#10263b"];
let tool = "pen", penColor = "#111111", penSize = 4, redo = [], drawing = null, crScale = 1;
let penSeen = false, crBaseCache = { key: null, img: null };  // once a pen/stylus draws, fingers stop drawing (palm rejection)
// the scanned paper drawing under this one (if it has one)
async function crBaseImage() {
  if (!cr) return null;
  const key = cr.pendingBase ? "pending:" + cr.pendingBase.length : cr.base && cr.id ? `/api/create/${encodeURIComponent(cr.owner)}/${cr.id}/base` : null;
  if (!key) return null;
  if (crBaseCache.key === key) return crBaseCache.img;
  const img = new Image();
  img.src = cr.pendingBase || key;
  try { await img.decode(); } catch { return null; }
  crBaseCache = { key, img };
  return img;
}
async function crImageData(img, quality) {
  if (!img) return null;
  const c = document.createElement("canvas");
  c.width = img.naturalWidth; c.height = img.naturalHeight;
  c.getContext("2d").drawImage(img, 0, 0);
  return c.toDataURL("image/jpeg", quality);
}
$("cr-colors").innerHTML = CR_COLORS_LIGHT.map((c) => `<button class="cr-dot" data-color="${c}" style="background:${c}" aria-label="color ${c}"></button>`).join("");

function canvasOpen() {
  redo = [];
  const dark = ["#1e1e24", "#10263b"].includes(cr.body.bg);
  penColor = dark ? "#ffffff" : "#111111";
  $("cr-color").value = penColor;
  crPickTool(cr.mode === "board" ? "pen" : "pen");
  $("cr-tools").classList.toggle("readonly", !cr.mine);
  requestAnimationFrame(canvasSize);
}
function canvasSize() {
  if (!cr || !["draw", "board"].includes(cr.mode)) return;
  const stage = $("cr-stage"), c = $("cr-canvas"), dpr = devicePixelRatio || 1;
  const w = stage.clientWidth;
  crScale = w / cr.body.w;
  c.style.width = w + "px"; c.style.height = Math.round(cr.body.h * crScale) + "px";
  c.width = Math.round(w * dpr); c.height = Math.round(cr.body.h * crScale * dpr);
  c.style.background = cr.body.bg;
  canvasPaint();
  crBaseImage().then((img) => { if (img) canvasPaint(); });
}
addEventListener("resize", () => { if (cr && ["draw", "board"].includes(cr.mode)) canvasSize(); });
const crLayer = document.createElement("canvas");  // your strokes, on their own layer so the eraser never rubs out the scan
function crBaseNow() {  // the scan underneath, if it's loaded and belongs to what's open
  const key = cr && (cr.pendingBase ? "pending:" + cr.pendingBase.length : cr.base && cr.id ? `/api/create/${encodeURIComponent(cr.owner)}/${cr.id}/base` : null);
  if (!key) return null;
  if (crBaseCache.key === key) return crBaseCache.img;
  crBaseImage().then((img) => { if (img) canvasPaint(); });  // not loaded yet - paint again once it is
  return null;
}
function canvasPaint() {
  const c = $("cr-canvas"), g = c.getContext("2d");
  g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, c.width, c.height);
  const s = crScale * (devicePixelRatio || 1), base = crBaseNow();
  const strokes = drawing ? [...cr.body.strokes, drawing] : cr.body.strokes;
  if (!base) return paintStrokes(g, strokes, s);
  g.drawImage(base, 0, 0, c.width, c.height);
  if (crLayer.width !== c.width || crLayer.height !== c.height) { crLayer.width = c.width; crLayer.height = c.height; }
  const lg = crLayer.getContext("2d");
  lg.setTransform(1, 0, 0, 1, 0, 0); lg.clearRect(0, 0, c.width, c.height);
  paintStrokes(lg, strokes, s);
  g.drawImage(crLayer, 0, 0);
}
function paintStrokes(g, strokes, s) {
  for (const k of strokes) {
    g.save();
    g.lineCap = "round"; g.lineJoin = "round";
    g.strokeStyle = g.fillStyle = k.c;
    g.lineWidth = k.w * s;
    g.globalAlpha = k.t === "marker" ? 0.35 : 1;
    g.globalCompositeOperation = k.t === "eraser" ? "destination-out" : "source-over";
    const p = k.pts.map(([x, y]) => [x * s, y * s]);
    p.forEach((q, i) => (p[i] = [q[0], q[1]]));
    if (k.t === "text") {
      g.font = `600 ${Math.round(k.w * 5 * s + 10 * s)}px system-ui, sans-serif`;
      g.textBaseline = "top";
      g.fillText(k.text, p[0][0], p[0][1]);
    } else if (k.t === "line" && p.length > 1) {
      g.beginPath(); g.moveTo(...p[0]); g.lineTo(...p[p.length - 1]); g.stroke();
    } else if (k.t === "box" && p.length > 1) {
      const [a, b] = [p[0], p[p.length - 1]];
      g.strokeRect(Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.abs(b[0] - a[0]), Math.abs(b[1] - a[1]));
    } else if (k.t === "circle" && p.length > 1) {
      const [a, b] = [p[0], p[p.length - 1]];
      g.beginPath();
      g.ellipse((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, Math.abs(b[0] - a[0]) / 2 || 1, Math.abs(b[1] - a[1]) / 2 || 1, 0, 0, Math.PI * 2);
      g.stroke();
    } else if (k.pr && p.length > 1) {  // drawn with a pen: each little piece as thick as you pressed
      for (let i = 1; i < p.length; i++) {
        g.lineWidth = k.w * s * crPressure((k.pts[i - 1][2] + k.pts[i][2]) / 2);
        g.beginPath(); g.moveTo(p[i - 1][0], p[i - 1][1]); g.lineTo(p[i][0], p[i][1]); g.stroke();
      }
    } else {  // pen, marker, eraser: a smooth curve through the points
      g.beginPath(); g.moveTo(...p[0].slice(0, 2));
      if (p.length === 1) g.lineTo(p[0][0] + 0.1, p[0][1]);
      for (let i = 1; i < p.length - 1; i++) g.quadraticCurveTo(p[i][0], p[i][1], (p[i][0] + p[i + 1][0]) / 2, (p[i][1] + p[i + 1][1]) / 2);
      if (p.length > 1) g.lineTo(...p[p.length - 1]);
      g.stroke();
    }
    g.restore();
  }
}
const crPressure = (pr) => 0.2 + 1.6 * Math.max(0, Math.min(1, pr ?? 0.5));  // light touch = thin, hard = thick
function crPickTool(t) {
  tool = t;
  document.querySelectorAll("#cr-tools [data-tool]").forEach((b) => b.classList.toggle("on", b.dataset.tool === t));
}
$("cr-tools").addEventListener("click", (e) => {
  const t = e.target.closest("[data-tool]");
  if (t) return crPickTool(t.dataset.tool);
  const d = e.target.closest("[data-color]");
  if (d) { penColor = d.dataset.color; $("cr-color").value = penColor; if (tool === "eraser") crPickTool("pen"); }
});
$("cr-color").addEventListener("input", () => { penColor = $("cr-color").value; if (tool === "eraser") crPickTool("pen"); });
$("cr-size").addEventListener("input", () => { penSize = +$("cr-size").value; });
$("cr-undo").addEventListener("click", () => { if (cr.body.strokes.length) { redo.push(cr.body.strokes.pop()); canvasPaint(); crMarkDirty(); } });
$("cr-redo").addEventListener("click", () => { if (redo.length) { cr.body.strokes.push(redo.pop()); canvasPaint(); crMarkDirty(); } });
$("cr-bg").addEventListener("click", () => {
  cr.body.bg = CR_BGS[(CR_BGS.indexOf(cr.body.bg) + 1) % CR_BGS.length];
  $("cr-canvas").style.background = cr.body.bg; crMarkDirty();
});
$("cr-clear").addEventListener("click", (e) => {
  const b = e.currentTarget;
  if (!cr.body.strokes.length) return;
  if (!b.dataset.sure) { b.dataset.sure = "1"; b.textContent = "Sure?"; setTimeout(() => { delete b.dataset.sure; b.textContent = "🧹"; }, 2500); return; }
  redo = [...cr.body.strokes].reverse(); cr.body.strokes = []; canvasPaint(); crMarkDirty();
  delete b.dataset.sure; b.textContent = "🧹"; toast("Cleared - ↷ brings it back");
});
function crPoint(e) {
  const r = $("cr-canvas").getBoundingClientRect();
  const pt = [Math.round((e.clientX - r.left) / crScale * 10) / 10, Math.round((e.clientY - r.top) / crScale * 10) / 10];
  if (e.pointerType === "pen") pt.push(Math.round((e.pressure || 0.5) * 100) / 100);
  return pt;
}
const canvasEl = $("cr-canvas");
canvasEl.addEventListener("pointerdown", (e) => {
  if (!cr || !cr.mine || (e.pointerType === "mouse" && e.button !== 0)) return;
  if (e.pointerType === "pen" && !penSeen) { penSeen = true; toast("✍️ Pen mode - press harder for thicker lines. Fingers won't draw now."); }
  if (e.pointerType === "touch" && penSeen) return;  // your hand resting on the screen
  if (e.pointerType === "touch" && drawing) { drawing = null; canvasPaint(); return; }  // a second finger = not drawing
  if ($("cr-text-in").hidden === false) return crTextCommit();
  const pt = crPoint(e);
  if (tool === "text") return crTextStart(pt, e);
  e.preventDefault();
  try { canvasEl.setPointerCapture(e.pointerId); } catch {}
  const w = tool === "eraser" ? penSize * 4 : tool === "marker" ? penSize * 3 : penSize;
  drawing = { t: tool, c: penColor, w, pts: [pt], ...(e.pointerType === "pen" && ["pen", "marker", "eraser"].includes(tool) ? { pr: 1 } : {}) };
  canvasPaint();
});
canvasEl.addEventListener("pointermove", (e) => {
  if (!drawing) return;
  const coalesced = e.getCoalescedEvents ? e.getCoalescedEvents() : [];
  const pts = coalesced.length ? coalesced.map(crPoint) : [crPoint(e)];
  if (["line", "box", "circle"].includes(drawing.t)) drawing.pts = [drawing.pts[0], pts[pts.length - 1]];
  else drawing.pts.push(...pts);
  canvasPaint();
});
const crPenUp = () => {
  if (!drawing) return;
  cr.body.strokes.push(drawing); drawing = null; redo = [];
  canvasPaint(); crMarkDirty();
};
canvasEl.addEventListener("pointerup", crPenUp);
canvasEl.addEventListener("pointercancel", crPenUp);
function crTextStart(pt) {
  const inp = $("cr-text-in");
  inp.value = ""; inp.hidden = false; inp.dataset.x = pt[0]; inp.dataset.y = pt[1];
  inp.style.left = pt[0] * crScale + "px"; inp.style.top = pt[1] * crScale + "px"; inp.style.color = penColor;
  setTimeout(() => inp.focus(), 30);
}
function crTextCommit() {
  const inp = $("cr-text-in");
  if (inp.hidden) return;
  inp.hidden = true;
  const text = inp.value.trim();
  if (!text) return;
  cr.body.strokes.push({ t: "text", c: penColor, w: penSize, pts: [[+inp.dataset.x, +inp.dataset.y]], text });
  redo = []; canvasPaint(); crMarkDirty();
}
$("cr-text-in").addEventListener("keydown", (e) => { if (e.key === "Enter") crTextCommit(); if (e.key === "Escape") $("cr-text-in").hidden = true; });
$("cr-text-in").addEventListener("blur", crTextCommit);

// =========================================================================
// 🔀 Flowchart: boxes, questions and start/end ovals joined by arrows
// =========================================================================
const FLOW_COLORS = ["#e8eaf6", "#fff3cd", "#d4edda", "#f8d7da", "#d1ecf1", "#ead7f5"];
let flowSel = null, flowLinkSel = null, flowConnecting = false, flowDrag = null, flowUndo = [];
const FW = 150, FH = 64;  // a box's size

function flowFromPlan(nodes, links) {
  const body = { nodes: [], links: [] };
  if (!nodes.length) {
    body.nodes = [{ id: "n1", x: 300, y: 60, label: "Start", shape: "oval", color: FLOW_COLORS[2] }];
    return body;
  }
  // lay them out in rows by how many steps from the first one
  const depth = nodes.map(() => -1); depth[0] = 0;
  const queue = [0];
  while (queue.length) {
    const i = queue.shift();
    links.filter((l) => l.from === i).forEach((l) => { if (depth[l.to] < 0) { depth[l.to] = depth[i] + 1; queue.push(l.to); } });
  }
  let extra = Math.max(0, ...depth) + 1;
  depth.forEach((d, i) => { if (d < 0) depth[i] = extra++; });
  const rows = {};
  nodes.forEach((n, i) => {
    const row = rows[depth[i]] = rows[depth[i]] || [];
    row.push(i);
  });
  nodes.forEach((n, i) => {
    const row = rows[depth[i]], col = row.indexOf(i);
    body.nodes.push({ id: "n" + (i + 1), label: n.label, shape: n.shape,
      x: Math.round(350 + (col - (row.length - 1) / 2) * (FW + 50)), y: 50 + depth[i] * (FH + 60),
      color: n.shape === "diamond" ? FLOW_COLORS[1] : n.shape === "oval" ? FLOW_COLORS[2] : FLOW_COLORS[0] });
  });
  body.links = links.map((l) => ({ from: "n" + (l.from + 1), to: "n" + (l.to + 1), label: l.label || "" }));
  return body;
}
function flowOpen() {
  flowSel = flowLinkSel = null; flowConnecting = false; flowUndo = [];
  document.querySelector("#cr-flow-wrap .cr-tools").classList.toggle("readonly", !cr.mine);
  $("fl-ai").hidden = !(crList && crList.ai);
  flowDraw();
}
function flowSnap() { flowUndo.push(JSON.stringify(cr.body)); if (flowUndo.length > 60) flowUndo.shift(); }
function flowChanged() { flowDraw(); crMarkDirty(); }
function flowSize() {
  const xs = cr.body.nodes.map((n) => n.x + FW), ys = cr.body.nodes.map((n) => n.y + FH);
  return [Math.max(800, ...xs) + 120, Math.max(600, ...ys) + 160];
}
function flowWrap(label) {  // up to 3 short lines
  const words = String(label).split(/\s+/), lines = [""];
  for (const w of words) {
    if ((lines[lines.length - 1] + " " + w).trim().length > 18 && lines[lines.length - 1]) lines.push(w);
    else lines[lines.length - 1] = (lines[lines.length - 1] + " " + w).trim();
  }
  return lines.slice(0, 3);
}
function flowEdge(a, b) {  // where the arrow from a's middle toward b's middle leaves a's outline
  const [ax, ay, bx, by] = [a.x + FW / 2, a.y + FH / 2, b.x + FW / 2, b.y + FH / 2];
  const dx = bx - ax, dy = by - ay;
  if (!dx && !dy) return [ax, ay];
  const hw = FW / 2 + 4, hh = FH / 2 + 4;
  let t = Math.min(dx ? hw / Math.abs(dx) : Infinity, dy ? hh / Math.abs(dy) : Infinity);
  if (a.shape === "diamond") t = 1 / (Math.abs(dx) / hw + Math.abs(dy) / hh);
  if (a.shape === "oval") t = 1 / Math.sqrt((dx / hw) ** 2 + (dy / hh) ** 2);
  return [ax + dx * t, ay + dy * t];
}
function flowShape(n, sel) {
  const stroke = sel ? "#7c4dff" : "#555", sw = sel ? 3 : 1.5, cx = n.x + FW / 2, cy = n.y + FH / 2;
  const shape = n.shape === "diamond" ? `<polygon points="${cx},${n.y - 8} ${n.x + FW + 10},${cy} ${cx},${n.y + FH + 8} ${n.x - 10},${cy}" fill="${n.color}" stroke="${stroke}" stroke-width="${sw}"/>`
    : n.shape === "oval" ? `<ellipse cx="${cx}" cy="${cy}" rx="${FW / 2}" ry="${FH / 2}" fill="${n.color}" stroke="${stroke}" stroke-width="${sw}"/>`
    : `<rect x="${n.x}" y="${n.y}" width="${FW}" height="${FH}" rx="10" fill="${n.color}" stroke="${stroke}" stroke-width="${sw}"/>`;
  const lines = flowWrap(n.label);
  const text = lines.map((l, i) => `<tspan x="${cx}" y="${cy + (i - (lines.length - 1) / 2) * 17}">${esc(l)}</tspan>`).join("");
  return `<g data-node="${n.id}" class="fl-node">${shape}<text text-anchor="middle" dominant-baseline="middle" font-size="14" font-family="system-ui, sans-serif" fill="#1a1a1a">${text}</text></g>`;
}
function flowSvg(forPicture = false) {
  const [w, h] = flowSize();
  const byId = Object.fromEntries(cr.body.nodes.map((n) => [n.id, n]));
  const links = cr.body.links.map((l, i) => {
    const a = byId[l.from], b = byId[l.to];
    if (!a || !b) return "";
    const [x1, y1] = flowEdge(a, b), [x2, y2] = flowEdge(b, a), sel = !forPicture && flowLinkSel === i;
    return `<g data-link="${i}" class="fl-link"><line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="transparent" stroke-width="18"/>
      <line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${sel ? "#7c4dff" : "#444"}" stroke-width="${sel ? 3 : 2}" marker-end="url(#fl-arrow)"/>
      ${l.label ? `<text x="${(x1 + x2) / 2}" y="${(y1 + y2) / 2 - 6}" text-anchor="middle" font-size="13" font-family="system-ui, sans-serif" fill="#333" paint-order="stroke" stroke="#fff" stroke-width="4">${esc(l.label)}</text>` : ""}</g>`;
  }).join("");
  const nodes = cr.body.nodes.map((n) => flowShape(n, !forPicture && flowSel === n.id)).join("");
  return { w, h, inner: `<defs><marker id="fl-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#444"/></marker></defs>
    <rect width="${w}" height="${h}" fill="#fbfbfd"/>${links}${nodes}` };
}
function flowDraw() {
  const { w, h, inner } = flowSvg();
  const svg = $("fl-svg");
  svg.setAttribute("width", w); svg.setAttribute("height", h); svg.setAttribute("viewBox", `0 0 ${w} ${h}`);
  svg.innerHTML = inner;
  $("fl-hint").textContent = !cr.mine ? "" : flowConnecting ? "🔗 Now tap the box the arrow should point to (tap empty space to cancel)."
    : flowSel ? "Drag it, or: 🔗 Connect · ✏️ Text · 🎨 Color · 🗑" : flowLinkSel !== null ? "Arrow picked: ✏️ gives it a label (like yes/no), 🗑 removes it."
    : "Drag boxes around. Tap one, then 🔗 Connect and tap another to draw an arrow.";
  ["fl-connect", "fl-color"].forEach((id) => ($(id).disabled = !flowSel));
  $("fl-edit").disabled = $("fl-del").disabled = !flowSel && flowLinkSel === null;
  $("fl-connect").classList.toggle("on", flowConnecting);
}
async function flowPicture(maxW) {
  const { w, h, inner } = flowSvg(true);
  const img = new Image();
  img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${inner}</svg>`);
  await img.decode();
  const scale = Math.min(1, maxW / w), c = document.createElement("canvas");
  c.width = Math.round(w * scale); c.height = Math.round(h * scale);
  c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
  return c.toDataURL("image/png");
}
function flowPt(e) {
  const r = $("fl-svg").getBoundingClientRect(), [w] = flowSize();
  const s = w / r.width;
  return [(e.clientX - r.left) * s, (e.clientY - r.top) * s];
}
$("fl-svg").addEventListener("pointerdown", (e) => {
  if (!cr || !cr.mine) return;
  if (!$("fl-text-in").hidden) flowTextCommit();
  const g = e.target.closest("[data-node]"), l = e.target.closest("[data-link]");
  if (flowConnecting) {
    if (g && g.dataset.node !== flowSel && !cr.body.links.some((k) => k.from === flowSel && k.to === g.dataset.node)) {
      flowSnap(); cr.body.links.push({ from: flowSel, to: g.dataset.node, label: "" });
      flowSel = g.dataset.node; flowConnecting = false; return flowChanged();
    }
    flowConnecting = false; return flowDraw();
  }
  if (g) {
    const n = cr.body.nodes.find((k) => k.id === g.dataset.node), [px, py] = flowPt(e);
    flowSel = n.id; flowLinkSel = null;
    flowDrag = { n, dx: px - n.x, dy: py - n.y, moved: false, before: JSON.stringify(cr.body) };
    try { $("fl-svg").setPointerCapture(e.pointerId); } catch {}
    e.preventDefault();
  } else if (l) { flowLinkSel = +l.dataset.link; flowSel = null; }
  else { flowSel = null; flowLinkSel = null; }
  flowDraw();
});
$("fl-svg").addEventListener("pointermove", (e) => {
  if (!flowDrag) return;
  const [px, py] = flowPt(e);
  const x = Math.max(12, Math.round((px - flowDrag.dx) / 10) * 10), y = Math.max(12, Math.round((py - flowDrag.dy) / 10) * 10);
  if (x !== flowDrag.n.x || y !== flowDrag.n.y) { flowDrag.n.x = x; flowDrag.n.y = y; flowDrag.moved = true; flowDraw(); }
});
const flowUp = () => {
  if (flowDrag && flowDrag.moved) { flowUndo.push(flowDrag.before); crMarkDirty(); }
  flowDrag = null;
};
$("fl-svg").addEventListener("pointerup", flowUp);
$("fl-svg").addEventListener("pointercancel", flowUp);
$("fl-svg").addEventListener("dblclick", (e) => { if (e.target.closest("[data-node]")) flowTextStart(); });
document.querySelectorAll("[data-flow-add]").forEach((b) => b.addEventListener("click", () => {
  flowSnap();
  const shape = b.dataset.flowAdd, near = cr.body.nodes.find((n) => n.id === flowSel);
  const id = "n" + (Math.max(0, ...cr.body.nodes.map((n) => +n.id.slice(1) || 0)) + 1);
  const stage = $("fl-stage");
  const [x, y] = near ? [near.x, near.y + FH + 60] : [Math.round((stage.scrollLeft + 40) / 10) * 10, Math.round((stage.scrollTop + 40) / 10) * 10];
  cr.body.nodes.push({ id, x, y, shape, label: shape === "diamond" ? "Question?" : shape === "oval" ? "End" : "Step",
                       color: shape === "diamond" ? FLOW_COLORS[1] : shape === "oval" ? FLOW_COLORS[2] : FLOW_COLORS[0] });
  if (near) cr.body.links.push({ from: near.id, to: id, label: "" });
  flowSel = id; flowLinkSel = null; flowChanged();
  flowTextStart();
}));
$("fl-connect").addEventListener("click", () => { if (flowSel) { flowConnecting = !flowConnecting; flowDraw(); } });
$("fl-color").addEventListener("click", () => {
  const n = cr.body.nodes.find((k) => k.id === flowSel);
  if (!n) return;
  flowSnap(); n.color = FLOW_COLORS[(FLOW_COLORS.indexOf(n.color) + 1) % FLOW_COLORS.length]; flowChanged();
});
$("fl-del").addEventListener("click", () => {
  flowSnap();
  if (flowSel) {
    cr.body.nodes = cr.body.nodes.filter((n) => n.id !== flowSel);
    cr.body.links = cr.body.links.filter((l) => l.from !== flowSel && l.to !== flowSel);
    flowSel = null;
  } else if (flowLinkSel !== null) { cr.body.links.splice(flowLinkSel, 1); flowLinkSel = null; }
  flowChanged();
});
$("fl-undo").addEventListener("click", () => {
  if (!flowUndo.length) return;
  cr.body = JSON.parse(flowUndo.pop()); flowSel = flowLinkSel = null; flowChanged();
});
$("fl-edit").addEventListener("click", flowTextStart);
function flowTextStart() {
  const inp = $("fl-text-in"), r = $("fl-svg").getBoundingClientRect(), s = r.width / flowSize()[0];
  const n = cr.body.nodes.find((k) => k.id === flowSel), l = flowLinkSel !== null ? cr.body.links[flowLinkSel] : null;
  if (!n && !l) return;
  const byId = Object.fromEntries(cr.body.nodes.map((k) => [k.id, k]));
  const [x, y] = n ? [n.x, n.y + FH / 2 - 16] : [(byId[l.from].x + byId[l.to].x) / 2, (byId[l.from].y + byId[l.to].y) / 2 + FH / 2 - 16];
  inp.value = n ? n.label : l.label; inp.hidden = false;
  inp.style.left = x * s + "px"; inp.style.top = y * s + "px"; inp.style.width = FW * s + "px";
  setTimeout(() => { inp.focus(); inp.select(); }, 30);
}
function flowTextCommit() {
  const inp = $("fl-text-in");
  if (inp.hidden) return;
  inp.hidden = true;
  const n = cr.body.nodes.find((k) => k.id === flowSel), l = flowLinkSel !== null ? cr.body.links[flowLinkSel] : null;
  const v = inp.value.trim().slice(0, 60);
  if (n && v && v !== n.label) { flowSnap(); n.label = v; flowChanged(); }
  else if (l && v !== l.label) { flowSnap(); l.label = v.slice(0, 20); flowChanged(); }
}
$("fl-text-in").addEventListener("keydown", (e) => { if (e.key === "Enter") flowTextCommit(); if (e.key === "Escape") $("fl-text-in").hidden = true; });
$("fl-text-in").addEventListener("blur", flowTextCommit);
$("fl-ai").addEventListener("click", async () => {
  const words = $("cr-title").value.trim() || "";
  const ask = words ? `a flowchart of: ${words}` : "";
  if (!ask) { toast("Give it a title first (like 'my morning routine') - it builds from that"); return $("cr-title").focus(); }
  $("fl-ai").disabled = true; $("fl-ai").textContent = "✨ thinking…";
  try {
    const plan = await post("/api/create/start", { text: ask + " (a flowchart)" });
    if (!plan.nodes || !plan.nodes.length) return toast("Couldn't come up with one - try a clearer title");
    flowSnap(); cr.body = flowFromPlan(plan.nodes, plan.links); flowSel = null; flowChanged();
    toast("✨ Built it - drag, edit or ↶ to undo");
  } catch (err) { toast(err.message); }
  finally { $("fl-ai").disabled = false; $("fl-ai").textContent = "✨ Build from words"; }
});

// =========================================================================
// 📝 Writing desk + 🤝 co-writer
// =========================================================================
const HELP_SETS = {
  song: [["continue", "✍️ Keep going"], ["verse", "➕ New verse"], ["chorus", "🔁 Chorus"], ["bridge", "🌉 Bridge"], ["rhymes", "🎯 Rhymes"], ["chords", "🎸 Chords"], ["titles", "🏷 Titles"], ["better", "💪 Make it better"]],
  rap: [["continue", "✍️ Keep going"], ["verse", "➕ New verse"], ["chorus", "🔁 Hook"], ["rhymes", "🎯 Rhymes"], ["titles", "🏷 Titles"], ["better", "💪 Make it better"]],
  poem: [["continue", "✍️ Keep going"], ["rhymes", "🎯 Rhymes"], ["titles", "🏷 Titles"], ["better", "💪 Make it better"]],
  other: [["continue", "✍️ Keep going"], ["titles", "🏷 Titles"], ["better", "💪 Make it better"]],
};
let helpBusy = false;
function writeOpen() {
  $("cr-kind").value = cr.kind || "other";
  $("cr-text").value = cr.body.text || "";
  $("cr-text").readOnly = !cr.mine; $("cr-kind").disabled = !cr.mine;
  document.querySelector(".cr-helper").hidden = !cr.mine || !(crList && crList.ai);
  document.querySelector(".cr-write").classList.toggle("solo", document.querySelector(".cr-helper").hidden);
  $("cr-help-out").hidden = true;
  writeHelpButtons(); writeCount();
}
function writeHelpButtons() {
  $("cr-help-btns").innerHTML = (HELP_SETS[cr.kind] || HELP_SETS.other).map(([k, n]) => `<button data-help="${k}">${n}</button>`).join("");
}
function writeCount() {
  const t = $("cr-text").value, words = (t.match(/\S+/g) || []).length, lines = t.split("\n").filter((l) => l.trim() && !/^\[.*\]$/.test(l.trim())).length;
  $("cr-count").textContent = `${words} words · ${lines} lines`;
}
$("cr-kind").addEventListener("change", () => { cr.kind = $("cr-kind").value; writeHelpButtons(); crMarkDirty(); });
$("cr-text").addEventListener("input", () => { cr.body.text = $("cr-text").value; writeCount(); crMarkDirty(); });
$("cr-help-btns").addEventListener("click", (e) => {
  const b = e.target.closest("[data-help]");
  if (!b) return;
  if (b.dataset.help === "rhymes") {
    const sel = $("cr-text").value.slice($("cr-text").selectionStart, $("cr-text").selectionEnd).trim();
    const word = sel || $("cr-help-ask").value.trim();
    if (!word) { toast("Type a word in the box (or highlight one) to rhyme with"); return $("cr-help-ask").focus(); }
    return writeHelp("rhymes", word);
  }
  writeHelp(b.dataset.help, $("cr-help-ask").value.trim());
});
$("cr-help-go").addEventListener("click", () => writeHelp("ask", $("cr-help-ask").value.trim()));
$("cr-help-ask").addEventListener("keydown", (e) => { if (e.key === "Enter") writeHelp("ask", $("cr-help-ask").value.trim()); });
async function writeHelp(help, ask) {
  if (helpBusy) return;
  if (help === "ask" && !ask) return $("cr-help-ask").focus();
  helpBusy = true;
  $("cr-help-out").hidden = false; $("cr-help-text").textContent = "thinking…";
  try {
    const r = await post("/api/create/help", { help, ask, kind: cr.kind, title: cr.title, text: $("cr-text").value });
    $("cr-help-text").textContent = r.text;
    if (help === "ask" || help === "rhymes") $("cr-help-ask").value = "";
  } catch (err) { $("cr-help-out").hidden = true; toast(err.message); }
  finally { helpBusy = false; }
}
$("cr-help-add").addEventListener("click", () => {
  const t = $("cr-text"), add = $("cr-help-text").textContent.trim();
  t.value = t.value.replace(/\s*$/, "") + (t.value.trim() ? "\n\n" : "") + add + "\n";
  cr.body.text = t.value; writeCount(); crMarkDirty(); $("cr-help-out").hidden = true;
  t.scrollTop = t.scrollHeight;
});
$("cr-help-cursor").addEventListener("click", () => {
  const t = $("cr-text"), add = $("cr-help-text").textContent.trim(), at = t.selectionStart ?? t.value.length;
  t.value = t.value.slice(0, at) + add + t.value.slice(t.selectionEnd ?? at);
  cr.body.text = t.value; writeCount(); crMarkDirty(); $("cr-help-out").hidden = true;
});
$("cr-help-close").addEventListener("click", () => { $("cr-help-out").hidden = true; });


// =========================================================================
// 📸 Scan a paper drawing: find the paper, straighten it, clean it up like a scanner - then draw on top
// =========================================================================
let scanImg = null, scanCorners = null, scanLook = "bw", scanRot = 0, scanDrag = null, scanTarget = "new", scanFit = 1;
document.addEventListener("click", (e) => {
  const b = e.target.closest("[data-cr-scan]");
  if (!b) return;
  scanTarget = b.dataset.crScan === "here" ? "here" : "new";
  $("cr-scan-file").value = "";
  $("cr-scan-file").click();
});
$("cr-scan-file").addEventListener("change", async () => {
  const file = $("cr-scan-file").files[0];
  if (!file) return;
  const img = new Image();
  img.src = URL.createObjectURL(file);
  try { await img.decode(); } catch { return toast("That photo didn't open - try another"); }
  // work on a copy no bigger than 2400px (phones take huge photos)
  const k = Math.min(1, 2400 / Math.max(img.naturalWidth, img.naturalHeight));
  const c = document.createElement("canvas");
  c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
  c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
  URL.revokeObjectURL(img.src);
  scanImg = c; scanRot = 0;
  scanCorners = scanFindPaper(scanImg);
  $("scan-modal").hidden = false;
  requestAnimationFrame(scanDraw);
});
function scanRotate() {  // turn the photo a quarter to the right (corners follow)
  const c = document.createElement("canvas");
  c.width = scanImg.height; c.height = scanImg.width;
  const g = c.getContext("2d");
  g.translate(c.width, 0); g.rotate(Math.PI / 2); g.drawImage(scanImg, 0, 0);
  const h = scanImg.height;
  scanCorners = scanCorners.map(([x, y]) => [h - y, x]);
  scanCorners = [scanCorners[3], scanCorners[0], scanCorners[1], scanCorners[2]];  // keep top-left first
  scanImg = c;
  scanDraw();
}
// the paper is usually the biggest bright area: threshold a small copy, keep the largest bright blob, take its corners
function scanFindPaper(img) {
  const W = 160, H = Math.max(1, Math.round(img.height * W / img.width));
  const c = document.createElement("canvas"); c.width = W; c.height = H;
  const g = c.getContext("2d"); g.drawImage(img, 0, 0, W, H);
  const d = g.getImageData(0, 0, W, H).data, lum = new Float32Array(W * H);
  let sum = 0;
  for (let i = 0; i < W * H; i++) { lum[i] = 0.299 * d[i * 4] + 0.587 * d[i * 4 + 1] + 0.114 * d[i * 4 + 2]; sum += lum[i]; }
  const sorted = Float32Array.from(lum).sort(), thr = Math.max(sum / (W * H), sorted[Math.floor(W * H * 0.5)]) * 0.92;
  const seen = new Uint8Array(W * H);
  let best = [];
  for (let start = 0; start < W * H; start++) {
    if (seen[start] || lum[start] < thr) continue;
    const blob = [], stack = [start]; seen[start] = 1;
    while (stack.length) {
      const i = stack.pop(); blob.push(i);
      const x = i % W, y = (i / W) | 0;
      for (const [nx, ny] of [[x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]]) {
        if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
        const j = ny * W + nx;
        if (!seen[j] && lum[j] >= thr) { seen[j] = 1; stack.push(j); }
      }
    }
    if (blob.length > best.length) best = blob;
  }
  const inset = [[0.04, 0.04], [0.96, 0.04], [0.96, 0.96], [0.04, 0.96]].map(([x, y]) => [x * img.width, y * img.height]);
  if (best.length < W * H * 0.08) return inset;  // couldn't tell - start near the edges
  let tl = best[0], tr = best[0], br = best[0], bl = best[0];
  const xy = (i) => [i % W, (i / W) | 0];
  for (const i of best) {
    const [x, y] = xy(i);
    const [a, b2] = xy(tl), [c2, d2] = xy(tr), [e2, f2] = xy(br), [g2, h2] = xy(bl);
    if (x + y < a + b2) tl = i;
    if (x - y > c2 - d2) tr = i;
    if (x + y > e2 + f2) br = i;
    if (y - x > h2 - g2) bl = i;
  }
  const k = img.width / W;
  return [tl, tr, br, bl].map((i) => { const [x, y] = xy(i); return [(x + 0.5) * k, (y + 0.5) * k]; });
}
function scanDraw() {
  const c = $("scan-canvas"), stage = $("scan-stage");
  const maxW = stage.clientWidth || 320, maxH = Math.min(innerHeight * 0.55, 560);
  scanFit = Math.min(maxW / scanImg.width, maxH / scanImg.height);
  c.width = Math.round(scanImg.width * scanFit); c.height = Math.round(scanImg.height * scanFit);
  const g = c.getContext("2d");
  g.drawImage(scanImg, 0, 0, c.width, c.height);
  const pts = scanCorners.map(([x, y]) => [x * scanFit, y * scanFit]);
  g.fillStyle = "rgba(0,0,0,.45)";  // dim everything outside the paper
  g.beginPath(); g.rect(0, 0, c.width, c.height); g.moveTo(...pts[0]); pts.slice(1).reverse().forEach((q) => g.lineTo(...q)); g.closePath(); g.fill("evenodd");
  g.strokeStyle = "#32e0c4"; g.lineWidth = 2;
  g.beginPath(); g.moveTo(...pts[0]); pts.slice(1).forEach((q) => g.lineTo(...q)); g.closePath(); g.stroke();
  pts.forEach(([x, y]) => { g.beginPath(); g.arc(x, y, 11, 0, Math.PI * 2); g.fillStyle = "rgba(50,224,196,.35)"; g.fill(); g.lineWidth = 3; g.stroke(); });
}
const scanPt = (e) => { const r = $("scan-canvas").getBoundingClientRect(); return [(e.clientX - r.left) / scanFit, (e.clientY - r.top) / scanFit]; };
$("scan-canvas").addEventListener("pointerdown", (e) => {
  const [x, y] = scanPt(e);
  let best = -1, bd = Infinity;
  scanCorners.forEach(([cx, cy], i) => { const dd = Math.hypot(cx - x, cy - y); if (dd < bd) { bd = dd; best = i; } });
  if (bd * scanFit > 60) return;
  scanDrag = best; try { $("scan-canvas").setPointerCapture(e.pointerId); } catch {} e.preventDefault();
});
$("scan-canvas").addEventListener("pointermove", (e) => {
  if (scanDrag === null) return;
  const [x, y] = scanPt(e);
  scanCorners[scanDrag] = [Math.max(0, Math.min(scanImg.width, x)), Math.max(0, Math.min(scanImg.height, y))];
  scanDraw();
});
$("scan-canvas").addEventListener("pointerup", () => (scanDrag = null));
$("scan-rotate").addEventListener("click", scanRotate);
$("scan-whole").addEventListener("click", () => { scanCorners = [[0, 0], [scanImg.width, 0], [scanImg.width, scanImg.height], [0, scanImg.height]]; scanDraw(); });
$("scan-auto").addEventListener("click", () => { scanCorners = scanFindPaper(scanImg); scanDraw(); });
$("scan-close").addEventListener("click", () => ($("scan-modal").hidden = true));
document.querySelector(".scan-looks").addEventListener("click", (e) => {
  const b = e.target.closest("[data-scan-look]");
  if (!b) return;
  scanLook = b.dataset.scanLook;
  document.querySelectorAll("[data-scan-look]").forEach((x) => x.classList.toggle("on", x === b));
});

// straighten: map the 4 corners onto a flat rectangle (a homography), sampling the photo for every output pixel
function homography(src, dst) {  // 3x3 matrix taking dst points -> src points
  const A = [], bb = [];
  for (let i = 0; i < 4; i++) {
    const [x, y] = dst[i], [u, v] = src[i];
    A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); bb.push(u);
    A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); bb.push(v);
  }
  for (let c = 0; c < 8; c++) {  // Gaussian elimination
    let piv = c;
    for (let r = c + 1; r < 8; r++) if (Math.abs(A[r][c]) > Math.abs(A[piv][c])) piv = r;
    [A[c], A[piv]] = [A[piv], A[c]]; [bb[c], bb[piv]] = [bb[piv], bb[c]];
    for (let r = 0; r < 8; r++) {
      if (r === c) continue;
      const f = A[r][c] / A[c][c];
      for (let k = c; k < 8; k++) A[r][k] -= f * A[c][k];
      bb[r] -= f * bb[c];
    }
  }
  return [...bb.map((v, i) => v / A[i][i]), 1];
}
function scanStraighten() {
  const [tl, tr, br, bl] = scanCorners, dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
  let w = Math.max(dist(tl, tr), dist(bl, br)), h = Math.max(dist(tl, bl), dist(tr, br));
  const k = Math.min(1, 2000 / Math.max(w, h)); w = Math.round(w * k); h = Math.round(h * k);
  const m = homography(scanCorners, [[0, 0], [w, 0], [w, h], [0, h]]);
  const src = scanImg.getContext("2d").getImageData(0, 0, scanImg.width, scanImg.height), sd = src.data, SW = scanImg.width, SH = scanImg.height;
  const out = new ImageData(w, h), od = out.data;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const z = m[6] * x + m[7] * y + 1, u = (m[0] * x + m[1] * y + m[2]) / z, v = (m[3] * x + m[4] * y + m[5]) / z;
      const x0 = Math.max(0, Math.min(SW - 2, u | 0)), y0 = Math.max(0, Math.min(SH - 2, v | 0)), fx = Math.max(0, Math.min(1, u - x0)), fy = Math.max(0, Math.min(1, v - y0));
      const i00 = (y0 * SW + x0) * 4, i10 = i00 + 4, i01 = i00 + SW * 4, i11 = i01 + 4, o = (y * w + x) * 4;
      for (let ch = 0; ch < 3; ch++)
        od[o + ch] = (sd[i00 + ch] * (1 - fx) + sd[i10 + ch] * fx) * (1 - fy) + (sd[i01 + ch] * (1 - fx) + sd[i11 + ch] * fx) * fy;
      od[o + 3] = 255;
    }
  }
  return out;
}
// clean up like a scanner: estimate the paper's own brightness everywhere (shadows, yellow light) and divide it out
function scanClean(img, look) {
  if (look === "photo") return img;
  const { width: w, height: h, data: d } = img;
  const sw = Math.max(8, Math.round(w / 24)), sh = Math.max(8, Math.round(h / 24));
  const full = document.createElement("canvas"); full.width = w; full.height = h; full.getContext("2d").putImageData(img, 0, 0);
  const small = document.createElement("canvas"); small.width = sw; small.height = sh;
  const sg = small.getContext("2d"); sg.drawImage(full, 0, 0, sw, sh);
  const s = sg.getImageData(0, 0, sw, sh), sd2 = s.data, mx = new Uint8ClampedArray(sd2.length);
  for (let y = 0; y < sh; y++) for (let x = 0; x < sw; x++) {  // brightest nearby = the paper (ink is darker)
    for (let ch = 0; ch < 3; ch++) {
      let best = 0;
      for (let dy = -3; dy <= 3; dy++) for (let dx = -3; dx <= 3; dx++) {
        const xx = Math.max(0, Math.min(sw - 1, x + dx)), yy = Math.max(0, Math.min(sh - 1, y + dy));
        best = Math.max(best, sd2[(yy * sw + xx) * 4 + ch]);
      }
      mx[(y * sw + x) * 4 + ch] = best;
    }
    mx[(y * sw + x) * 4 + 3] = 255;
  }
  sg.putImageData(new ImageData(mx, sw, sh), 0, 0);
  const bgc = document.createElement("canvas"); bgc.width = w; bgc.height = h;
  const bg2 = bgc.getContext("2d"); bg2.imageSmoothingQuality = "high"; bg2.filter = "blur(2px)"; bg2.drawImage(small, 0, 0, w, h);
  const bgd = bg2.getImageData(0, 0, w, h).data;
  const out = new ImageData(w, h), od = out.data;
  for (let i = 0; i < d.length; i += 4) {
    const r = Math.min(1, d[i] / Math.max(1, bgd[i])), g = Math.min(1, d[i + 1] / Math.max(1, bgd[i + 1])), b = Math.min(1, d[i + 2] / Math.max(1, bgd[i + 2]));
    if (look === "bw") {
      let v = 0.299 * r + 0.587 * g + 0.114 * b;
      v = v > 0.9 ? 1 : Math.pow(Math.max(0, (v - 0.1) / 0.8), 1.6);  // paper -> white, pencil -> crisp
      od[i] = od[i + 1] = od[i + 2] = v * 255;
    } else {
      const lift = (x) => (x > 0.92 ? 1 : Math.pow(x / 0.92, 1.25));
      od[i] = lift(r) * 255; od[i + 1] = lift(g) * 255; od[i + 2] = lift(b) * 255;
    }
    od[i + 3] = 255;
  }
  return out;
}
$("scan-go").addEventListener("click", async () => {
  $("scan-go").disabled = true; $("scan-go").textContent = "Scanning…";
  await new Promise((r) => setTimeout(r, 30));  // let the button repaint before the heavy part
  try {
    const flat = scanClean(scanStraighten(), scanLook);
    const c = document.createElement("canvas"); c.width = flat.width; c.height = flat.height;
    c.getContext("2d").putImageData(flat, 0, 0);
    let jpeg = c.toDataURL("image/jpeg", 0.88);
    if (jpeg.length > 3_800_000) jpeg = c.toDataURL("image/jpeg", 0.7);
    $("scan-modal").hidden = true;
    const h = Math.round(1000 * flat.height / flat.width);
    if (scanTarget === "here" && cr && ["draw", "board"].includes(cr.mode)) {
      cr.pendingBase = jpeg; cr.base = false; cr.body.h = h;
      canvasSize(); crMarkDirty(0); toast("📸 Your drawing is underneath - draw right on top");
    } else {
      crOpenNew("draw", null, { title: "Scanned drawing" });
      cr.pendingBase = jpeg; cr.body.h = h; cr.body.bg = "#ffffff";
      canvasSize(); crMarkDirty(0);
      toast("📸 Scanned! Color it in, add to it, or share it");
    }
  } catch (err) { toast("That didn't work - try again (" + err.message + ")"); }
  finally { $("scan-go").disabled = false; $("scan-go").textContent = "Scan it"; }
});
