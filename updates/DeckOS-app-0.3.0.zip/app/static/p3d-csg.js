// ✂ Solid cut / join for 🖨 3D prints (constructive solid geometry with BSP trees).
// After Evan Wallace's csg.js (MIT) - rewritten without recursion so big models don't blow the stack.
// In:  triangles as flat Float32Arrays (x,y,z × 3 per triangle).  Out: the same.

const EPS = 1e-4;
const COPLANAR = 0, FRONT = 1, BACK = 2, SPANNING = 3;

class Plane {
  constructor(n, w) { this.n = n; this.w = w; }  // n = [x,y,z] unit normal
  clone() { return new Plane(this.n.slice(), this.w); }
  flip() { this.n = [-this.n[0], -this.n[1], -this.n[2]]; this.w = -this.w; }
  static from(a, b, c) {
    const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
    let x = uy * vz - uz * vy, y = uz * vx - ux * vz, z = ux * vy - uy * vx;
    const l = Math.hypot(x, y, z); if (!(l > 1e-12)) return null;
    x /= l; y /= l; z /= l;
    return new Plane([x, y, z], x * a[0] + y * a[1] + z * a[2]);
  }
  // sort a polygon into the right list, cutting it in two if it crosses this plane
  split(poly, cFront, cBack, front, back) {
    const [nx, ny, nz] = this.n, types = []; let all = 0;
    for (const v of poly.v) {
      const t = nx * v[0] + ny * v[1] + nz * v[2] - this.w;
      const type = t < -EPS ? BACK : t > EPS ? FRONT : COPLANAR;
      all |= type; types.push(type);
    }
    if (all === COPLANAR) { const p = poly.plane.n; (nx * p[0] + ny * p[1] + nz * p[2] > 0 ? cFront : cBack).push(poly); }
    else if (all === FRONT) front.push(poly);
    else if (all === BACK) back.push(poly);
    else {
      const f = [], b = [], n = poly.v.length;
      for (let i = 0; i < n; i++) {
        const j = (i + 1) % n, ti = types[i], tj = types[j], vi = poly.v[i], vj = poly.v[j];
        if (ti !== BACK) f.push(vi);
        if (ti !== FRONT) b.push(vi);
        if ((ti | tj) === SPANNING) {
          const d = [vj[0] - vi[0], vj[1] - vi[1], vj[2] - vi[2]];
          const t = (this.w - (nx * vi[0] + ny * vi[1] + nz * vi[2])) / (nx * d[0] + ny * d[1] + nz * d[2]);
          const m = [vi[0] + d[0] * t, vi[1] + d[1] * t, vi[2] + d[2] * t];
          f.push(m); b.push(m);
        }
      }
      if (f.length >= 3) front.push(new Poly(f, poly.plane));
      if (b.length >= 3) back.push(new Poly(b, poly.plane));
    }
  }
}

class Poly {
  constructor(v, plane) { this.v = v; this.plane = plane || Plane.from(v[0], v[1], v[2]); }
  clone() { return new Poly(this.v.slice(), this.plane.clone()); }
  flip() { this.v.reverse(); this.plane = this.plane.clone(); this.plane.flip(); }
}

class Node {
  constructor(polys) { this.plane = null; this.front = null; this.back = null; this.polys = []; if (polys) this.build(polys); }
  nodes() { const out = [], st = [this]; while (st.length) { const n = st.pop(); out.push(n); if (n.front) st.push(n.front); if (n.back) st.push(n.back); } return out; }
  invert() {
    for (const n of this.nodes()) {
      n.polys.forEach((p) => p.flip());
      if (n.plane) { n.plane = n.plane.clone(); n.plane.flip(); }
      const t = n.front; n.front = n.back; n.back = t;
    }
  }
  clip(polys) {  // the parts of polys that are outside this solid
    if (!this.plane) return polys.slice();
    const out = [], st = [[this, polys]];
    while (st.length) {
      const [n, ps] = st.pop(), f = [], b = [];
      for (const p of ps) n.plane.split(p, f, b, f, b);
      if (n.front) st.push([n.front, f]); else for (const p of f) out.push(p);
      if (n.back) st.push([n.back, b]);  // (no back node = inside the solid: dropped)
    }
    return out;
  }
  clipTo(bsp) { for (const n of this.nodes()) n.polys = bsp.clip(n.polys); }
  all() { const out = []; for (const n of this.nodes()) for (const p of n.polys) out.push(p); return out; }
  build(polys) {
    const st = [[this, polys]];
    while (st.length) {
      const [n, ps] = st.pop(); if (!ps.length) continue;
      if (!n.plane) n.plane = ps[0].plane.clone();
      const f = [], b = [];
      for (const p of ps) n.plane.split(p, n.polys, n.polys, f, b);
      if (f.length) { n.front = n.front || new Node(); st.push([n.front, f]); }
      if (b.length) { n.back = n.back || new Node(); st.push([n.back, b]); }
    }
  }
}

function polys(arr) {
  const out = [];
  for (let i = 0; i + 8 < arr.length; i += 9) {
    const v = [[arr[i], arr[i + 1], arr[i + 2]], [arr[i + 3], arr[i + 4], arr[i + 5]], [arr[i + 6], arr[i + 7], arr[i + 8]]];
    const plane = Plane.from(v[0], v[1], v[2]);
    if (plane) out.push(new Poly(v, plane));  // (skip slivers with no area)
  }
  return out;
}
function tris(ps) {  // polygons are convex: fan them into triangles
  let n = 0; ps.forEach((p) => n += p.v.length - 2);
  const out = new Float32Array(n * 9); let o = 0;
  for (const p of ps) for (let k = 1; k + 1 < p.v.length; k++) for (const v of [p.v[0], p.v[k], p.v[k + 1]]) { out[o++] = v[0]; out[o++] = v[1]; out[o++] = v[2]; }
  return out;
}

export function subtract(a, b) {  // a with b cut out of it
  const A = new Node(polys(a)), B = new Node(polys(b));
  A.invert(); A.clipTo(B); B.clipTo(A); B.invert(); B.clipTo(A); B.invert(); A.build(B.all()); A.invert();
  return tris(A.all());
}
export function union(a, b) {  // a and b melted into one solid
  const A = new Node(polys(a)), B = new Node(polys(b));
  A.clipTo(B); B.clipTo(A); B.invert(); B.clipTo(A); B.invert(); A.build(B.all());
  return tris(A.all());
}
