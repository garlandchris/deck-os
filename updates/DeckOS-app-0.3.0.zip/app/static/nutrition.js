// 🔥 calories (Meals), 🥗 diet (profile), and the Food filters that use them
const DIET_OPTIONS = ["Vegetarian", "Vegan", "Pescatarian", "Gluten-free", "Dairy-free", "Nut-free", "Halal", "Kosher", "Keto", "Low-carb", "Low-sodium", "Diabetic-friendly"];
const kc = (n) => Number(n || 0).toLocaleString();

// ----- Meals: today's calories -----
function drawCalories() {
  const c = meals && meals.calories;
  if (!c) return;
  const tonight = meals.days.find((d) => d.today && d.recipe);
  const tonightR = tonight && meals.recipes.find((r) => r.id === tonight.recipe.id);
  if (!c.goal) {
    $("cal-box").innerHTML = `<div class="cal-off"><b>🔥 Count calories?</b><span class="muted small">Set a daily goal and Deck OS shows what fits - here and in Food.</span>
      <div class="row-mini"><input id="cal-goal" type="number" min="800" max="6000" placeholder="2000"><button class="small-btn" data-cal-goal>Set goal</button></div>
      <small class="muted">Not sure? 2,000 is a common starting point - your doctor can tell you what's right for you.</small></div>`;
    return;
  }
  const pct = Math.min(100, Math.round(c.eaten / c.goal * 100)), over = c.left < 0;
  $("cal-box").innerHTML = `<div class="cal-head"><div><b class="cal-left ${over ? "low" : ""}">${over ? kc(-c.left) + " over" : kc(c.left) + " left"}</b>
      <small class="muted">${kc(c.eaten)} of ${kc(c.goal)} today</small></div><button class="link-btn" data-cal-edit>goal</button></div>
    <div class="mn-bar ${over ? "low" : pct > 85 ? "ok" : "good"}"><i style="width:${pct}%"></i></div>
    ${c.today.length ? `<div class="cal-today">${c.today.map((x) => `<span>${esc(x.name)} <b>${kc(x.kcal)}</b><button class="link-btn" data-cal-x="${x.id}">✕</button></span>`).join("")}</div>` : ""}
    <div class="row-mini cal-add"><input id="cal-name" maxlength="60" placeholder="What did you eat?"><input id="cal-kcal" type="number" min="1" max="5000" placeholder="cal">
      <button class="small-btn" data-cal-est title="Estimate it">🤖</button><button class="accent-btn small-btn" data-cal-add>＋</button></div>
    ${tonightR && tonightR.kcal ? `<button class="small-btn cal-tonight" data-cal-tonight>${esc(tonightR.emoji)} Had tonight's ${esc(tonightR.name)} (~${kc(tonightR.kcal)})</button>` : ""}
    <div class="cal-goal-edit" hidden><input id="cal-goal" type="number" min="800" max="6000" value="${c.goal}"><button class="small-btn" data-cal-goal>Save</button><button class="link-btn" data-cal-off>stop counting</button></div>`;
}
async function calPost(body, msg) {
  try { meals.calories = await post("/api/calories", body); drawCalories(); if (typeof drawMealPicker === "function" && !$("meal-modal").hidden) drawMealPicker(); if (msg) toast(msg); } catch (err) { toast(err.message); }
}
$("cal-box").addEventListener("click", async (e) => {
  if (e.target.closest("[data-cal-goal]")) return calPost({ goal: $("cal-goal").value }, "🔥 Goal set");
  if (e.target.closest("[data-cal-off]")) return calPost({ goal: 0 }, "Stopped counting");
  if (e.target.closest("[data-cal-edit]")) { const g = $("cal-box").querySelector(".cal-goal-edit"); g.hidden = !g.hidden; return; }
  const x = e.target.closest("[data-cal-x]");
  if (x) return calPost({ remove: x.dataset.calX });
  if (e.target.closest("[data-cal-add]")) return calPost({ add: { name: $("cal-name").value, kcal: $("cal-kcal").value } }, "➕ Logged");
  if (e.target.closest("[data-cal-tonight]")) {
    const t = meals.days.find((d) => d.today && d.recipe), r = meals.recipes.find((y) => y.id === t.recipe.id);
    return calPost({ add: { name: r.name, kcal: r.kcal } }, `${r.emoji} Logged`);
  }
  if (e.target.closest("[data-cal-est]")) {
    const name = $("cal-name").value.trim();
    if (!name) return $("cal-name").focus();
    const b = e.target.closest("[data-cal-est]"); b.disabled = true; b.textContent = "…";
    try { const r = await post("/api/meals/estimate", { name }); $("cal-kcal").value = r.kcal; toast(`🤖 About ${kc(r.kcal)} - ${r.note || "a typical serving"}`); }
    catch (err) { toast(err.message); } finally { b.disabled = false; b.textContent = "🤖"; }
  }
});
$("cal-box").addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target.matches("#cal-name, #cal-kcal")) { e.preventDefault(); $("cal-box").querySelector("[data-cal-add]").click(); } });
// recipe rows: calories + does it fit what's left today?
function recipeKcalHtml(r) {
  if (!r.kcal) return "";
  const c = meals && meals.calories;
  if (!c || c.left == null) return `<small class="recipe-kcal">🔥 ~${kc(r.kcal)} cal</small>`;
  return r.kcal <= c.left ? `<small class="recipe-kcal good">✅ fits · ~${kc(r.kcal)} cal</small>` : `<small class="recipe-kcal low">⚠️ ~${kc(r.kcal)} cal · ${kc(r.kcal - Math.max(0, c.left))} over</small>`;
}
$("recipe-estimate").addEventListener("click", async () => {
  const b = $("recipe-estimate"); b.disabled = true; b.textContent = "🤖 …";
  try {
    const r = await post("/api/meals/estimate", { name: $("recipe-name").value, ingredients: $("recipe-ingredients").value.split("\n").filter(Boolean) });
    $("recipe-kcal").value = r.kcal; $("recipe-kcal-note").textContent = r.note || "";
  } catch (err) { toast(err.message); } finally { b.disabled = false; b.textContent = "🤖 Estimate"; }
});

// ----- Food: fits my calories / my diet -----
let foodFits = false, foodDiet = false;
const DIET_TAG = { Vegan: "vegan", Vegetarian: "vegetarian", "Gluten-free": "gluten_free", Halal: "halal", Kosher: "kosher" };
function myDietTags() { return ((food && food.diet) || []).map((d) => DIET_TAG[d]).filter(Boolean); }
function drawFoodFilters() {
  if (!food || foodTab !== "near") { $("food-filters").innerHTML = ""; return; }
  const c = food.calories || {}, tags = myDietTags();
  $("food-filters").innerHTML = (c.left != null ? `<button data-ffit class="${foodFits ? "on" : ""}">🔥 Fits my calories <small>(${c.left > 0 ? "~" + kc(c.left) + " left" : "none left today"})</small></button>` : "")
    + (tags.length ? `<button data-fdiet class="${foodDiet ? "on" : ""}">🥗 ${esc(food.diet.filter((d) => DIET_TAG[d]).join(" / "))}</button>` : "")
    + (c.left != null || tags.length ? `<small class="muted food-est">cal = a typical meal there (an estimate)</small>` : "");
}
function foodFilterOk(i) {
  if (foodFits && food.calories && food.calories.left != null && (i.kcal || 0) > Math.max(0, food.calories.left)) return false;
  if (foodDiet) { const t = myDietTags(); if (t.length && !t.some((d) => (i.diets || []).includes(d)) && i.category !== "Salads & Healthy") return false; }
  return true;
}
$("food-filters").addEventListener("click", (e) => {
  if (e.target.closest("[data-ffit]")) { foodFits = !foodFits; drawFood(); }
  if (e.target.closest("[data-fdiet]")) { foodDiet = !foodDiet; drawFood(); }
});

// ----- profile: my diet -----
function drawMyDiet() {
  if (!profile) return;
  const mine = profile.diet || [];
  $("pf-diet").innerHTML = [...new Set([...DIET_OPTIONS, ...mine])].map((d) => `<button type="button" data-diet="${esc(d)}" class="${mine.includes(d) ? "on" : ""}">${mine.includes(d) ? "✓ " : ""}${esc(d)}</button>`).join("");
}
async function saveDiet(list) {
  try { const r = await post("/api/profile", { diet: list }); profile.diet = r.diet; drawMyDiet(); toast("🥗 Saved"); } catch (err) { toast(err.message); }
}
$("pf-diet").addEventListener("click", (e) => {
  const b = e.target.closest("[data-diet]");
  if (!b) return;
  const mine = new Set(profile.diet || []);
  mine.has(b.dataset.diet) ? mine.delete(b.dataset.diet) : mine.add(b.dataset.diet);
  saveDiet([...mine]);
});
$("pf-diet-add").addEventListener("click", () => { const v = $("pf-diet-new").value.trim(); if (v) { $("pf-diet-new").value = ""; saveDiet([...(profile.diet || []), v]); } });
