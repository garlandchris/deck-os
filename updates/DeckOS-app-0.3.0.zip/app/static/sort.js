// 🗂 Sort my spending (owner, home PC): the budget app's transactions that have no category yet. Pick one and it waits
// here until the budget coach puts it in the budget app on its next sync. Read only - nothing here moves money.
// 🎯 Big goals card on Money: big fund / savings / invested from the coach, with a "move the goal post?" check-in.
let srt = null, srtOpen = null;
const srtUsd = (v) => (v < 0 ? "+" : "") + "$" + Math.abs(Number(v || 0)).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const srtDay = (d) => new Date(d + "T12:00").toLocaleDateString([], { month: "short", day: "numeric" });

async function loadSortPage() {
  $("sort-body").innerHTML = '<p class="muted">Reading your budget app…</p>';
  try { srt = await api("/api/money/sort"); } catch (err) { srt = { ok: false, say: err.message }; }
  drawSort();
}

function srtCats(sel) {
  const groups = {};
  for (const c of srt.cats) (groups[c.group] = groups[c.group] || []).push(c);
  return `<option value="">Pick a category…</option>` + Object.entries(groups).map(([g, cs]) =>
    `<optgroup label="${esc(g)}">${cs.map((c) => `<option value="${esc(c.id)}" ${c.id === sel ? "selected" : ""}>${esc(c.name)}</option>`).join("")}</optgroup>`).join("");
}

function drawSort() {
  const box = $("sort-body"), s = srt;
  if (!s || !s.ok) { box.innerHTML = `<p class="muted">${esc((s && s.say) || "Couldn't load this right now.")}</p><button class="small-btn" data-srt-refresh>↻ Refresh</button>`; return; }
  const name = (id) => (s.cats.find((c) => c.id === id) || {}).name || "";
  const same = (p) => s.unsorted.filter((r) => r.payee && r.payee === p).length;
  const row = (r) => {
    const open = srtOpen === r.id, n = same(r.payee);
    return `<div class="card srt-item${open ? " srt-open" : ""}" data-id="${esc(r.id)}">
      <div class="subs-top"><b>${esc(r.payee || "(no name)")}</b><b class="${r.amount < 0 ? "best-good" : ""}">${srtUsd(r.amount)}</b></div>
      <p class="muted small">${srtDay(r.date)} · ${esc(r.account)}${r.notes ? " · " + esc(r.notes) : ""}</p>
      ${open ? `<div class="mn-row"><select data-srt-cat>${srtCats(r.guess)}</select></div>
        ${n > 1 ? `<label class="small"><input type="checkbox" data-srt-all checked> All ${n} from ${esc(r.payee)}</label>` : ""}
        ${r.payee ? `<label class="small"><input type="checkbox" data-srt-rule> Always sort ${esc(r.payee)} this way</label>` : ""}
        <div class="quiz-row"><button class="accent-btn small-btn" data-srt-save>Sort it</button><button class="link-btn" data-srt-close>cancel</button></div>`
      : `<div class="quiz-row">${r.guess ? `<button class="small-btn" data-srt-guess="${esc(r.guess)}">💡 ${esc(name(r.guess))}</button>` : ""}<button class="small-btn" data-srt-pick>🗂 Sort…</button></div>`}</div>`;
  };
  const synced = new Date(s.synced * 1000).toLocaleString([], { weekday: "short", hour: "numeric", minute: "2-digit" });
  box.innerHTML = `<div class="card"><h4>${s.unsorted.length}${s.more ? "+" : ""} not sorted yet</h4>
      <p class="muted small">From your budget app (last synced ${esc(synced)}). Pick a category and it's ⏳ waiting until the budget coach puts it in on its next sync - then it drops off this list. Read only - nothing here moves money.</p>
      <button class="small-btn" data-srt-refresh>↻ Refresh</button></div>
    ${s.unsorted.length ? s.unsorted.map(row).join("") : '<p class="muted">🎉 Everything is sorted.</p>'}
    ${s.waiting.length ? `<h3 class="cr-h">⏳ Waiting for the budget app <small class="muted">${s.waiting.length}</small></h3>${s.waiting.map((r) => `<div class="card srt-item" data-id="${esc(r.id)}">
      <div class="subs-top"><b>${esc(r.payee || "(no name)")}</b><b>${srtUsd(r.amount)}</b></div>
      <p class="muted small">${srtDay(r.date)} · → ${esc(r.cat_name)}${r.rule ? " · always" : ""}</p>
      <div class="quiz-row"><button class="link-btn" data-srt-undo>undo</button></div></div>`).join("")}` : ""}`;
}

async function srtSend(body, msg) {
  try { srt = await post("/api/money/sort", body); srtOpen = null; if (msg) toast(msg); } catch (err) { toast(err.message); }
  drawSort();
}

if ($("sort-body")) $("sort-body").addEventListener("click", (e) => {
  const b = e.target.closest("button"); if (!b) return;
  const it = b.closest("[data-id]"), id = it && it.dataset.id, r = srt && srt.unsorted && srt.unsorted.find((x) => x.id === id);
  if (b.hasAttribute("data-srt-refresh")) return loadSortPage();
  if (b.hasAttribute("data-srt-pick")) { srtOpen = id; return drawSort(); }
  if (b.hasAttribute("data-srt-close")) { srtOpen = null; return drawSort(); }
  if (b.hasAttribute("data-srt-undo")) return srtSend({ ids: [id], undo: true });
  if (b.dataset.srtGuess) return srtSend({ ids: [id], cat: b.dataset.srtGuess }, "Sorted ⏳");
  if (b.hasAttribute("data-srt-save")) {
    const cat = it.querySelector("[data-srt-cat]").value;
    if (!cat) return toast("Pick a category");
    const all = it.querySelector("[data-srt-all]"), rule = it.querySelector("[data-srt-rule]");
    const ids = all && all.checked ? srt.unsorted.filter((x) => x.payee === r.payee).map((x) => x.id) : [id];
    b.disabled = true;
    return srtSend({ ids, cat, rule: !!(rule && rule.checked) }, ids.length > 1 ? `Sorted ${ids.length} ⏳` : "Sorted ⏳");
  }
});

// the link on the Money page (owner only): "🗂 Sort my spending: 12 not sorted →"
async function drawSortLink() {
  const box = $("mn-sort-link"); if (!box) return;
  if (!status || status.demo || typeof subsOk !== "function" || !subsOk()) { box.hidden = true; return; }
  let s; try { s = await api("/api/money/sort"); } catch { box.hidden = true; return; }
  box.hidden = !s.ok;
  if (!s.ok) return;
  box.innerHTML = `<button class="card subs-link" data-go="sort"><b>🗂 Sort my spending</b>
    <span>${s.unsorted.length ? `${s.unsorted.length}${s.more ? "+" : ""} not sorted yet` : "Everything's sorted 🎉"}${s.waiting.length ? ` · ${s.waiting.length} waiting` : ""}</span><span class="muted">Open →</span></button>`;
}
if ($("mn-sort-link")) $("mn-sort-link").addEventListener("click", (e) => { if (e.target.closest("[data-go]")) go("sort"); });

// 🎯 Big goals
let bg = null;
async function drawBigGoals() {
  const box = $("mn-biggoals"); if (!box) return;
  if (!status || status.demo || typeof subsOk !== "function" || !subsOk()) { box.hidden = true; return; }
  try { bg = await api("/api/money/big-goals"); } catch { box.hidden = true; return; }
  box.hidden = false;
  drawBigGoalsBox();
}
function bgSpark(trend) {
  const v = trend.map((t) => t[1]); if (v.length < 2) return "";
  const lo = Math.min(...v), hi = Math.max(...v), w = 120, h = 24;
  const pts = v.map((x, i) => `${(i / (v.length - 1) * w).toFixed(1)},${(h - (hi === lo ? h / 2 : (x - lo) / (hi - lo) * h)).toFixed(1)}`).join(" ");
  return `<svg class="bg-spark" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" aria-hidden="true"><polyline points="${pts}" fill="none" stroke="var(--accent)" stroke-width="2"/></svg>`;
}
function drawBigGoalsBox() {
  const box = $("mn-biggoals");
  if (!bg.ok) { box.innerHTML = `<h3 class="cr-h">🎯 Big goals</h3><p class="muted small">${esc(bg.say || "")}</p>`; return; }
  const money = (v) => "$" + Math.round(v || 0).toLocaleString("en-US");
  box.innerHTML = `<h3 class="cr-h">🎯 Big goals <small class="muted">tracked from your accounts</small></h3><div class="mn-grid">${bg.goals.map((g) => `<div class="card mn-pot" data-bg="${g.key}">
      <div class="mn-pot-head"><b>${g.e} ${esc(g.t)}</b><small class="muted">${g.pct === null ? "" : g.pct + "%"}</small></div>
      <div class="mn-big">${g.now === null ? "?" : money(g.now)} <small class="muted">${g.goal ? `of ${g.low ? money(g.low) + "-" : ""}${money(g.goal)}` : "- set your goal below"}</small></div>
      ${mnBar(g.pct || 0, (g.pct || 0) >= 100 ? "good" : "")}
      <small class="muted">${g.pace === null ? "Pace shows up after 2 weeks of tracking." : g.pace > 0 ? `+${money(g.pace)}/month${g.months ? ` · about ${g.months < 1 ? "under a month" : Math.round(g.months) + " months"} to go` : ""}` : g.pace < 0 ? `Down ${money(-g.pace)}/month lately` : "Flat lately"}</small>
      ${bgSpark(g.trend)}
      ${g.ask ? `<p class="small"><b>${g.pct >= 100 ? "🎉 You made it!" : "Almost there!"}</b> Want to move the goal post?</p>` : ""}
      <details class="mn-log mn-edit" ${g.ask ? "open" : ""}><summary>🥅 ${g.goal ? "Move the goal post" : "Set my goal"}</summary>
        <div class="mn-row"><input data-bg-goal inputmode="decimal" placeholder="New goal $" value=""><button class="accent-btn small-btn" data-bg-save>Move it</button>${g.ask ? `<button class="small-btn" data-bg-keep>Keep ${money(g.goal)}</button>` : ""}</div></details>
    </div>`).join("")}</div>`;
}
if ($("mn-biggoals")) $("mn-biggoals").addEventListener("click", async (e) => {
  const b = e.target.closest("button"); if (!b) return;
  const key = b.closest("[data-bg]").dataset.bg;
  let body;
  if (b.hasAttribute("data-bg-keep")) body = { key, keep: true };
  else if (b.hasAttribute("data-bg-save")) body = { key, goal: b.closest("[data-bg]").querySelector("[data-bg-goal]").value };
  else return;
  b.disabled = true;
  try { bg = await post("/api/money/big-goals", body); toast(body.keep ? "Keeping it 👍" : "Goal post moved 🥅"); } catch (err) { toast(err.message); b.disabled = false; return; }
  drawBigGoalsBox();
});
