// ☀️ Morning Run - pose logic that runs ON THE PHONE (MediaPipe Pose landmarks in, reps + form tips out). Nothing is
// recorded or sent. Pure functions so it can be unit-tested with synthetic landmarks (tests/morning_pose_test.mjs).
// Landmarks: 0 nose, 11/12 shoulders, 13/14 elbows, 15/16 wrists, 23/24 hips, 25/26 knees, 27/28 ankles. y grows downward.
(function (root) {
  const ang = (a, b, c) => { const ab = Math.atan2(a.y - b.y, a.x - b.x), cb = Math.atan2(c.y - b.y, c.x - b.x); let d = Math.abs(ab - cb) * 180 / Math.PI; return d > 180 ? 360 - d : d; };
  const vis = (lm, ids) => ids.every((i) => lm[i] && (lm[i].visibility ?? 1) > 0.5);
  const side = (lm, L, R) => (vis(lm, L) ? L : vis(lm, R) ? R : null);
  const tilt = (a, b) => Math.abs(Math.atan2(b.x - a.x, b.y - a.y) * 180 / Math.PI);  // degrees off vertical (a above b)
  const now = () => (typeof performance !== "undefined" ? performance.now() : Date.now());

  // a rep = rest (A) -> work (B) -> rest (A); a state must hold 2 frames; reps at least 350 ms apart
  function twoState(test, clock = now) {
    let st = null, cand = null, n = 0, half = false, last = -1e9;
    const f = (lm) => {
      if (!lm) return null;
      const s = test(lm); if (!s) return null;
      if (s === cand) n++; else { cand = s; n = 1; }
      if (n < 2 || s === st) return null;
      st = s;
      if (s === "B") { half = true; return "down"; }
      if (s === "A" && half) { half = false; const t = clock(); if (t - last > 350) { last = t; return "rep"; } }
      return null;
    };
    return f;
  }
  const either = (a, b) => (lm) => (lm && (a(lm) === "rep" || b(lm) === "rep") ? "rep" : null);
  const elbow = (down = 90, up = 150) => (lm) => { const s = side(lm, [11, 13, 15], [12, 14, 16]); if (!s) return null; const a = ang(lm[s[0]], lm[s[1]], lm[s[2]]); return a > up ? "A" : a < down ? "B" : null; };
  const kneeA = (down) => (lm) => { const k = []; if (vis(lm, [23, 25, 27])) k.push(ang(lm[23], lm[25], lm[27])); if (vis(lm, [24, 26, 28])) k.push(ang(lm[24], lm[26], lm[28])); if (!k.length) return null; const a = Math.min(...k); return a > 160 ? "A" : a < down ? "B" : null; };
  const wristsOverNose = (lm) => { if (!vis(lm, [0, 11, 12, 15, 16])) return null; const wy = Math.max(lm[15].y, lm[16].y); return wy < lm[0].y ? "B" : wy > Math.min(lm[11].y, lm[12].y) - 0.02 ? "A" : null; };
  const chinOverBar = (lm) => { if (!vis(lm, [0, 15, 16])) return null; const wy = Math.min(lm[15].y, lm[16].y); if (lm[0].y < wy) return "B";
    const s = side(lm, [11, 13, 15], [12, 14, 16]); return s && ang(lm[s[0]], lm[s[1]], lm[s[2]]) > 150 ? "A" : null; };
  const hipsUp = (lm) => { const s = side(lm, [11, 23, 25], [12, 24, 26]); if (!s) return null; const a = ang(lm[s[0]], lm[s[1]], lm[s[2]]); return a > 160 ? "B" : a < 130 ? "A" : null; };  // bridges
  const kneeUp = (h, k) => (lm) => vis(lm, [h, k]) ? (lm[k].y < lm[h].y + 0.05 ? "B" : lm[k].y > lm[h].y + 0.15 ? "A" : null) : null;
  const kneeToChest = (sh, hip, kn) => (lm) => { if (!vis(lm, [sh, hip, kn])) return null; const torso = Math.hypot(lm[sh].x - lm[hip].x, lm[sh].y - lm[hip].y) || 0.1;
    const d = Math.hypot(lm[kn].x - lm[sh].x, lm[kn].y - lm[sh].y) / torso; return d < 0.75 ? "B" : d > 1.1 ? "A" : null; };

  // how each exercise is counted by the camera (missing = tap to count / timer)
  const COUNT = {
    pushups: (clock) => twoState(elbow(), clock), pike: (clock) => twoState(elbow(95), clock), squats: (clock) => twoState(kneeA(100), clock), goblet: (clock) => twoState(kneeA(100), clock),
    lunges: (clock) => twoState(kneeA(105), clock), latlunge: (clock) => twoState(kneeA(110), clock), cossack: (clock) => twoState(kneeA(100), clock), lungerot: (clock) => twoState(kneeA(105), clock),
    pullups: (clock) => twoState(chinOverBar, clock), zpress: (clock) => twoState(wristsOverNose, clock),
    sprawl: (clock) => twoState((lm) => { if (!vis(lm, [11, 23])) return null; const d = Math.abs(lm[11].y - lm[23].y); return d > 0.18 ? "A" : d < 0.08 ? "B" : null; }, clock),
    glutebridge: (clock) => twoState(hipsUp, clock), upa: (clock) => twoState(hipsUp, clock),
    situps: (clock) => twoState((lm) => { const s = side(lm, [11, 23, 25], [12, 24, 26]); if (!s) return null; const a = ang(lm[s[0]], lm[s[1]], lm[s[2]]); return a > 120 ? "A" : a < 70 ? "B" : null; }, clock),
    vups: (clock) => twoState((lm) => { const s = side(lm, [11, 23, 27], [12, 24, 28]); if (!s) return null; const a = ang(lm[s[0]], lm[s[1]], lm[s[2]]); return a > 150 ? "A" : a < 80 ? "B" : null; }, clock),
    sealjacks: (clock) => twoState((lm) => { if (!vis(lm, [11, 12, 15, 16, 27, 28])) return null; const sw = Math.abs(lm[11].x - lm[12].x) || 0.1;
      const arms = Math.abs(lm[15].x - lm[16].x) / sw, feet = Math.abs(lm[27].x - lm[28].x) / sw; return arms > 2.2 && feet > 1.4 ? "B" : arms < 1.2 && feet < 1.1 ? "A" : null; }, clock),
    jacks: (clock) => twoState((lm) => { if (!vis(lm, [11, 12, 15, 16, 27, 28])) return null; const sw = Math.abs(lm[11].x - lm[12].x) || 0.1, feet = Math.abs(lm[27].x - lm[28].x) / sw;
      const up = lm[15].y < lm[11].y && lm[16].y < lm[12].y; return up && feet > 1.4 ? "B" : !up && feet < 1.1 ? "A" : null; }, clock),
    knees: (clock) => either(twoState(kneeUp(23, 25), clock), twoState(kneeUp(24, 26), clock)),
    hangknees: (clock) => twoState((lm) => vis(lm, [23, 25]) ? (lm[25].y < lm[23].y ? "B" : lm[25].y > lm[23].y + 0.15 ? "A" : null) : null, clock),
    climbers: (clock) => either(twoState(kneeToChest(11, 23, 25), clock), twoState(kneeToChest(12, 24, 26), clock)),
    twists: (clock) => twoState((lm) => { if (!vis(lm, [11, 12, 15, 16])) return null; const mid = (lm[11].x + lm[12].x) / 2, hx = (lm[15].x + lm[16].x) / 2, sw = Math.abs(lm[11].x - lm[12].x) || 0.1;
      return hx < mid - 0.35 * sw ? "A" : hx > mid + 0.35 * sw ? "B" : null; }, clock),  // one rep = touch one side and back
  };

  // form checks: return a short tip for this frame, or null when it looks clean. Helpers, not a coach.
  const straight = (lm) => { const s = side(lm, [11, 23, 27], [12, 24, 28]); return s ? ang(lm[s[0]], lm[s[1]], lm[s[2]]) : null; };
  const FORM = {
    pushups: { live: (lm) => { const a = straight(lm); return a != null && a < 160 ? "Hips in line" : null; },
               depth: (lm) => { const s = side(lm, [11, 13, 15], [12, 14, 16]); return s ? ang(lm[s[0]], lm[s[1]], lm[s[2]]) : null; }, depthMax: 100, depthTip: "A little deeper - chest to fist height" },
    pike: { live: (lm) => { const s = side(lm, [11, 23, 27], [12, 24, 28]); return s && ang(lm[s[0]], lm[s[1]], lm[s[2]]) > 120 ? "Hips higher" : null; } },
    goblet: { live: (lm) => { if (vis(lm, [11, 23]) && tilt(lm[11], lm[23]) > 50) return "Chest up";
                               if (vis(lm, [25, 26, 27, 28]) && Math.abs(lm[25].x - lm[26].x) < 0.8 * Math.abs(lm[27].x - lm[28].x)) return "Knees out"; return null; },
              depth: (lm) => (vis(lm, [23, 25]) ? (lm[23].y - lm[25].y) * -100 : null), depthMax: 2, depthTip: "A bit deeper - hips to knees" },
    plank: { live: (lm) => { const a = straight(lm); return a != null && a < 160 ? "Straight line - squeeze your glutes" : null; } },
    lunges: { live: (lm) => { const s = side(lm, [25, 27], [26, 28]); if (s && Math.abs(lm[s[0]].x - lm[s[1]].x) > 0.08 && lm[s[0]].y > 0) return "Knee over the ankle";
                               return vis(lm, [11, 23]) && tilt(lm[11], lm[23]) > 30 ? "Stay tall" : null; } },
    rdl: { live: (lm) => { if (vis(lm, [0, 11, 23]) && ang(lm[0], lm[11], lm[23]) < 140) return "Flat back, chest proud";
                            const s = side(lm, [23, 25, 27], [24, 26, 28]); return s && ang(lm[s[0]], lm[s[1]], lm[s[2]]) < 135 ? "Soft knees - hinge at the hips" : null; } },
    twists: { live: (lm) => { if (!vis(lm, [11, 23])) return null; const t = tilt(lm[11], lm[23]); return t < 15 ? "Lean back a little" : t > 60 ? "Sit up a bit" : null; } },
    headheight: { live: (lm) => (vis(lm, [0, 15, 16]) && Math.min(lm[15].y, lm[16].y) < lm[0].y - 0.06 ? "Stay at head height" : null) },
    getup: { live: (lm) => { const s = side(lm, [11, 13, 15], [12, 14, 16]); return s && lm[s[2]].y < lm[s[0]].y && ang(lm[s[0]], lm[s[1]], lm[s[2]]) < 160 ? "Lock the elbow" : null; } },
    sprawl: { bottom: (lm) => (vis(lm, [11, 23]) ? Math.abs(lm[11].y - lm[23].y) : null), bottomMax: 0.1, bottomTip: "Hips all the way down" },
  };
  const FORM_OF = { pushups: "pushups", pike: "pike", goblet: "goblet", squats: "goblet", plank: "plank", sideplank: "plank", bearhold: null,
    lunges: "lunges", latlunge: "lunges", cossack: "lunges", lungerot: "lunges", slrdl: "rdl", twists: "twists",
    halo: "headheight", chop2lift: "headheight", woodchop: "headheight", windmill: null, tgukneel: "getup", sprawl: "sprawl" };

  // 🌀 fan safety: a wrist above the head while standing (hips well above knees) - warn right away
  function fanAlert(lm) {
    if (!lm || !vis(lm, [0, 15, 16, 23, 25])) return false;
    const standing = lm[25].y - lm[23].y > 0.12;
    return standing && Math.min(lm[15].y, lm[16].y) < lm[0].y - 0.08;
  }

  // per-rep form tracking: a rep is clean if no tip fired during it; cues spoken at most once per 3 reps
  function formTracker(id) {
    const key = FORM_OF[id], rule = key && FORM[key];
    let faults = {}, repFault = null, depth = null, bottom = null, clean = 0, total = 0, lastCueRep = -99;
    return {
      has: !!rule,
      frame(lm) {
        if (!rule || !lm) return null;
        const tip = rule.live ? rule.live(lm) : null;
        if (tip) repFault = repFault || tip;
        if (rule.depth) { const d = rule.depth(lm); if (d != null) depth = depth == null ? d : Math.min(depth, d); }
        if (rule.bottom) { const b = rule.bottom(lm); if (b != null) bottom = bottom == null ? b : Math.min(bottom, b); }
        return tip;
      },
      rep() {  // call on each counted rep; returns a tip to say (or null)
        total++;
        if (rule && rule.depth && depth != null && depth > rule.depthMax) repFault = repFault || rule.depthTip;
        if (rule && rule.bottom && bottom != null && bottom > rule.bottomMax) repFault = repFault || rule.bottomTip;
        let say = null;
        if (repFault) { faults[repFault] = (faults[repFault] || 0) + 1; if (total - lastCueRep >= 3) { say = repFault; lastCueRep = total; } } else clean++;
        repFault = null; depth = null; bottom = null;
        return say;
      },
      summary() {
        const top = Object.entries(faults).sort((a, b) => b[1] - a[1])[0];
        return rule && total ? { clean, of: total, tip: top ? top[0].toLowerCase() : "" } : null;
      },
    };
  }

  // phone placement: whole body in frame (nose, shoulders, hips, ankles visible) for ~1 s
  const FRAME_IDS = [0, 11, 12, 23, 24, 27, 28];
  function framer(needFrames = 20) { let n = 0; return (lm) => { if (lm && FRAME_IDS.every((i) => lm[i] && (lm[i].visibility ?? 1) > 0.5 && lm[i].y > 0 && lm[i].y < 1)) n++; else n = 0; return n >= needFrames; }; }

  root.MorningPose = { ang, twoState, COUNT, FORM, FORM_OF, fanAlert, formTracker, framer, straight };
})(typeof window !== "undefined" ? window : globalThis);
