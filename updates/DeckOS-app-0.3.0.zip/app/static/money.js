// 💰 Money: private goals / subscriptions / budget + a money check, and shared family pots.
let mn = null;
const usd = (v) => "$" + Number(v || 0).toLocaleString("en-US", { minimumFractionDigits: v % 1 ? 2 : 0, maximumFractionDigits: 2 });
const CAT_NAMES = { housing: "🏠 Rent / mortgage", utilities: "💡 Utilities & phone", food: "🛒 Food & groceries", transport: "🚗 Car & gas",
  insurance: "🛡 Insurance", debt: "💳 Debt payments", fun: "🎉 Fun & eating out", other: "📦 Everything else" };

let bank = null, bankPreview = false, budTab = "mine";
async function loadMoney() {
  try { mn = await api("/api/money"); } catch (err) { return toast(err.message); }
  drawMoney();
  loadBank();
  loadGrants();
  loadPlan();
}
async function loadBank() {
  try { bank = await api(`/api/money/bank${bankPreview ? "?preview=1" : ""}`); } catch (err) { bank = { state: "error", error: err.message }; }
  drawBank();
}
async function mnPost(path, body, msg) {
  try { mn = await post(path, body); drawMoney(); if (msg) toast(msg); return true; } catch (err) { toast(err.message); return false; }
}
// who's in a pot: can't see it / can add money / can edit
function accessPicker(access, starter) {
  const opts = [["", "🚫 Can't see it"], ["add", "➕ Can add money"], ["edit", "✏️ Can edit"]];
  const people = mn.people.filter((x) => x.username !== starter);
  if (!people.length) return "";
  return `<b class="mn-access-h">Who's in</b>` + people.map((x) => `<label class="mn-line"><span>${esc(x.name)}</span>
    <select data-access="${esc(x.username)}">${opts.map(([v, n]) => `<option value="${v}" ${(access[x.username] || "") === v ? "selected" : ""}>${n}</option>`).join("")}</select></label>`).join("")
    + `<small class="muted">People who can't see it won't know it exists - good for a surprise.</small>`;
}
const readAccess = (root) => Object.fromEntries([...root.querySelectorAll("[data-access]")].filter((sel) => sel.value).map((sel) => [sel.dataset.access, sel.value]));
function mnBar(pct, cls = "") { return `<div class="mn-bar ${cls}"><i style="width:${Math.max(0, Math.min(100, pct))}%"></i></div>`; }

// 📈 charts of real spending. One measure each -> one accent hue; bars labeled with values; hover shows the exact number.
function hbars(rows, total) {   // horizontal bars, biggest first
  const max = Math.max(1, ...rows.map((r) => r[1]));
  return rows.map(([name, v]) => `<div class="hb" title="${esc(name)}: ${usd(v)}${total ? ` (${Math.round(v / total * 100)}%)` : ""}">
    <span class="hb-l">${esc(name)}</span><span class="hb-t"><i style="width:${Math.max(2, v / max * 100)}%"></i></span><b class="hb-v">${usd(v)}</b></div>`).join("");
}
function weekBars(weeks, cap) {   // last 10 weeks, Monday-start; dashed line = a "good week" (needs + fun, about $450)
  const W = 300, H = 120, pad = 18, bw = (W - 8) / weeks.length - 4, max = Math.max(cap * 3, ...weeks.map((w) => w[1])) * 1.08;
  const y = (v) => H - pad - v / max * (H - pad - 6), good = 450;
  const bars = weeks.map(([d, v], i) => { const x = 4 + i * (bw + 4), top = y(v), last = i === weeks.length - 1;
    return `<g class="wb"><title>Week of ${d}: ${usd(v)}${last ? " (so far)" : ""}</title><rect x="${x}" y="${top}" width="${bw}" height="${Math.max(0, H - pad - top)}" rx="4" class="${last ? "now" : v > good * 1.5 ? "high" : ""}"/>
      <text x="${x + bw / 2}" y="${H - 4}" text-anchor="middle">${d.slice(5).replace("-", "/")}</text></g>`; }).join("");
  return `<svg class="week-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Spending per week, last 10 weeks">
    ${bars}<line x1="0" x2="${W}" y1="${y(good)}" y2="${y(good)}" class="goodline"/></svg>`;
}
function spendCharts(b) {
  const sp = b.spend; if (!sp) return "";
  return `<div class="bud-charts">
    <div class="card"><h4>🧾 Where this month's money went <small class="muted">${usd(sp.month_total)} so far</small></h4>${hbars(sp.by_category, sp.month_total)}</div>
    <div class="card"><h4>📅 Spending per week <small class="muted">last 10 weeks</small></h4>${weekBars(sp.weekly, sp.fun_week_cap)}
      <small class="muted">Taller = more spent. The green dashed line is a good week (~$450: needs + fun money). Lighter bar = this week so far.</small></div>
    <div class="card"><h4>🏪 Where you spend most <small class="muted">this month</small></h4>${hbars(sp.by_merchant, sp.month_total)}</div>
  </div>`;
}
let budWallet = null;
function walletDetail(w, b) {
  const lim = w.limit, used = lim ? Math.max(0, w.balance) / lim * 100 : null;
  return `<div class="card bud-wd">
    <div class="bud-card-top"><b>💳 ${esc(w.name)} •• ${esc(w.last4)}</b>${w.not_mine ? `<small class="muted">someone else pays this one</small>` : ""}</div>
    <div class="bud-wd-grid">
      <div><small class="muted">Spent since payday</small><b>${usd(w.spent_since_payday)}</b></div>
      <div><small class="muted">Spent this month</small><b>${usd(w.spent_month)}</b></div>
      <div><small class="muted">Balance now</small><b>${usd(w.balance)}</b></div>
      <div><small class="muted">Left to spend</small><b class="${w.left != null && w.left < 100 ? "down" : ""}">${w.left != null ? usd(w.left) : "no preset limit"}</b></div>
    </div>
    ${used != null ? mnBar(used, utilClass(used)) + `<small class="muted">${Math.round(used)}% of the ${usd(lim)} limit used</small>` : `<small class="muted">Add its limit and this shows how much is left.</small>`}
  </div>`;
}
document.addEventListener("click", (e) => {
  const c = e.target.closest("[data-wcard]");
  if (!c) return;
  const i = +c.dataset.wcard; budWallet = budWallet === i ? null : i; drawMyBudget();
});
function drawMyBudget() {   // 📊 from the budget coach (status.budget) - debt plan, cards, categories, goals, investments
  const b = status && status.budget, box = $("mn-mybudget");
  if (!box) return;
  if (!b) { box.innerHTML = ""; return; }
  const cards = Object.entries(b.balances || {}).map(([n, bal]) => {
    const lim = b.limits && b.limits[n], u = b.utilization && b.utilization[n];
    return `<div class="bud-card"><div class="bud-card-top"><b>${b.plan && b.plan.target === n ? "🎯 " : ""}${esc(n)}</b><span>${usd(bal)}${lim ? ` <small class="muted">of ${usd(lim)}</small>` : ""}</span></div>
      ${u != null ? mnBar(u, utilClass(u)) + `<small class="muted">${u}% used${u >= 30 ? " · goal: under 30%" : " ✅"}</small>` : ""}</div>`;
  }).join("");
  const groups = (b.groups || []).map((g) => {
    const rows = g.cats.filter((c) => c.budgeted || c.spent).map((c) => {
      const pct = c.budgeted ? c.spent / c.budgeted * 100 : (c.spent ? 100 : 0);
      return `<div class="bud-cat"><div class="bud-card-top"><span>${esc(c.name)}</span><span>${usd(c.spent)} <small class="muted">/ ${usd(c.budgeted)}</small></span></div>${mnBar(pct, pct > 100 ? "low" : pct >= 80 ? "ok" : "good")}</div>`;
    }).join("");
    const waiting = g.cats.filter((c) => !c.budgeted && !c.spent).map((c) => esc(c.name));
    return `<div class="card bud-group"><h4>${esc(g.name)}</h4>${rows || ""}${waiting.length ? `<small class="muted">Waiting for later: ${waiting.join(" · ")}</small>` : ""}</div>`;
  }).join("");
  const inv = (b.investments || []).reduce((s, a) => s + a.balance, 0) + (b.coinbase_total || 0);
  box.innerHTML = `<div class="card bud-top">
      <div class="bud-row"><div><h3>📊 My budget <small class="muted">${esc(b.month || "")}</small></h3>
        <div class="bud-big">${usd(b.debt)} <small class="muted">card debt</small></div></div>${debtSpark(b.debt_hist, 220, 48)}</div>
      ${mnBar(b.debt_start ? (b.debt_start - b.debt) / b.debt_start * 100 : 0, "good")}
      <small class="muted">Plan every payday: extra to ${esc(b.plan && b.plan.target || "the target card")} · fun money ${usd(b.fun_cap)}</small>
      <div class="bud-cards">${cards}</div>
      ${(b.wallet || []).length ? `<h4 class="bud-wallet-h">💳 Card wallet <small class="muted">tap a card</small></h4>
        <div class="bud-wallet">${b.wallet.map((w, i) => `<button class="bud-wcard ${w.not_mine ? "notmine" : ""} ${budWallet === i ? "on" : ""}" data-wcard="${i}">
          <b>${esc(w.name.replace(/\(TM\)|TM/g, "").trim())}</b><small>•• ${esc(w.last4)}</small></button>`).join("")}</div>
        <div id="bud-wdetail">${budWallet != null && b.wallet[budWallet] ? walletDetail(b.wallet[budWallet], b) : ""}</div>` : ""}
      <div class="bud-chips">${b.food ? `<span class="bud-chip ${b.food.week_left < 0 ? "low" : b.food.week_left < 30 ? "ok" : "good"}">🍔 Food this week: <b>${usd(Math.max(0, b.food.week_left))}</b> left of ${usd(b.food.per_week)}${b.food.week_left < 0 ? ` (${usd(-b.food.week_left)} over)` : ""} <small class="muted">${(b.food.meals || []).map(([m, v]) => `${m.split(" ")[0]} ~$${v}`).join(" · ")}</small></span>`
        + (b.food.pots && (b.food.pots.weekend || b.food.pots.purchase || b.food.pots.invest || b.food.pots.debt || b.food.pots.purchase_total) ? `<span class="bud-chip good">🍔 Food savings: ${[["🎉", b.food.pots.weekend], ["🎯", b.food.pots.purchase + (b.food.pots.purchase_total || 0)], ["📈", b.food.pots.invest], ["💳", b.food.pots.debt]].filter(([, v]) => v).map(([e, v]) => `${e} <b>${usd(v)}</b>`).join(" · ")}</span>` : "") : ""}<span class="bud-chip ${b.fun_spent > b.fun_cap ? "low" : b.fun_spent >= .75 * b.fun_cap ? "ok" : "good"}">🎉 Fun money since ${esc(b.since_payday || "payday")}: <b>${usd(b.fun_spent)}</b> / ${usd(b.fun_cap)}</span>
        <span class="bud-chip">📈 Investments + crypto: <b>${usd(inv)}</b> <small class="muted">(separate - never used for debt)</small></span>
        </div>
      ${b.budget_url ? `<a class="small-btn" href="${esc(b.budget_url)}" target="_blank" rel="noopener">Open the full budget app ↗</a>` : ""}
    </div>${(b.targets || []).length ? `<div class="card bud-targets"><h4>🎯 My targets</h4>${b.targets.map((t) => `<div class="bud-cat"><div class="bud-card-top"><span>${esc(t.label)}</span><span><b>${usd(t.now)}</b> <small class="muted">/ ${t.low && t.low !== t.goal ? `${usd(t.low)}-` : ""}${usd(t.goal)}</small></span></div>${mnBar(t.now / t.goal * 100, t.now >= (t.low || t.goal) ? "good" : "ok")}<small class="muted">${esc(t.note)}</small></div>`).join("")}</div>` : ""}${(b.roadmap || []).length ? `<div class="card bud-road"><h4>🛡 Insurance roadmap <small class="muted">each step unlocks from your real balances</small></h4>
      ${b.roadmap.map((r, i) => `<details class="road-step ${r.eligible ? "on" : ""}" ${r.eligible && i === b.roadmap.findIndex((x) => x.eligible) ? "open" : ""}>
        <summary><span class="road-dot">${r.eligible ? "✅" : "🔒"}</span><b>${esc(r.title)}</b><small class="muted">${esc(r.unlock)}</small></summary>
        <div class="road-body"><div>💵 <b>Budget:</b> ${esc(r.budget)}</div><div>📞 <b>Who to contact:</b> ${esc(r.who)}</div>
          <div>❓ <b>Ask them:</b><ul>${r.ask.map((q) => `<li>${esc(q)}</li>`).join("")}</ul></div></div></details>`).join("")}
      ${(b.broker_notes || []).length ? `<details class="road-step on broker"><summary><span class="road-dot">📝</span><b>Bring this to the broker</b><small class="muted">tap to open in the meeting</small></summary>
        <ol class="road-body">${b.broker_notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ol></details>` : ""}</div>` : ""}${spendCharts(b)}<div class="bud-groups">${groups}</div>`;
}
function drawMoney() {
  drawMyBudget();
  $("mn-health").hidden = !!(status && status.budget);   // the manual money check - replaced by real numbers above
  const h = mn.health;
  $("mn-health").innerHTML = h.score === null
    ? `<h3>🩺 Money check</h3><p class="muted small">Fill in <b>My month</b> at the bottom (just income and a few rough numbers) and you'll see where you're strong and where you're short - updated every time something changes.</p>`
    : `<div class="mn-score ${h.score >= 75 ? "good" : h.score >= 45 ? "ok" : "low"}"><b>${h.score}</b><small>/100</small></div>
       <div class="mn-checks"><h3>🩺 Money check</h3>${h.checks.map((c) => `<div class="mn-check"><div class="mn-check-top"><span>${esc(c.title)}</span><small>${c.score >= 75 ? "💪" : c.score >= 45 ? "👀" : "⚠️"}</small></div>
         ${mnBar(c.score, c.score >= 75 ? "good" : c.score >= 45 ? "ok" : "low")}<small class="muted">${esc(c.detail)}</small></div>`).join("")}</div>`;
  // family pots
  $("mn-pot-form").hidden = !mn.can_pots;
  $("mn-pots").innerHTML = mn.pots.length ? mn.pots.map((p) => `<div class="card mn-pot" data-pot="${p.id}">
      <div class="mn-pot-head"><b>${esc(p.emoji)} ${esc(p.name)}</b><small class="muted">${p.role === "edit" ? "" : "you can add"}</small></div>
      <div class="mn-big">${usd(p.total)}${p.goal ? ` <small class="muted">of ${usd(p.goal)}</small>` : ""}</div>
      ${p.goal ? mnBar(p.total / p.goal * 100, "good") : ""}
      ${mn.can_pots ? (p.kind === "jar"
        ? `<div class="mn-row"><select data-pot-who>${mn.people.filter((x) => x.username === p.by || (p.access || {})[x.username]).map((x) => `<option value="${esc(x.username)}" ${status.me && status.me.username === x.username ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select>
            <button class="accent-btn small-btn" data-pot-fine="${p.fine || 1}">🤬 +${usd(p.fine || 1)}</button></div>`
        : `<div class="mn-row"><input data-pot-amount inputmode="decimal" placeholder="$"><input data-pot-note maxlength="60" placeholder="note (optional)"><button class="accent-btn small-btn" data-pot-add>Add</button></div>`) : ""}
      ${p.leaders.length ? `<small class="muted">${p.kind === "jar" ? "🏆 Potty mouths: " : "Put in: "}${p.leaders.map((l) => `${esc(l.name)} ${usd(l.amount)}`).join(" · ")}</small>` : `<small class="muted">Started by ${esc(p.by_name)}</small>`}
      ${p.log.length ? `<details class="mn-log"><summary>History</summary>${p.log.map((l) => `<div><span>${l.amount < 0 ? "💸" : "➕"} ${usd(Math.abs(l.amount))}${l.note ? " - " + esc(l.note) : ""}</span><small class="muted">${esc((mn.people.find((x) => x.username === l.who) || {}).name || l.who)} · ${new Date(l.at * 1000).toLocaleDateString([], { month: "short", day: "numeric" })}</small></div>`).join("")}
        ${p.can_edit ? `<div class="mn-row"><input data-pot-spend inputmode="decimal" placeholder="Spent $"><input data-pot-spend-note maxlength="60" placeholder="on what?"><button class="small-btn" data-pot-take>Take out</button></div>` : ""}</details>` : ""}
      ${p.can_edit ? `<details class="mn-log mn-edit"><summary>✏️ Edit</summary>
        <div class="mn-row"><input data-pe-emoji class="mn-emoji" maxlength="8" value="${esc(p.emoji)}"><input data-pe-name maxlength="40" value="${esc(p.name)}"></div>
        <div class="mn-row">${p.kind === "jar" ? `<input data-pe-fine inputmode="decimal" value="${p.fine || 1}" placeholder="Fine $">` : `<input data-pe-goal inputmode="decimal" value="${p.goal || ""}" placeholder="Goal $">`}</div>
        <div class="mn-access">${accessPicker(p.access || {}, p.by)}</div>
        <div class="mn-row"><button class="accent-btn small-btn" data-pot-save>Save</button>${p.can_remove ? `<button class="link-btn" data-pot-remove>remove pot</button>` : ""}</div></details>` : ""}
    </div>`).join("") : `<p class="muted small">No pots yet. Start one below - a swear jar is a fun first one 🤬</p>`;
  if (!$("mn-pot-form").open || !$("mn-pot-access").innerHTML) $("mn-pot-access").innerHTML = accessPicker(Object.fromEntries(mn.people.map((x) => [x.username, "add"])), mn.me);
  // goals
  $("mn-goals").innerHTML = mn.goals.length ? mn.goals.map((g) => `<div class="card mn-pot" data-goal="${g.id}">
      <div class="mn-pot-head"><b>${esc(g.emoji)} ${esc(g.name)}</b><button class="link-btn" data-goal-remove>remove</button></div>
      <div class="mn-big">${usd(g.saved)} <small class="muted">of ${usd(g.target)}${g.due ? " by " + new Date(g.due + "T12:00").toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" }) : ""}</small></div>
      ${mnBar(g.target ? g.saved / g.target * 100 : 0, g.saved >= g.target ? "good" : "")}
      <div class="mn-row"><input data-goal-amount inputmode="decimal" placeholder="$"><button class="accent-btn small-btn" data-goal-add>＋ Put in</button><button class="small-btn" data-goal-take>－ Took out</button></div>
    </div>`).join("") : `<p class="muted small">No goals yet - what are you saving for?</p>`;
  // subscriptions
  $("mn-sub-total").textContent = mn.subs.length ? `${usd(h.monthly_subs)}/mo · ${usd(h.yearly_subs)}/yr` : "";
  $("mn-subs").innerHTML = mn.subs.length ? mn.subs.map((s) => `<div class="mn-sub" data-sub="${s.id}"><span><b>${esc(s.name)}</b>
      <small class="muted">${usd(s.amount)} ${s.cycle}${s.next ? " · next " + new Date(s.next + "T12:00").toLocaleDateString([], { month: "short", day: "numeric" }) : ""}</small></span>
      <button class="link-btn" data-sub-remove>cancel it</button></div>`).join("")
    : `<p class="muted small">Add what you pay for every month or year - it's easy to forget the small ones.</p>`;
  drawBudget();
  if (typeof drawSubsLink === "function") drawSubsLink();
  if (typeof drawSortLink === "function") drawSortLink();
  if (typeof drawBigGoals === "function") drawBigGoals();
}

function drawBudget() {
  const shared = mn.shared_budgets || [];
  if (budTab !== "mine" && budTab !== "new" && !shared.find((x) => x.id === budTab)) budTab = "mine";
  $("mn-bud-tabs").innerHTML = `<button data-bud-tab="mine" class="${budTab === "mine" ? "on" : ""}">🔒 Mine</button>`
    + shared.map((x) => `<button data-bud-tab="${x.id}" class="${budTab === x.id ? "on" : ""}">${esc(x.emoji)} ${esc(x.name)}</button>`).join("")
    + (mn.can_pots ? `<button data-bud-tab="new" class="${budTab === "new" ? "on" : ""}">＋ Shared budget</button>` : "");
  const numbers = (b, ro) => `<label class="mn-line"><span>💵 Take-home pay</span><input data-bud="income" inputmode="decimal" value="${b.income || ""}" placeholder="$ per month" ${ro}></label>
    ${mn.categories.map((c) => `<label class="mn-line"><span>${CAT_NAMES[c] || c}</span><input data-bud-cat="${c}" inputmode="decimal" value="${(b.spending || {})[c] || ""}" placeholder="$" ${ro}></label>`).join("")}
    <label class="mn-line"><span>🛟 Savings you could use in an emergency</span><input data-bud="cushion" inputmode="decimal" value="${b.cushion ?? ""}" placeholder="$ total" ${ro}></label>`;
  if (budTab === "mine" && status && status.budget && (status.budget.groups || []).length) {
    const b = status.budget;
    $("mn-budget").innerHTML = `<p class="muted small">🏦 Your real budget for ${esc(b.month || "this month")} - from your bank and card transactions, sorted automatically. Change the amounts in the budget app.</p>`
      + b.groups.map((g) => `<h4 class="bud-mine-h">${esc(g.name)}</h4><table class="bud-table"><tr><th></th><th>Budget</th><th>Spent</th><th>Left</th></tr>`
        + g.cats.map((c) => `<tr><td>${esc(c.name)}</td><td>${usd(c.budgeted)}</td><td>${usd(c.spent)}</td><td class="${c.left < 0 ? "down" : c.budgeted ? "up" : "muted"}">${usd(c.left)}</td></tr>`).join("")
        + `</table>`).join("")
      + (b.budget_url ? `<a class="small-btn" href="${esc(b.budget_url)}" target="_blank" rel="noopener">Change amounts in the budget app ↗</a>` : "");
    return;
  }
  if (budTab === "mine") {
    $("mn-budget").innerHTML = (mn.health_from_bank ? `<p class="mn-note">🏦 Your money check is using your bank's real numbers. These are your own numbers - switch in the bank card to use them instead.</p>` : "")
      + `<p class="muted small">Only you see this. Rough monthly numbers are fine - subscriptions above are counted for you.</p>${numbers(mn.budget || {}, "")}
      <button class="accent-btn" data-bud-save="mine">Save my month</button>`;
    return;
  }
  if (budTab === "new") {
    $("mn-budget").innerHTML = `<p class="muted small">A budget you share - like the house budget with your partner. Everyone still has their own private one too.</p>
      <div class="mn-row"><input id="mn-sb-emoji" class="mn-emoji" maxlength="8" placeholder="👫"><input id="mn-sb-name" maxlength="40" placeholder="House budget, Our trip, Kids…"></div>
      <div class="mn-access">${budgetMembers({}, mn.me)}</div>${numbers({}, "")}
      <button class="accent-btn" data-bud-save="new">Make it</button>`;
    return;
  }
  const x = shared.find((y) => y.id === budTab), ro = x.role === "edit" ? "" : "disabled", h = x.health;
  $("mn-budget").innerHTML = `<p class="muted small">${x.by === mn.me ? "You made this" : `Made by ${esc(x.by_name)}`} · ${Object.keys(x.members).length + 1} people${x.updated_by ? ` · last changed by ${esc(x.updated_by)}` : ""}${x.role === "edit" ? "" : " · you can see it"}</p>
    ${h.score !== null ? `<div class="mn-mini-check"><b class="${h.score >= 75 ? "good" : h.score >= 45 ? "ok" : "low"}">${h.score}/100</b> ${h.checks.map((c) => `<span>${c.score >= 75 ? "💪" : c.score >= 45 ? "👀" : "⚠️"} ${esc(c.title)}</span>`).join("")}</div>` : ""}
    ${x.by === mn.me ? `<details class="mn-log"><summary>👥 Who's in</summary><div class="mn-access">${budgetMembers(x.members, x.by)}</div></details>` : ""}
    ${numbers(x.budget, ro)}
    ${x.role === "edit" ? `<button class="accent-btn" data-bud-save="${x.id}">Save</button>` : ""}${x.can_remove ? ` <button class="link-btn" data-bud-remove="${x.id}">remove budget</button>` : ""}`;
}
function budgetMembers(members, starter) {
  const opts = [["", "🚫 Not in it"], ["view", "👀 Can see it"], ["edit", "✏️ Can edit"]];
  return `<b class="mn-access-h">Who's in</b>` + mn.people.filter((p) => p.username !== starter).map((p) => `<label class="mn-line"><span>${esc(p.name)}</span>
    <select data-access="${esc(p.username)}">${opts.map(([v, n]) => `<option value="${v}" ${(members[p.username] || "") === v ? "selected" : ""}>${n}</option>`).join("")}</select></label>`).join("");
}
function readBudget() {
  return { income: document.querySelector('#mn-budget [data-bud="income"]').value.trim(), cushion: document.querySelector('#mn-budget [data-bud="cushion"]').value.trim(),
    spending: Object.fromEntries([...document.querySelectorAll("#mn-budget [data-bud-cat]")].map((i) => [i.dataset.budCat, i.value.trim()])) };
}

// ----- 🏦 the bank (SimpleFIN) - off until connected; "preview" shows SimpleFIN's sample bank -----
const BANK_CATS = ["housing", "utilities", "food", "transport", "insurance", "debt", "fun", "subscriptions", "other", "income", "transfer"];
const CAT_SHORT = { housing: "🏠 Housing", utilities: "💡 Utilities", food: "🛒 Food", transport: "🚗 Car & gas", insurance: "🛡 Insurance", debt: "💳 Debt",
  fun: "🎉 Fun & eating out", subscriptions: "🔁 Subscriptions", other: "📦 Other", income: "💵 Money in", transfer: "↔️ Transfer" };
function drawBank() {
  const box = $("mn-bank");
  if (status && status.budget) { box.innerHTML = ""; return; }   // the real budget (📊 My budget) replaces the sample/manual bank card
  $("mn-intro").textContent = bank && bank.state === "on" ? "Your bank numbers, goals, subscriptions and budget are only yours. Family pots and shared budgets are for the people you pick."
    : "Your goals, subscriptions and budget are only yours. Family pots and shared budgets are for the people you pick. You type the numbers in - no bank is connected.";
  if (!bank || bank.state === "off") {
    box.innerHTML = bank && bank.can_connect ? `<div class="card mn-bank-off"><div><b>🏦 Bank: not connected</b>
      <p class="muted small">Link your bank (read-only, through SimpleFIN) and this page fills itself in - balances, spending by month and category, and your subscriptions found for you. Nothing to type twice. Ready when you are: 🛠 Build requests → 🔑 Needs your OK.</p></div>
      <button class="small-btn" data-bank-preview>👀 Preview with a sample bank</button></div>` : "";
    return;
  }
  if (bank.state === "error") { box.innerHTML = `<div class="card"><b>🏦 Bank</b><p class="muted small">${esc(bank.error)}</p></div>`; return; }
  const sample = bank.state === "preview";
  const synced = bank.synced_at ? new Date(bank.synced_at * 1000).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : "";
  const max = Math.max(1, ...bank.months.map((m) => m.spent));
  const catMax = Math.max(1, ...bank.by_category.map((c) => c.amount));
  const W = 320, H = 150, bw = 34, gap = (W - bank.months.length * bw) / (bank.months.length + 1);
  const bars = bank.months.map((m, i) => {
    const h = Math.max(2, (m.spent / max) * (H - 34)), x = gap + i * (bw + gap), y = H - 20 - h;
    return `<g class="mn-barg" data-tip="${esc(m.month)}${m.partial ? " (so far)" : ""}: spent ${usd(m.spent)} · money in ${usd(m.income)}">
      <rect x="${x - gap / 2}" y="0" width="${bw + gap}" height="${H}" fill="transparent"/>
      <path d="M${x},${H - 20} V${y + 4} q0,-4 4,-4 h${bw - 8} q4,0 4,4 V${H - 20} z" class="mn-bar-fill ${m.partial ? "partial" : ""}"/>
      <text x="${x + bw / 2}" y="${H - 5}" text-anchor="middle" class="mn-axis">${esc(m.month)}</text></g>`;
  }).join("");
  box.innerHTML = `<div class="card mn-bankcard">
    <div class="mn-pot-head"><b>🏦 ${sample ? "Sample bank" : "Your bank"} ${sample ? `<span class="mn-sample">SAMPLE - not your money</span>` : ""}</b>
      ${sample ? `<button class="link-btn" data-bank-preview-off>close preview</button>` : `<button class="link-btn" data-bank-sync>sync now</button>`}</div>
    <div class="mn-tiles">${[["Everything together", bank.net], ["Cash", bank.cash], ["Savings", bank.savings]].map(([n, v]) =>
      `<div title="${usd(v)}"><small class="muted">${n}</small><b>${usd(Math.round(v))}</b></div>`).join("")}</div>
    <details class="mn-log"><summary>${bank.accounts.length} account${bank.accounts.length === 1 ? "" : "s"}${synced ? ` · updated ${synced}` : ""}</summary>
      ${bank.accounts.map((a) => `<div><span>${esc(a.org)} · ${esc(a.name)}</span><b>${usd(a.balance)}</b></div>`).join("")}</details>
    ${bank.errors.length ? `<p class="muted small">⚠️ ${bank.errors.map(esc).join(" · ")}</p>` : ""}
    ${!sample ? `<label class="toggle mn-usebank"><input type="checkbox" data-bank-use ${bank.use_bank ? "checked" : ""}> Money check uses these real numbers</label>` : ""}
    <h4 class="mn-chart-h">Spent each month</h4>
    <div class="mn-chart"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Spending per month">
      <line x1="0" x2="${W}" y1="${H - 20}" y2="${H - 20}" class="mn-base"/>${bars}</svg><div class="mn-tip" hidden></div></div>
    <details class="mn-log"><summary>See as a table</summary>${bank.months.map((m) => `<div><span>${esc(m.month)}${m.partial ? " (so far)" : ""}</span><span>spent ${usd(m.spent)} · in ${usd(m.income)}</span></div>`).join("")}</details>
    <h4 class="mn-chart-h">This month by category</h4>
    ${bank.by_category.length ? bank.by_category.map((c) => `<div class="mn-hbar"><span>${CAT_SHORT[c.cat] || c.cat}</span><div class="mn-bar"><i style="width:${c.amount / catMax * 100}%"></i></div><b>${usd(c.amount)}</b></div>`).join("")
      : `<p class="muted small">Nothing spent yet this month.</p>`}
    ${bank.recurring.length ? `<h4 class="mn-chart-h">🔁 Repeating charges we found</h4>${bank.recurring.map((r) => `<div class="mn-sub"><span><b>${esc(r.name)}</b><small class="muted">${usd(r.amount)} ${r.cycle} · next ~${new Date(r.next + "T12:00").toLocaleDateString([], { month: "short", day: "numeric" })}</small></span>
      ${sample ? "" : `<button class="small-btn" data-bank-addsub="${esc(r.key)}">＋ Subscriptions</button>`}</div>`).join("")}` : ""}
    <details class="mn-log mn-tx"><summary>Recent transactions</summary><input data-bank-search placeholder="🔎 Search" class="mn-search">
      <div data-bank-list>${bankRows(bank.recent)}</div></details>
  </div>`;
}
function bankRows(rows) {
  return rows.slice(0, 80).map((t) => `<div class="mn-txrow"><span><b>${esc(t.payee && t.payee !== "You" ? t.payee : t.desc)}</b><small class="muted">${new Date(t.posted * 1000).toLocaleDateString([], { month: "short", day: "numeric" })}${t.pending ? " · pending" : ""}</small></span>
    <select data-bank-cat="${esc(t.key)}" title="Always file this place under…">${BANK_CATS.map((c) => `<option value="${c}" ${t.cat === c ? "selected" : ""}>${CAT_SHORT[c]}</option>`).join("")}</select>
    <b class="${t.amount > 0 ? "good" : ""}">${t.amount > 0 ? "+" : ""}${usd(t.amount)}</b></div>`).join("");
}
$("mn-bank").addEventListener("click", async (e) => {
  if (e.target.closest("[data-bank-preview]")) { bankPreview = true; $("mn-bank").innerHTML = `<div class="card"><p class="muted">Opening the sample bank…</p></div>`; return loadBank(); }
  if (e.target.closest("[data-bank-preview-off]")) { bankPreview = false; return loadBank(); }
  if (e.target.closest("[data-bank-sync]")) { try { bank = await post("/api/money/bank", { sync: true }); drawBank(); mn = await api("/api/money"); drawMoney(); toast("🏦 Up to date"); } catch (err) { toast(err.message); } return; }
  const add = e.target.closest("[data-bank-addsub]");
  if (add) {
    const r = bank.recurring.find((x) => x.key === add.dataset.bankAddsub);
    if (await mnPost("/api/money/sub", { name: r.name, amount: r.amount, cycle: r.cycle, next: r.next }, "🔁 Added to your subscriptions")) loadBank();
  }
});
$("mn-bank").addEventListener("change", async (e) => {
  if (e.target.matches("[data-bank-use]")) { await post("/api/money/bank", { use_bank: e.target.checked }); mn = await api("/api/money"); drawMoney(); toast(e.target.checked ? "Using your bank's numbers" : "Using the numbers you typed"); }
  if (e.target.matches("[data-bank-cat]")) {
    try { bank = await post("/api/money/bank", { rule: { key: e.target.dataset.bankCat, cat: e.target.value }, preview: bankPreview }); drawBank(); toast("📂 Got it - that place goes there from now on"); } catch (err) { toast(err.message); }
  }
});
$("mn-bank").addEventListener("input", (e) => {
  if (!e.target.matches("[data-bank-search]")) return;
  const q = e.target.value.toLowerCase();
  $("mn-bank").querySelector("[data-bank-list]").innerHTML = bankRows(bank.recent.filter((t) => `${t.payee} ${t.desc} ${t.cat}`.toLowerCase().includes(q)));
});
$("mn-bank").addEventListener("pointerover", (e) => {
  const g = e.target.closest(".mn-barg"), tip = $("mn-bank").querySelector(".mn-tip");
  if (!tip) return;
  if (!g) { tip.hidden = true; return; }
  tip.textContent = g.dataset.tip; tip.hidden = false;
});
$("mn-bank").addEventListener("pointerleave", () => { const tip = $("mn-bank").querySelector(".mn-tip"); if (tip) tip.hidden = true; }, true);

$("panel-money").addEventListener("click", async (e) => {
  const tab = e.target.closest("[data-bud-tab]");
  if (tab) { budTab = tab.dataset.budTab; return drawBudget(); }
  const bs = e.target.closest("[data-bud-save]");
  if (bs) {
    const which = bs.dataset.budSave;
    if (which === "mine") return mnPost("/api/money/budget", readBudget(), "📊 Saved - check your money check up top");
    if (which === "new") {
      const ok = await mnPost("/api/money/shared-budget", { name: $("mn-sb-name").value, emoji: $("mn-sb-emoji").value, members: readAccess($("mn-budget")), ...readBudget() }, "👫 Shared budget made");
      if (ok) { budTab = mn.shared_budgets[mn.shared_budgets.length - 1].id; drawBudget(); }
      return;
    }
    const x = mn.shared_budgets.find((y) => y.id === which);
    return mnPost("/api/money/shared-budget", { id: which, ...(x.by === mn.me ? { members: readAccess($("mn-budget")) } : {}), ...readBudget() }, "📊 Saved for everyone in it");
  }
  const br = e.target.closest("[data-bud-remove]");
  if (br) {
    if (!br.dataset.sure) { br.dataset.sure = 1; br.textContent = "tap again to remove"; return; }
    budTab = "mine"; return mnPost("/api/money/shared-budget", { id: br.dataset.budRemove, remove: true }, "Removed");
  }
});
$("panel-money").addEventListener("click", async (e) => {
  const pot = e.target.closest("[data-pot]"), goal = e.target.closest("[data-goal]"), sub = e.target.closest("[data-sub]");
  const val = (sel, root) => root.querySelector(sel).value.trim();
  if (pot) {
    const id = pot.dataset.pot;
    if (e.target.closest("[data-pot-fine]")) return mnPost("/api/money/pot/add", { id, amount: e.target.closest("[data-pot-fine]").dataset.potFine, who: val("[data-pot-who]", pot), note: "🤬" }, "🤬 Into the jar!");
    if (e.target.closest("[data-pot-add]")) return mnPost("/api/money/pot/add", { id, amount: val("[data-pot-amount]", pot), note: val("[data-pot-note]", pot) }, "➕ Added");
    if (e.target.closest("[data-pot-take]")) return mnPost("/api/money/pot/add", { id, amount: -Math.abs(parseFloat(val("[data-pot-spend]", pot)) || 0), note: val("[data-pot-spend-note]", pot) }, "💸 Taken out");
    if (e.target.closest("[data-pot-save]")) {
      const g = pot.querySelector("[data-pe-goal]"), f = pot.querySelector("[data-pe-fine]"), cur = mn.pots.find((x) => x.id === id);
      return mnPost("/api/money/pot", { id, name: val("[data-pe-name]", pot), emoji: val("[data-pe-emoji]", pot), kind: cur.kind,
        goal: g ? g.value : cur.goal, fine: f ? f.value : cur.fine, access: readAccess(pot) }, "✏️ Saved");
    }
    if (e.target.closest("[data-pot-remove]")) {
      const b = e.target.closest("[data-pot-remove]");
      if (!b.dataset.sure) { b.dataset.sure = 1; b.textContent = "tap again"; return; }
      return mnPost("/api/money/pot", { id, remove: true }, "Removed");
    }
  }
  if (goal) {
    const id = goal.dataset.goal, amt = parseFloat(val("[data-goal-amount]", goal));
    if (e.target.closest("[data-goal-add]") && amt) return mnPost("/api/money/goal", { id, add: Math.abs(amt) }, "🎯 Nice!");
    if (e.target.closest("[data-goal-take]") && amt) return mnPost("/api/money/goal", { id, add: -Math.abs(amt) });
    if (e.target.closest("[data-goal-remove]")) {
      const b = e.target.closest("[data-goal-remove]");
      if (!b.dataset.sure) { b.dataset.sure = 1; b.textContent = "tap again"; return; }
      return mnPost("/api/money/goal", { id, remove: true });
    }
  }
  if (sub && e.target.closest("[data-sub-remove]")) {
    const b = e.target.closest("[data-sub-remove]");
    if (!b.dataset.sure) { b.dataset.sure = 1; b.textContent = "remove from list?"; return; }
    return mnPost("/api/money/sub", { id: sub.dataset.sub, remove: true }, "Removed - don't forget to cancel it with them too");
  }
  if (e.target.closest("#mn-pot-save")) {
    const access = readAccess($("mn-pot-access")), everyone = mn.people.filter((x) => x.username !== mn.me).every((x) => access[x.username]);
    if (await mnPost("/api/money/pot", { name: $("mn-pot-name").value, emoji: $("mn-pot-emoji").value, kind: $("mn-pot-kind").value, goal: $("mn-pot-goal").value, fine: $("mn-pot-fine").value, access },
                     everyone ? "👪 Pot started - the family chat knows" : "👪 Pot started - only the people you picked can see it"))
      ["mn-pot-name", "mn-pot-emoji", "mn-pot-goal", "mn-pot-fine"].forEach((i) => ($(i).value = "")), ($("mn-pot-form").open = false);
  }
  if (e.target.closest("#mn-goal-save")) {
    if (await mnPost("/api/money/goal", { name: $("mn-goal-name").value, emoji: $("mn-goal-emoji").value, target: $("mn-goal-target").value, saved: $("mn-goal-saved").value, due: $("mn-goal-due").value }, "🎯 Goal added"))
      ["mn-goal-name", "mn-goal-emoji", "mn-goal-target", "mn-goal-saved", "mn-goal-due"].forEach((i) => ($(i).value = "")), ($("mn-goal-form").open = false);
  }
  if (e.target.closest("#mn-sub-save")) {
    if (await mnPost("/api/money/sub", { name: $("mn-sub-name").value, amount: $("mn-sub-amount").value, cycle: $("mn-sub-cycle").value, next: $("mn-sub-next").value }, "🔁 Added"))
      ["mn-sub-name", "mn-sub-amount", "mn-sub-next"].forEach((i) => ($(i).value = "")), ($("mn-sub-form").open = false);
  }
});
$("mn-pot-kind").addEventListener("change", () => { $("mn-pot-fine").hidden = $("mn-pot-kind").value !== "jar"; $("mn-pot-goal").hidden = $("mn-pot-kind").value === "jar"; });

// 🏛 Grants watch (owner only): open federal small-business grants + new IRS/SBA tax-break rules, checked weekly
let grants = null, grantsAll = false;
async function loadGrants() {
  try { grants = await api("/api/grants"); } catch { grants = null; }   // not the owner -> no card
  drawGrants();
}
function drawGrants() {
  const box = $("mn-grants");
  if (!grants) { box.innerHTML = ""; return; }
  const when = grants.last ? new Date(grants.last * 1000).toLocaleDateString([], { month: "short", day: "numeric" }) : null;
  const fresh = grants.items.filter((x) => x.new).length;
  const shown = grantsAll ? grants.items : grants.items.slice(0, 6);
  const row = (x) => `<li><a href="${esc(x.url)}" target="_blank" rel="noopener">${x.new ? "🆕 " : ""}${x.src === "grant" ? "💵" : "📜"} ${esc(x.title)}</a>
    <small class="muted">${esc(x.who)}${x.src === "grant" ? ` · ${esc(x.status)}${x.close ? ` · closes ${esc(x.close)}` : ""}` : ` · ${x.status === "proposed" ? "proposed rule" : "new rule"} ${esc(x.date)}`}</small></li>`;
  box.innerHTML = `<div class="card mn-grants"><b>🏛 Grants watch</b> <small class="muted">${when ? `checked ${when}${fresh ? ` · ${fresh} new` : ""}` : "first check runs soon"}</small>
    <p class="muted small">Once a week: open federal grants small businesses can apply for (Grants.gov) and new IRS/SBA tax rules (Federal Register). Official sources only. Most business grants are research (SBIR) grants, so read who qualifies. Ask a tax preparer before claiming anything.</p>
    ${grants.error ? `<p class="muted small">⚠️ ${esc(grants.error)}</p>` : ""}
    <ul class="mn-grant-list">${shown.map(row).join("") || `<li class="muted small">Nothing yet.</li>`}</ul>
    ${grants.items.length > 6 ? `<button class="link-btn" data-grants-all>${grantsAll ? "show less" : `show all ${grants.items.length}`}</button>` : ""}
    <button class="link-btn" data-grants-check>check now</button></div>`;
}
$("mn-grants").addEventListener("click", async (e) => {
  if (e.target.closest("[data-grants-all]")) { grantsAll = !grantsAll; return drawGrants(); }
  if (e.target.closest("[data-grants-check]")) {
    e.target.textContent = "checking…";
    try { grants = await post("/api/grants", {}); toast("🏛 Grants watch is up to date"); } catch (err) { toast(err.message); }
    drawGrants();
  }
});

// ---------- 🪜 Money plan (owner only): paces, the ladder, 🐷 stash along the way, 🔍 free speed-ups, 🗓 planned costs,
// 🛒 Should I buy this?, 📈 grow income, ⚙️ my numbers. Built from the cards + goals the owner types in (or a budget coach,
// read-only, when there is one) - nothing here moves money.
let plan = null, planCheck = null;
async function loadPlan() {
  try { plan = await api("/api/money/plan"); } catch { plan = null; }   // not the owner -> nothing shown
  drawPlan();
  if (plan && plan.ok) loadPayToday();
}
const pDate = (d) => d ? new Date(d.length === 7 ? d + "-15T12:00" : d + "T12:00").toLocaleDateString([], d.length === 7 ? { month: "short", year: "numeric" } : { month: "short", day: "numeric", year: "numeric" }) : "";
const pDays = (n) => n == null ? "" : n === 0 ? "same day" : `${n} day${n === 1 ? "" : "s"}`;
function planGrowth(g, pick, range) {
  const r = g.pick_range || {};
  const aprs = range ? (Math.round(range[0]) === Math.round(range[1]) ? `${Math.round(range[1])}%` : `${Math.round(range[0])}-${Math.round(range[1])}%`) : "";
  const pickLine = r.kind === "index" ? `<div>🌱 ${usd(g.pick_put_in)} in an index fund could be about <b>${usd(r.bad)}</b> after a bad stretch (−20%/yr), <b>${usd(r.avg)}</b> at the long-run average (~7%/yr after inflation) or <b>${usd(r.good)}</b> in good years (+20%). <small class="muted">History, not a promise.</small></div>`
    : r.kind === "crypto" ? `<div>🪙 ${usd(g.pick_put_in)} in crypto: it can drop 50%+ in a year, so there's no honest average to show.</div>`
    : `<div>🎯 ${usd(g.pick_put_in)} in high-yield savings: about <b>${usd(r.about)}</b> at ~4%. <small class="muted">Rates change.</small></div>`;
  return `<div class="plan-growth"><div>🛟 Cushion: about <b>${usd(g.cushion)}</b> in high-yield savings (~4%, rates change)</div>${g.pick_put_in ? pickLine : ""}
    ${aprs ? `<div>💳 The same dollars on the cards "earn" a <b>guaranteed ${aprs}</b> - the interest you stop paying.</div>` : ""}</div>`;
}
// ⚙️ My numbers: the owner's own cards + goals. Nothing is built in - an empty plan starts here.
function planSetupHtml(setup, open) {
  const S = setup || { cards: [], goals: {} }, g = S.goals || {};
  const val = (v) => v == null ? "" : esc(String(v));
  const cards = (S.cards || []).map((c) => `<li data-pcard="${esc(c.id)}"><span>${c.full ? "🛒" : "💳"} ${esc(c.name)}<small class="muted">${c.full ? "paid in full every payday" : `${c.apr || 0}% APR${c.fixed ? ` · steady ${usd(c.fixed)} each payday` : ""}`}</small></span>
      <span class="mn-row"><input data-pc-bal inputmode="decimal" placeholder="$ balance" value="${val(c.balance)}"><button class="small-btn" data-pc-set>Save</button><button class="link-btn" data-pc-rm>remove</button></span></li>`).join("");
  const num = (k, ph, label) => `<label class="small">${label}<input data-pg="${k}" inputmode="decimal" placeholder="${ph}" value="${val(g[k])}"></label>`;
  return `<div class="card plan"><details ${open ? "open" : ""}><summary><h3 style="display:inline">⚙️ My numbers <small class="muted">your cards + goals - private, on this computer</small></h3></summary>
    ${cards ? `<ul class="plan-speed">${cards}</ul>` : `<p class="muted small">👋 Add your first card below - the name on it, what you owe and its interest rate (APR, on your statement).</p>`}
    <div class="mn-row"><input id="pc-name" maxlength="40" placeholder="Card name"><input id="pc-bal" inputmode="decimal" placeholder="$ owed"><input id="pc-apr" inputmode="decimal" placeholder="APR %"><input id="pc-fixed" inputmode="decimal" placeholder="$ each payday (optional)"></div>
    <div class="mn-row"><label class="small"><input type="checkbox" id="pc-full"> I pay this one in full every payday</label><button class="accent-btn small-btn" id="pc-add">➕ Add card</button></div>
    <div class="mn-row">${num("pay", "$ per month", "💳 Toward debt each month ")}${num("cash", "$ saved now", "🛟 Cushion now ")}${num("save", "$ per month", "🛟 Saving each month ")}</div>
    <div class="mn-row">${num("ef_goal", "1000", "🛟 Cushion goal ")}<label class="small">🎯 Next goal <input data-pg="goal_name" maxlength="40" placeholder="(a trip, a car…)" value="${val(g.goal_name)}"></label>${num("goal_amount", "$", "🎯 Goal $ ")}</div>
    <div class="mn-row"><label class="small">📅 A recent payday <input data-pg="payday" type="date" value="${val(g.payday)}"></label>${num("spend", "$ per 2 weeks", "🛍 Spending money between paydays ")}<button class="accent-btn small-btn" id="pg-save">Save my numbers</button></div>
    <small class="muted">Paid every 2 weeks. Leave anything you don't know blank - the plan says "I don't know" instead of guessing.</small></details></div>`;
}
function drawPlan() {
  const box = $("mn-plan");
  if (!box) return;
  if (!plan) { box.innerHTML = ""; return; }
  if (!plan.ok) { box.innerHTML = `<div class="card plan"><h3>🪜 My money plan</h3><p class="muted">${esc(plan.unknown)}</p></div>${plan.needs_setup ? planSetupHtml(plan.setup, true) : ""}`; return; }
  const p = plan, debtWord = p.student ? "$0 debt" : "cards gone";
  const paces = p.paces.map((x) => `<button class="plan-pace ${x.key === p.pace ? "on" : ""}" data-pace="${x.key}">
      <b>${x.e} ${esc(x.t)}${x.recommended ? ` <span class="plan-rec">recommended</span>` : ""}</b><small class="muted">${esc(x.d)}</small>
      <span>💳 ${esc(debtWord)}: <b>${pDate(x.end) || "?"}</b></span><span>🛟 ${usd(p.ef_goal)} cushion: ${pDate(x.ef) || "?"}</span>
      ${p.goal_amount ? `<span>🎯 ${esc(p.goal_name)}: ${pDate(x.goal) || "?"}</span>` : ""}
      <span>🐷 Stashed by then: <b>${usd(x.stashed)}</b> · interest ${usd(x.interest)}</span><small class="muted">${usd(x.per_month)}/mo to the plan · stash ${x.stash}%</small></button>`).join("");
  const steps = p.steps.map((s) => {
    const on = s.key === p.current;
    let bar = "";
    if (s.key === "ef") bar = mnBar(s.now / s.goal * 100, s.now >= s.goal ? "good" : "ok") + `<small class="muted">${usd(s.now)} of ${usd(s.goal)}</small>`;
    if (s.key === "cards" && s.start) bar = mnBar((s.start - s.now) / s.start * 100, "good") + `<small class="muted">${usd(s.now)} left · started at ${usd(s.start)}</small>`;
    const parts = (s.parts || []).map((c) => `<li>${esc(c.t)} ${usd(c.bal)} <small class="muted">${Math.round(c.apr)}% · paid off ${pDate(c.date) || "?"}</small></li>`).join("");
    const form = s.key === "student" ? `<details class="plan-student" ${s.needed ? "open" : ""}><summary>${s.needed ? "➕ Add your student loans" : "✏️ Edit"}</summary>
        <div class="mn-row"><input data-sl="balance" inputmode="decimal" placeholder="$ owed" value="${p.student ? p.student.balance : ""}">
        <input data-sl="rate" inputmode="decimal" placeholder="rate %" value="${p.student ? p.student.rate : ""}">
        <input data-sl="payment" inputmode="decimal" placeholder="$/month" value="${p.student ? p.student.payment : ""}">
        <select data-sl="kind">${["federal", "private", "both"].map((k) => `<option ${p.student && p.student.kind === k ? "selected" : ""}>${k}</option>`).join("")}</select></div>
        <small class="muted">From your loan servicer's app. Several loans? Add the total and the highest rate. Private to you.</small>
        <div class="mn-row"><button class="accent-btn small-btn" data-sl-save>Save</button>${p.student ? `<button class="link-btn" data-sl-clear>remove</button>` : ""}</div></details>` : "";
    return `<li class="plan-step ${on ? "on" : ""} ${s.needed || s.locked ? "wait" : ""}"><span class="plan-dot">${s.e}</span><div>
      <div class="bud-card-top"><b>${esc(s.t)}${on ? ` <span class="plan-rec">you're here</span>` : ""}</b><span>${s.locked ? "🔒" : s.needed ? "numbers needed" : (s.unlock ? "starts " : "") + (pDate(s.date) || "")}</span></div>
      ${bar}${parts ? `<ul class="plan-parts">${parts}</ul>` : ""}<small class="muted">${esc(s.note)}</small>${form}</div></li>`;
  }).join("");
  const cmp = p.compare.map((c) => `<tr class="${c.pct === p.stash_pct ? "on" : ""}" data-stash="${c.pct}"><td><b>${c.pct}%</b></td><td>${pDate(c.end) || "?"}${c.later_days ? ` <small class="muted">+${pDays(c.later_days)}</small>` : ""}</td>
      <td>${usd(c.growth.put_in)}</td><td>${usd(c.interest)}${c.more_interest ? ` <small class="muted">+${usd(c.more_interest)}</small>` : ""}</td></tr>`).join("");
  const mine = p.compare.find((c) => c.pct === p.stash_pct) || p.compare[0];
  const speed = p.speedups.map((s) => `<li><span>${s.e} ${esc(s.t)}<small class="muted">${esc(s.d)}</small></span>${s.days ? `<b class="plan-soon">${pDays(s.days)} sooner</b>` : ""}</li>`).join("");
  const planned = (p.planned || []).map((x) => `<li data-planned="${esc(x.id)}"><span>${esc(x.e || "🗓")} ${esc(x.name)}<small class="muted">${x.paid ? "✅ paid" : "upcoming"}${x.when ? " · " + pDate(x.when) : ""}${x.note ? " · " + esc(x.note) : ""}</small></span>
      ${x.amount ? `<b>${usd(x.amount)}</b>` : `<span class="mn-row"><input data-pl-amount inputmode="decimal" placeholder="$ amount"><button class="small-btn" data-pl-set>Set</button></span>`}
      ${!x.paid && x.amount ? `<button class="link-btn" data-pl-paid>mark paid</button>` : ""}</li>`).join("");
  const c = planCheck;
  const checkOut = !c ? "" : `<div class="plan-verdict ${c.verdict}"><b>${c.verdict === "fits" ? "✅" : c.verdict === "tight" ? "👀" : "⏳"} ${esc(c.say)}</b>
      ${c.moves.length ? `<ul>${c.moves.map((m) => `<li>${esc(m.t)}: ${m.days ? `+${pDays(m.days)}` : "no change"} <small class="muted">${pDate(m.date)}</small></li>`).join("")}</ul>` : ""}
      ${c.card_cost_year ? `<small class="muted">${usd(c.amount)} sitting on a ${c.apr.toFixed(0)}% card for a year costs about ${usd(c.card_cost_year)} in interest.</small>` : ""}
      ${c.fun_after != null ? `<small class="muted">Fun money this pay period after it: ${c.fun_after >= 0 ? usd(c.fun_after) + " left" : usd(-c.fun_after) + " over"}.</small>` : ""}
      <small class="muted">Just a check - nothing was bought or moved.</small></div>`;
  box.innerHTML = `<div class="card plan"><h3>🪜 My money plan <small class="muted">${p.next_payday ? `next payday ${pDate(p.next_payday)}` : ""}</small></h3>
    <div class="plan-paces">${paces}</div>
    <p class="plan-steady">⚖️ Hitting Steady every payday beats going hard for a month and quitting.</p>
    <ol class="plan-ladder">${steps}</ol></div>
  ${payTodayHtml()}
  <div class="card plan"><h3>🛒 Should I buy this?</h3>
    <div class="mn-row"><input id="plan-amt" inputmode="decimal" placeholder="$ amount"><input id="plan-note" maxlength="60" placeholder="what? (dinner, printer…)"><button class="accent-btn small-btn" id="plan-check">Check</button></div>
    ${checkOut}
    ${p.checks.length ? `<details class="mn-log"><summary>Recent checks</summary>${p.checks.map((x) => `<div><span>${usd(x.amount)}${x.note ? " - " + esc(x.note) : ""}</span><small class="muted">${x.verdict}${x.days ? ` · +${pDays(x.days)}` : ""}</small></div>`).join("")}</details>` : ""}</div>
  <div class="card plan"><h3>🐷 Stash along the way</h3>
    <p class="muted small">How much of the extra each payday goes to savings instead of the cards. The cushion fills first, then your pick:
      <select id="plan-pick">${Object.entries(p.picks).map(([k, v]) => `<option value="${k}" ${k === p.stash_pick ? "selected" : ""}>${esc(v)}</option>`).join("")}</select></p>
    <table class="plan-cmp"><thead><tr><th>Stash</th><th>${esc(debtWord)}</th><th>Stashed by then</th><th>Interest</th></tr></thead><tbody>${cmp}</tbody></table>
    <small class="muted">Tap a row to use it.</small>${planGrowth(mine.growth, p.stash_pick, p.apr_range)}
    <p class="small">Savings earn less than the cards cost, but a cushion stops new card debt.</p></div>
  <div class="card plan"><h3>🔍 Free speed-ups <small class="muted">faster without giving anything up</small></h3><ul class="plan-speed">${speed || `<li class="muted">Nothing found right now.</li>`}</ul></div>
  <div class="card plan"><h3>🗓 Planned costs <small class="muted">taken out first, so the dates stay honest</small></h3><ul class="plan-speed">${planned}</ul>
    <div class="mn-row"><input id="pl-name" maxlength="80" placeholder="What's coming up?"><input id="pl-amt" inputmode="decimal" placeholder="$"><input id="pl-when" type="month"><button class="small-btn" id="pl-add">Add</button></div></div>
  <div class="card plan"><h3>📈 Grow income</h3><ul class="plan-speed">
    <li><span>🏛 Grants watch<small class="muted">Open small-business grants + new tax rules, checked weekly</small></span><button class="link-btn" data-plan-grants>open ↓</button></li></ul></div>
  ${planSetupHtml(p.setup, false)}`;
}
// 💸 Pay today: what's in the bank -> how much to each card right now (the payday-plan strategy) and what's left. Moves nothing.
let payToday = null;
async function loadPayToday() { try { payToday = await api("/api/money/pay-today"); } catch { payToday = null; } drawPlan(); }
function payTodayHtml() {
  const t = payToday;
  if (!t) return "";
  const form = `<div class="mn-row"><input id="pt-bank" inputmode="decimal" placeholder="$ in checking now" value="${t.bank != null && t.bank_from === "typed" ? t.bank : ""}">
    <input id="pt-keep" inputmode="decimal" placeholder="keep $${t.auto_keep || 900}" value="${t.keep != null && t.keep !== t.auto_keep ? t.keep : ""}"><button class="accent-btn small-btn" id="pt-go">Split it</button></div>
    <label class="small"><input type="checkbox" id="pt-ping" ${t.ping !== false ? "checked" : ""}> 🔔 Ping me every payday at 5 PM with my card balances + this split</label>`;
  const sent = (t.bills || []).filter((b) => t.payday && b.sent === t.payday).map((b) => `<li data-ptbill="${esc(b.id)}"><span>${esc(b.e || "🔁")} ${esc(b.name)}<small class="muted">✅ sent this payday</small></span><b>${usd(b.amount)}</b><button class="link-btn" data-ptb-unsent>undo</button></li>`).join("");
  const later = (t.bills || []).filter((b) => t.payday && b.start > t.payday).map((b) => `<li data-ptbill="${esc(b.id)}"><span>${esc(b.e || "🔁")} ${esc(b.name)}<small class="muted">starts ${pDate(b.start)}</small></span><b>${usd(b.amount)}</b><button class="link-btn" data-ptb-rm>remove</button></li>`).join("");
  const bills = `<details class="mn-log"><summary>🔁 Every-payday bills ${t.bills && t.bills.length ? `(${t.bills.length})` : ""}</summary>
    ${sent || later ? `<ul class="plan-speed">${sent}${later}</ul>` : ""}
    <div class="mn-row"><input id="ptb-name" maxlength="60" placeholder="Who / what (rent share, phone bill…)"><input id="ptb-amt" inputmode="decimal" placeholder="$ each payday"><button class="small-btn" id="ptb-add">Add</button></div>
    <small class="muted">Comes out of checking first every payday, before the cards. Tap ✓ sent once it's paid.</small></details>`;
  const paidRows = (t.paid || []).map((p) => `<li data-ptpaid="${esc(p.id)}"><span>✅ ${esc(p.t)}<small class="muted">${pDate(p.day)} · ${p.posting ? "taken off here until the bank shows it" : "the bank shows it now"}</small></span><b>${usd(p.amount)}</b><button class="link-btn" data-ptp-rm>remove</button></li>`).join("");
  const paid = `<details class="mn-log"${(t.paid || []).some((p) => p.posting) ? " open" : ""}><summary>✅ I paid a card ${t.paid && t.paid.length ? `(${usd(t.paid.reduce((n, p) => n + p.amount, 0))})` : ""}</summary>
    ${paidRows ? `<ul class="plan-speed">${paidRows}</ul>` : ""}
    <div class="mn-row"><select id="ptp-card">${(t.cards || []).map((c) => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join("")}</select><input id="ptp-amt" inputmode="decimal" placeholder="$ paid"><button class="small-btn" id="ptp-add">Log it</button></div>
    <small class="muted">Banks take a day or three to show a payment. Logged ones come off the balances + payoff dates right away, then drop off once the bank catches up.</small></details>`;
  if (!t.ok) return `<div class="card plan"><h3>💸 Pay today</h3><p class="muted small">${esc(t.unknown || "What's in your checking account right now? I'll split it across your cards the payday-plan way.")}</p>${t.unknown ? "" : form + paid + bills}</div>`;
  const rows = t.rows.map((r) => r.bill
    ? `<li data-ptbill="${esc(r.id)}"><span>${esc(r.e)} ${esc(r.t)}<small class="muted">${esc(r.why)}</small></span><b>${usd(r.pay)}</b><button class="link-btn" data-ptb-sent>✓ sent</button> <button class="link-btn" data-ptb-rm>remove</button></li>`
    : `<li><span>${r.full ? "🛒" : "💳"} ${esc(r.t)}<small class="muted">${esc(r.why)} · ${usd(r.bal)} → ${usd(r.after)}</small></span><b>${usd(r.pay)}</b></li>`).join("");
  return `<div class="card plan"><h3>💸 Pay today <small class="muted">${t.next_payday ? `${t.days_to_payday} day${t.days_to_payday === 1 ? "" : "s"} to payday` : ""}</small></h3>
    <p class="small">🏦 ${usd(t.bank)} in checking${t.bank_from === "bank" ? " (from the bank)" : ""} · keeping <b>${usd(t.keep)}</b> to spend until payday</p>
    <ul class="plan-speed">${rows}</ul>
    <p><b>Pay ${usd(t.total)} total → ${usd(t.left)} left in checking.</b></p>
    ${t.short ? `<p class="small">⚠️ ${usd(t.short)} short of the full plan - the target card gets less this time. Next payday does more.</p>` : ""}
    ${t.extra_left ? `<p class="small">🎉 All cards covered - ${usd(t.extra_left)} more could go to savings.</p>` : ""}
    ${form}${paid}${bills}<small class="muted">Check each card's app for its exact minimum + due date - if a minimum is higher, pay the minimum. Just a plan - nothing is paid or moved.</small></div>`;
}
async function payTodayPing(on) {
  try { payToday = await post("/api/money/pay-today", { ping: on }); toast(on ? "🔔 Payday ping on" : "Payday ping off"); } catch (err) { toast(err.message); }
  drawPlan();
}
async function payTodayBill(bill, msg) {
  try { payToday = await post("/api/money/pay-today", { bill }); if (msg) toast(msg); } catch (err) { toast(err.message); }
  drawPlan();
}
async function payTodayPaid(paid, msg) {
  try { await post("/api/money/pay-today", { paid }); if (msg) toast(msg); } catch (err) { return toast(err.message); }
  loadPlan();   // balances + payoff dates move with it
}
async function payTodaySet() {
  try { payToday = await post("/api/money/pay-today", { bank: $("pt-bank").value, keep: $("pt-keep").value }); } catch (err) { toast(err.message); }
  drawPlan();
}
async function planSet(body, msg) {
  try { plan = await post("/api/money/plan", body); if (msg) toast(msg); } catch (err) { toast(err.message); }
  drawPlan(); drawHomePlan(true);
  if (plan && plan.ok && !payToday) loadPayToday();
}
$("mn-plan").addEventListener("click", async (e) => {
  const t = e.target;
  const pace = t.closest("[data-pace]");
  if (pace) return planSet({ pace: pace.dataset.pace }, "Pace set");
  const row = t.closest("[data-stash]");
  if (row) return planSet({ stash_pct: Number(row.dataset.stash) }, `🐷 Stashing ${row.dataset.stash}%`);
  if (t.closest("[data-sl-save]")) {
    const v = (k) => $("mn-plan").querySelector(`[data-sl="${k}"]`).value;
    return planSet({ student: { balance: v("balance"), rate: v("rate"), payment: v("payment"), kind: v("kind") } }, "🎓 Saved");
  }
  if (t.closest("[data-sl-clear]")) return planSet({ student: null });
  if (t.closest("[data-plan-grants]")) return $("mn-grants").scrollIntoView({ behavior: "smooth" });
  const li = t.closest("[data-planned]");
  if (li && t.closest("[data-pl-set]")) return planSet({ planned: { id: li.dataset.planned, amount: li.querySelector("[data-pl-amount]").value } }, "Added to the plan");
  if (li && t.closest("[data-pl-paid]")) return planSet({ planned: { id: li.dataset.planned, paid: true } });
  if (t.id === "pl-add") return planSet({ planned: { name: $("pl-name").value, amount: $("pl-amt").value || null, when: $("pl-when").value || null } }, "Added to the plan");
  if (t.id === "pc-add") return planSet({ card: { name: $("pc-name").value, balance: $("pc-bal").value, apr: $("pc-apr").value, fixed: $("pc-fixed").value, full: $("pc-full").checked } }, "💳 Card added");
  const pc = t.closest("[data-pcard]");
  if (pc && t.closest("[data-pc-set]")) return planSet({ card: { id: pc.dataset.pcard, balance: pc.querySelector("[data-pc-bal]").value } }, "Saved");
  if (pc && t.closest("[data-pc-rm]") && confirm("Remove this card from your plan?")) return planSet({ card: { id: pc.dataset.pcard, remove: true } }, "Removed");
  if (t.id === "pg-save") {
    const goals = {};
    $("mn-plan").querySelectorAll("[data-pg]").forEach((i) => { goals[i.dataset.pg] = i.value; });
    return planSet({ goals }, "✅ Saved - your plan updates from these");
  }
  if (t.id === "pt-go") return payTodaySet();
  if (t.id === "pt-ping") return payTodayPing(t.checked);
  if (t.id === "ptp-add") return payTodayPaid({ card: $("ptp-card").value, amount: $("ptp-amt").value }, "✅ Logged - taken off that card");
  const pp = t.closest("[data-ptpaid]");
  if (pp && t.closest("[data-ptp-rm]")) return payTodayPaid({ remove: pp.dataset.ptpaid }, "Removed");
  if (t.id === "ptb-add") return payTodayBill({ name: $("ptb-name").value, amount: $("ptb-amt").value }, "🔁 Added - every payday");
  const pb = t.closest("[data-ptbill]");
  if (pb && t.closest("[data-ptb-sent]")) return payTodayBill({ id: pb.dataset.ptbill, sent: true }, "✅ Marked sent this payday");
  if (pb && t.closest("[data-ptb-unsent]")) return payTodayBill({ id: pb.dataset.ptbill, sent: false });
  if (pb && t.closest("[data-ptb-rm]") && confirm("Stop this every-payday bill?")) return payTodayBill({ id: pb.dataset.ptbill, remove: true }, "Removed");
  if (t.id === "plan-check") {
    t.textContent = "…";
    try { planCheck = await post("/api/money/plan/check", { amount: $("plan-amt").value, note: $("plan-note").value }); } catch (err) { toast(err.message); }
    const amt = $("plan-amt").value, note = $("plan-note").value;
    try { plan = await api("/api/money/plan"); } catch {}
    drawPlan(); $("plan-amt").value = amt; $("plan-note").value = note;
  }
});
$("mn-plan").addEventListener("change", (e) => { if (e.target.id === "plan-pick") planSet({ stash_pick: e.target.value }); });
