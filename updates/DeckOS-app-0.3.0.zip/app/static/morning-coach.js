// 🧢 Coach - the Morning Run's stick-figure character (the owner's idea). One light inline SVG: headband, whistle, a simple
// face, an idle bounce. He demonstrates every exercise (2-3 keyframes, ~1.5 s loop), or moves IN SYNC with the owner's counted
// reps (each rep = one demo rep; holds = he holds too). Reactions: fist pump, PR party, thumbs up, "hips up!" point, coffee
// sip, wave, wrist tap (running late), stopwatch (2-Minute Max). Props: dumbbell, bar, rice bucket, toothbrush, towel, scale,
// mug. Our own drawings - no images. prefers-reduced-motion: he shows the key pose, no movement.
(function (root) {
  // a pose = head H, neck N, near elbow/wrist E W, far elbow/wrist e w, hip P, near knee/ankle K A, far knee/ankle k a (box 120x100, floor y=92)
  const parse = (s) => { const o = {}; s.trim().split(/\s+/).forEach((t) => { const m = t.match(/^([A-Za-z])(-?[\d.]+),(-?[\d.]+)$/); if (m) o[m[1]] = [+m[2], +m[3]]; }); return o; };
  const STAND = "H60,14 N60,24 E57,38 W56,51 e63,38 w64,51 P60,54 K58,72 A58,91 k62,72 a62,91";
  const F = (...frames) => frames.map((f) => Object.assign(parse(STAND), parse(f)));
  const plankUp = "H27,57 N35,61 E35,75 W35,90 e37,75 w37,90 P65,71 K80,80 A96,89 k80,80 a96,89";
  const plankDn = "H29,75 N37,79 E45,84 W36,90 e47,84 w38,90 P66,82 K81,86 A96,89 k81,86 a96,89";
  const lieBack = "H18,84 N26,86 E30,90 W38,90 e30,90 w38,90 P56,87 K68,74 A78,90 k68,74 a78,90";
  const allFours = "H26,58 N33,62 E33,76 W33,90 e35,76 w35,90 P63,64 K63,90 A80,90 k65,90 a82,90";
  const kneelTall = "H60,30 N60,40 E56,52 W58,62 e64,52 w62,62 P60,66 K60,90 A78,90 k62,90 a80,90";
  const halfKneel = "H58,30 N58,40 E56,52 W58,62 e62,52 w62,62 P58,66 K72,68 A74,90 k50,90 a36,90";
  const seated = "H50,48 N50,58 E44,66 W50,72 e56,66 w54,72 P50,86 K66,86 A84,88 k66,86 a84,88";
  const hang = "H60,20 N60,28 E56,18 W56,10 e64,18 w64,10 P60,56 K60,72 A60,86 k62,72 a62,86";
  const POSES = {
    stand: F(STAND, "H60,15 N60,25"),
    pushup: F(plankUp, plankDn),
    pike: F("H34,78 N38,72 E37,82 W35,90 e39,82 w37,90 P62,44 K73,66 A84,90 k73,66 a84,90", "H34,86 N39,80 E46,84 W35,90 e48,84 w37,90 P62,48 K73,68 A84,90 k73,68 a84,90"),
    squat: F("H60,14 N60,24 E68,30 W76,30 e68,30 w76,30", "H54,36 N55,46 E64,50 W72,48 e64,50 w72,48 P48,68 K64,70 A58,91 k64,70 a58,91"),
    squat_db: F("H60,14 N60,24 E58,36 W62,30 e64,36 w62,30", "H54,36 N55,46 E54,58 W58,52 e60,58 w58,52 P48,68 K64,70 A58,91 k64,70 a58,91"),
    row: F("H38,36 N45,42 E45,56 W45,70 e47,56 w47,70 P66,56 K68,72 A66,91 k70,72 a68,91", "H38,36 N45,42 E58,46 W54,58 e47,56 w47,70 P66,56 K68,72 A66,91 k70,72 a68,91"),
    zpress: F(seated.replace("E44,66 W50,72", "E42,58 W44,48").replace("e56,66 w54,72", "e58,58 w56,48"), seated.replace("E44,66 W50,72", "E44,44 W46,32").replace("e56,66 w54,72", "e56,44 w54,32")),
    floorpress: F(lieBack.replace("E30,90 W38,90", "E34,90 W34,78").replace("e30,90 w38,90", "e36,90 w36,78"), lieBack.replace("E30,90 W38,90", "E30,76 W30,62").replace("e30,90 w38,90", "e32,76 w32,62")),
    ytw: F("H20,84 N28,86 E18,82 W8,78 e18,82 w8,78 P58,87 K74,88 A92,88 k74,88 a92,88", "H20,84 N28,86 E28,80 W28,72 e28,80 w28,72 P58,87 K74,88 A92,88 k74,88 a92,88"),
    shtaps: F(plankUp, plankUp.replace("e37,75 w37,90", "e40,66 w36,60")),
    hold: F("H60,14 N60,24 E57,38 W56,56 e63,38 w64,56", "H60,15 N60,25 E57,39 W56,57 e63,39 w64,57"),
    pullover: F(lieBack.replace("E30,90 W38,90", "E14,84 W4,86").replace("e30,90 w38,90", "e14,84 w4,86"), lieBack.replace("E30,90 W38,90", "E28,74 W30,64").replace("e30,90 w38,90", "e28,74 w30,64")),
    hang: F(hang, hang.replace("P60,56", "P61,56").replace("A60,86", "A62,86")),
    pullup: F(hang, "H60,6 N60,16 E52,18 W56,10 e68,18 w64,10 P60,44 K60,60 A60,76 k62,60 a62,76"),
    sprawl: F(STAND, "H28,78 N36,81 E42,85 W36,90 e44,85 w38,90 P66,89 K80,90 A96,90 k80,90 a96,90"),
    shadow: F("H60,14 N60,24 E66,30 W64,22 e56,30 w60,22", "H60,14 N60,24 E70,26 W84,26 e56,30 w60,22", "H60,14 N60,24 E66,30 W64,22 e50,26 w38,26"),
    shrimp: F("H20,84 N28,86 E34,82 W40,80 e34,82 w40,80 P56,86 K66,76 A76,90 k66,76 a76,90", "H22,84 N30,86 E36,82 W42,80 e36,82 w42,80 P64,82 K62,72 A72,90 k70,82 a80,90"),
    bridge: F(lieBack, lieBack.replace("P56,87", "P54,70")),
    situout: F(allFours, "H26,58 N33,62 E33,76 W33,90 e40,70 w46,60 P56,74 K48,84 A30,86 k66,90 a82,90"),
    twist: F("H44,52 N48,60 E56,66 W62,64 e56,66 w62,64 P58,86 K72,74 A86,84 k72,74 a86,84", "H44,52 N48,60 E42,68 W36,70 e42,68 w36,70 P58,86 K72,74 A86,84 k72,74 a86,84"),
    chop: F(halfKneel.replace("E56,52 W58,62", "E66,58 W72,72").replace("e62,52 w62,62", "e66,58 w72,72"), halfKneel.replace("E56,52 W58,62", "E50,40 W44,36").replace("e62,52 w62,62", "e50,40 w44,36")),
    hip9090: F("H50,48 N50,58 E44,66 W42,74 e56,66 w58,74 P50,86 K66,80 A62,90 k36,84 a28,90", "H50,48 N50,58 E44,66 W42,74 e56,66 w58,74 P50,86 K36,80 A40,90 k64,84 a72,90"),
    openbook: F("H20,80 N28,82 E40,82 W50,82 e40,82 w50,82 P56,86 K70,76 A78,90 k70,76 a78,90", "H20,80 N28,82 E40,82 W50,82 e26,70 w14,62 P56,86 K70,76 A78,90 k70,76 a78,90"),
    latlunge: F("H60,14 N60,24 E60,36 W62,30 e60,36 w62,30 P60,54 K52,72 A44,91 k68,72 a76,91", "H52,28 N52,38 E54,48 W58,44 e54,48 w58,44 P50,64 K38,72 A34,91 k62,76 a80,91"),
    skater: F("H48,22 N50,32 E44,42 W40,50 e58,40 w66,44 P54,58 K48,72 A46,90 k64,74 a70,84", "H72,22 N70,32 E76,42 W80,50 e62,40 w54,44 P66,58 K72,72 A74,90 k56,74 a50,84"),
    slrdl: F("H60,14 N60,24 E58,38 W58,52 e62,38 w62,52", "H34,40 N40,44 E42,56 W42,68 e44,56 w44,68 P62,52 K62,72 A62,91 k80,50 a96,46"),
    wallsit: F("H72,30 N72,40 E64,48 W58,52 e64,48 w58,52 P72,64 K52,64 A52,91 k52,64 a52,91", "H72,31 N72,41 E64,49 W58,53 e64,49 w58,53 P72,64 K52,64 A52,91 k52,64 a52,91"),
    cossack: F("H60,14 N60,24 E64,34 W68,32 e64,34 w68,32 P60,54 K50,72 A40,91 k70,72 a80,91", "H46,40 N47,50 E54,56 W60,54 e54,56 w60,54 P44,70 K34,74 A32,91 k64,80 a86,88"),
    plank: F("H28,72 N36,74 E36,86 W46,88 e38,86 w48,88 P66,78 K80,84 A96,89 k80,84 a96,89", "H28,71 N36,73 E36,86 W46,88 e38,86 w48,88 P66,77 K80,84 A96,89 k80,84 a96,89"),
    sideplank: F("H30,56 N36,60 E36,74 W36,88 e36,48 w36,36 P64,72 K80,80 A96,88 k80,80 a96,88", "H30,55 N36,59 E36,74 W36,88 e36,47 w36,35 P64,71 K80,80 A96,88 k80,80 a96,88"),
    hollow: F("H26,80 N32,82 E20,80 W10,78 e20,80 w10,78 P56,88 K72,84 A88,80 k72,84 a88,80", "H26,79 N32,81 E20,79 W10,77 e20,79 w10,77 P56,88 K72,83 A88,79 k72,83 a88,79"),
    deadbug: F("H20,84 N28,86 E30,76 W30,66 e30,76 w30,66 P56,88 K58,72 A70,72 k58,72 a70,72", "H20,84 N28,86 E20,80 W10,78 e30,76 w30,66 P56,88 K70,82 A84,84 k58,72 a70,72"),
    birddog: F(allFours, "H26,58 N33,62 E22,58 W10,56 e35,76 w35,90 P63,64 K63,90 A80,90 k78,62 a94,62"),
    pallof: F(kneelTall.replace("E56,52 W58,62", "E64,46 W66,40").replace("e64,52 w62,62", "e64,46 w66,40"), kneelTall.replace("E56,52 W58,62", "E72,40 W82,40").replace("e64,52 w62,62", "e72,40 w82,40")),
    vup: F("H20,86 N28,87 E18,86 W8,86 e18,86 w8,86 P56,88 K72,88 A90,88 k72,88 a90,88", "H40,62 N44,68 E56,62 W66,58 e56,62 w66,58 P56,86 K66,70 A74,58 k66,70 a74,58"),
    flutter: F("H22,82 N30,84 E34,88 W40,90 e34,88 w40,90 P58,88 K74,84 A90,80 k74,86 a90,86", "H22,82 N30,84 E34,88 W40,90 e34,88 w40,90 P58,88 K74,86 A90,86 k74,84 a90,80"),
    bear: F("H26,58 N33,62 E33,76 W33,90 e35,76 w35,90 P63,64 K60,84 A80,90 k62,84 a82,90", "H26,57 N33,61 E33,76 W33,90 e35,76 w35,90 P63,63 K60,84 A80,90 k62,84 a82,90"),
    hangknees: F(hang, "H60,20 N60,28 E56,18 W56,10 e64,18 w64,10 P60,50 K72,44 A74,58 k72,44 a74,58"),
    renegade: F(plankUp, plankUp.replace("E35,75 W35,90", "E46,64 W42,74")),
    halo: F(kneelTall.replace("E56,52 W58,62", "E50,26 W50,16").replace("e64,52 w62,62", "e56,28 w52,16"), kneelTall.replace("E56,52 W58,62", "E62,22 W60,14").replace("e64,52 w62,62", "e66,24 w60,14"), kneelTall.replace("E56,52 W58,62", "E70,26 W70,16").replace("e64,52 w62,62", "e64,28 w68,16")),
    tgu: F(lieBack.replace("E30,90 W38,90", "E28,74 W28,60"), "H30,64 N34,72 E28,58 W28,44 e40,82 w44,90 P56,86 K68,74 A78,90 k68,74 a78,90", kneelTall.replace("E56,52 W58,62", "E58,24 W58,10")),
    windmill: F(kneelTall.replace("E56,52 W58,62", "E60,24 W60,10"), "H44,50 N48,54 E54,40 W60,26 e44,66 w42,82 P60,66 K60,90 A78,90 k62,90 a80,90"),
    lungerot: F("H60,14 N60,24 E64,32 W62,28 e56,32 w58,28", "H58,32 N58,42 E68,44 W72,40 e66,46 w72,40 P58,64 K72,72 A72,91 k48,84 a38,91"),
    atw: F("H60,14 N60,24 E50,40 W46,52 e54,42 w48,52", "H60,14 N60,24 E70,40 W74,52 e66,42 w72,52", "H60,14 N60,24 E62,42 W60,58 e58,42 w60,58"),
    clean: F("H58,18 N58,28 E58,44 W58,60 e62,40 w62,52 P60,58 K62,74 A60,91 k62,74 a62,91", "H60,14 N60,24 E64,34 W62,26 e63,38 w64,51"),
    march: F("H60,14 N60,24 E57,38 W56,54 e63,38 w64,54 P60,54 K66,62 A64,76 k62,72 a62,91", "H60,14 N60,24 E57,38 W56,54 e63,38 w64,54 P60,54 K58,72 A58,91 k68,62 a66,76"),
    rotswing: F("H44,36 N48,42 E50,56 W56,70 e52,56 w56,70 P66,56 K64,72 A60,91 k68,72 a66,91", "H58,16 N60,26 E70,40 W80,50 e70,42 w80,50"),
    getupflow: F(seated.replace("E44,66 W50,72", "E54,62 W58,60").replace("e56,66 w54,72", "e54,62 w58,60"), kneelTall.replace("E56,52 W58,62", "E62,48 W66,44").replace("e64,52 w62,62", "e62,48 w66,44"), "H60,14 N60,24 E62,34 W66,32 e62,34 w66,32"),
    lunge: F(STAND, "H58,32 N58,42 E56,54 W56,64 e60,54 w60,64 P58,64 K72,72 A72,91 k48,84 a38,91"),
    sealjack: F("H60,14 N60,24 E64,34 W60,38 e56,34 w60,38 P60,54 K60,72 A60,91 k60,72 a60,91", "H60,14 N60,24 E74,26 W86,26 e46,26 w34,26 P60,54 K54,72 A48,91 k66,72 a72,91"),
    climber: F(plankUp, plankUp.replace("K80,80 A96,89", "K52,76 A60,84")),
    situp: F(lieBack, "H44,56 N46,64 E52,70 W56,76 e52,70 w56,76 P56,87 K68,74 A78,90 k68,74 a78,90"),
    jack: F("H60,14 N60,24 E57,38 W56,51 e63,38 w64,51", "H60,14 N60,24 E50,14 W44,4 e70,14 w76,4 P60,54 K54,72 A48,91 k66,72 a72,91"),
    ohpress: F("H60,14 N60,24 E52,30 W54,22 e68,30 w66,22", "H60,14 N60,24 E58,12 W58,2 e62,12 w62,2"),
    thruster: F("H54,36 N55,46 E52,52 W54,44 e60,52 w58,44 P48,68 K64,70 A58,91 k64,70 a58,91", "H60,14 N60,24 E58,12 W58,2 e62,12 w62,2"),
    rice: F(STAND, STAND),
    // card poses (Morning Run steps + reactions)
    brush: F("H60,14 N60,24 E66,30 W64,20 e63,38 w64,51", "H60,14 N60,24 E66,30 W60,20 e63,38 w64,51"),
    towel: F("H60,14 N60,24 E52,22 W56,10 e68,22 w64,10", "H60,14 N60,24 E50,22 W54,10 e70,22 w66,10"),
    scale: F("H60,12 N60,22 E57,36 W56,49 e63,36 w64,49 P60,52 K58,70 A58,86 k62,70 a62,86", "H60,13 N60,23 E57,37 W56,50 e63,37 w64,50 P60,53 K58,70 A58,86 k62,70 a62,86"),
    sip: F("H60,14 N60,24 E66,32 W64,22 e57,38 w56,51", "H60,15 N60,25 E66,34 W66,28 e57,39 w56,52"),
    fist: F("H60,14 N60,24 E66,32 W66,20 e57,38 w56,51", "H60,13 N60,23 E68,18 W66,6 e57,38 w56,51"),
    party: F("H60,14 N60,24 E52,14 W46,4 e68,14 w74,4 P60,54", "H60,10 N60,20 E50,10 W44,0 e70,10 w76,0 P60,50 K58,68 A58,86 k62,68 a62,86"),
    thumb: F("H60,14 N60,24 E68,34 W70,26 e57,38 w56,51", "H60,14 N60,24 E68,34 W70,24 e57,38 w56,51"),
    point: F("H60,14 N60,24 E70,26 W82,24 e57,38 w56,51", "H60,14 N60,24 E70,26 W84,22 e57,38 w56,51"),
    wave: F("H60,14 N60,24 E70,22 W76,10 e57,38 w56,51", "H60,14 N60,24 E70,22 W82,12 e57,38 w56,51"),
    wrist: F("H60,15 N60,25 E66,34 W62,36 e54,34 w60,36", "H60,15 N60,25 E66,34 W62,34 e54,34 w60,38"),
    watch: F("H60,14 N60,24 E66,32 W66,24 e57,38 w56,51", "H60,14 N60,24 E66,32 W67,24 e57,38 w56,51"),
  };
  const PROP_OF = { squat_db: "db", row: "db", zpress: "db", floorpress: "db", hold: "db2", pullover: "db", twist: "db", chop: "db", pallof: "db", halo: "db", tgu: "db",
    windmill: "db", lungerot: "db", atw: "db", clean: "db", rotswing: "db", getupflow: "db", slrdl: "db", renegade: "db", ohpress: "db2", thruster: "db2",
    hang: "bar", pullup: "bar", hangknees: "bar", rice: "rice", brush: "brush", towel: "towel", scale: "scale", sip: "mug", watch: "watch", wallsit: "wall" };
  const lerp = (a, b, t) => a + (b - a) * t;
  const reduce = () => typeof matchMedia !== "undefined" && matchMedia("(prefers-reduced-motion: reduce)").matches;

  class Coach {
    constructor(host, name) {
      this.host = host; this.name = name || "Coach"; this.pose = "stand"; this.mode = "idle"; this.t0 = 0; this.k = 0; this.react = null; this.raf = 0; this.prop = null;
      host.innerHTML = `<div class="coach"><div class="coach-bubble" hidden></div><svg viewBox="0 0 120 100" class="coach-svg" role="img" aria-label="${name || "Coach"}">
        <g class="c-floor"><line x1="2" y1="92" x2="118" y2="92"/></g><g class="c-prop-back"></g>
        <g class="c-body"><polyline class="c-limb c-far" /><polyline class="c-limb c-farleg" /><line class="c-torso" /><polyline class="c-limb c-leg" /><polyline class="c-limb c-arm" />
          <g class="c-head"><circle r="7" class="c-skull"/><path class="c-band" d="M-7,-2 L7,-2"/><circle class="c-eye" cx="-2.4" cy="-0.5" r="0.9"/><circle class="c-eye" cx="2.6" cy="-0.5" r="0.9"/><path class="c-mouth" d="M-2.5,2.6 Q0,4.6 2.5,2.6"/></g>
          <g class="c-whistle"><line x1="0" y1="0" x2="2" y2="6"/><circle cx="2.6" cy="7" r="1.4"/></g></g>
        <g class="c-prop"></g></svg><div class="coach-name">${name || "Coach"}</div></div>`;
      this.svg = host.querySelector("svg"); this.bubble = host.querySelector(".coach-bubble");
      this.tick = this.tick.bind(this); this.raf = requestAnimationFrame(this.tick);
    }
    setName(n) { this.name = n; const el = this.host.querySelector(".coach-name"); if (el) el.textContent = n; }
    // modes: "demo" loops the move · "sync" waits for rep() · "hold" holds the work pose · "idle" stands and bounces
    show(pose, mode = "demo") { this.pose = POSES[pose] ? pose : "stand"; this.mode = mode; this.t0 = performance.now(); this.k = 0; this.react = null; this.prop = PROP_OF[this.pose] || null; }
    rep() { if (this.mode === "sync") this.t0 = performance.now(), (this.k = 1); }
    reaction(kind, ms = 1600) { if (POSES[kind]) { this.react = { pose: kind, until: performance.now() + ms, prop: PROP_OF[kind] }; } }
    say(text, ms = 3500) { if (!text) return; this.bubble.textContent = text; this.bubble.hidden = false; clearTimeout(this.bt); this.bt = setTimeout(() => { this.bubble.hidden = true; }, ms); }
    face(kind) { const m = this.svg.querySelector(".c-mouth"); m.setAttribute("d", kind === "o" ? "M-1.5,3 Q0,5 1.5,3 Q0,1 -1.5,3" : kind === "flat" ? "M-2.5,3 L2.5,3" : "M-2.5,2.6 Q0,4.6 2.5,2.6"); }
    frameAt(now) {
      const r = this.react && now < this.react.until ? this.react : null; if (this.react && !r) this.react = null;
      const name = r ? r.pose : this.pose, fr = POSES[name] || POSES.stand;
      if (reduce()) return { p: fr[fr.length > 1 ? 1 : 0], bob: 0, prop: r ? r.prop : this.prop };
      let a, b, t;
      if (r || this.mode === "demo") { const per = 1500 / Math.max(1, fr.length), x = ((now - this.t0) / per) % fr.length, i = Math.floor(x); a = fr[i]; b = fr[(i + 1) % fr.length]; t = 0.5 - 0.5 * Math.cos(Math.PI * (x - i)); }
      else if (this.mode === "hold") { a = b = fr[Math.min(1, fr.length - 1)]; t = 0; }
      else if (this.mode === "sync") { const d = (now - this.t0) / 700; if (!this.k || d >= 1) { this.k = 0; a = b = fr[0]; t = 0; } else { a = fr[0]; b = fr[1] || fr[0]; t = Math.sin(Math.PI * d); } }
      else { a = b = fr[0]; t = 0; }
      const p = {}; for (const key in a) p[key] = [lerp(a[key][0], b[key][0], t), lerp(a[key][1], b[key][1], t)];
      const bob = this.mode === "idle" && !r ? Math.sin(now / 380) * 1.2 : 0;
      return { p, bob, prop: r ? r.prop : this.prop };
    }
    tick(now) {
      if (!this.svg.isConnected) return;
      const { p, bob, prop } = this.frameAt(now), q = (k) => `${p[k][0].toFixed(1)},${(p[k][1] + bob).toFixed(1)}`, s = this.svg;
      s.querySelector(".c-arm").setAttribute("points", `${q("N")} ${q("E")} ${q("W")}`);
      s.querySelector(".c-far").setAttribute("points", `${q("N")} ${q("e")} ${q("w")}`);
      s.querySelector(".c-leg").setAttribute("points", `${q("P")} ${q("K")} ${q("A")}`);
      s.querySelector(".c-farleg").setAttribute("points", `${q("P")} ${q("k")} ${q("a")}`);
      const t = s.querySelector(".c-torso"); t.setAttribute("x1", p.N[0]); t.setAttribute("y1", p.N[1] + bob); t.setAttribute("x2", p.P[0]); t.setAttribute("y2", p.P[1] + bob);
      s.querySelector(".c-head").setAttribute("transform", `translate(${p.H[0].toFixed(1)},${(p.H[1] + bob).toFixed(1)})`);
      s.querySelector(".c-whistle").setAttribute("transform", `translate(${p.N[0].toFixed(1)},${(p.N[1] + bob).toFixed(1)})`);
      const W = p.W, w = p.w, pr = s.querySelector(".c-prop"), back = s.querySelector(".c-prop-back");
      const db = (x, y) => `<g class="c-db"><rect x="${x - 4}" y="${y - 1.2}" width="8" height="2.4" rx="1"/><rect x="${x - 5}" y="${y - 2.6}" width="2" height="5.2" rx=".6"/><rect x="${x + 3}" y="${y - 2.6}" width="2" height="5.2" rx=".6"/></g>`;
      const emo = (e, x, y, sz = 9) => `<text x="${x}" y="${y}" font-size="${sz}" text-anchor="middle" dominant-baseline="middle">${e}</text>`;
      pr.innerHTML = prop === "db" ? db(W[0], W[1] + bob) : prop === "db2" ? db(W[0], W[1] + bob) + db(w[0], w[1] + bob)
        : prop === "brush" ? emo("🪥", W[0], W[1] + bob - 2, 8) : prop === "mug" ? emo("☕", W[0] + 1, W[1] + bob, 8) : prop === "watch" ? emo("⏱", W[0], W[1] + bob - 1, 9)
        : prop === "towel" ? `<path class="c-towel" d="M${p.H[0] - 9},${p.H[1] + bob - 3} Q${p.H[0]},${p.H[1] + bob - 14} ${p.H[0] + 9},${p.H[1] + bob - 3} L${p.H[0] + 10},${p.H[1] + bob + 6} L${p.H[0] - 10},${p.H[1] + bob + 6} Z"/>`
        : prop === "rice" ? `<g class="c-bucket"><path d="M70,92 L74,70 L98,70 L102,92 Z"/><ellipse cx="86" cy="70" rx="12" ry="3"/></g>${emo(Math.floor(now / 450) % 2 ? "✊" : "🖐", 86, 66, 11)}` : "";
      back.innerHTML = prop === "bar" ? `<line class="c-bar" x1="40" y1="10" x2="80" y2="10"/>` : prop === "scale" ? `<rect class="c-scale" x="48" y="86" width="24" height="6" rx="2"/>` : prop === "wall" ? `<line class="c-bar" x1="79" y1="20" x2="79" y2="92"/>` : "";
      this.raf = requestAnimationFrame(this.tick);
    }
    stop() { cancelAnimationFrame(this.raf); }
  }
  Coach.POSES = POSES;
  Coach.CSS = `.coach{position:relative;display:flex;flex-direction:column;align-items:center;width:100%;max-width:300px;margin:0 auto}
    .coach-svg{width:100%;height:auto;overflow:visible}
    .coach-svg .c-limb,.coach-svg .c-torso{fill:none;stroke:var(--text,#d7e3ee);stroke-width:3.2;stroke-linecap:round;stroke-linejoin:round}
    .coach-svg .c-far,.coach-svg .c-farleg{opacity:.55}
    .coach-svg .c-skull{fill:var(--panel,#0f141a);stroke:var(--text,#d7e3ee);stroke-width:2.4}
    .coach-svg .c-band{stroke:var(--accent,#32e0c4);stroke-width:2.6;stroke-linecap:round}
    .coach-svg .c-eye{fill:var(--text,#d7e3ee)} .coach-svg .c-mouth{fill:none;stroke:var(--text,#d7e3ee);stroke-width:1.2;stroke-linecap:round}
    .coach-svg .c-whistle line{stroke:var(--muted,#6b7d8f);stroke-width:.8} .coach-svg .c-whistle circle{fill:var(--warn,#ffb547)}
    .coach-svg .c-floor line{stroke:var(--line,#1f2a36);stroke-width:1.5}
    .coach-svg .c-db rect{fill:var(--muted,#6b7d8f)} .coach-svg .c-bar{stroke:var(--muted,#6b7d8f);stroke-width:2.5;stroke-linecap:round}
    .coach-svg .c-towel{fill:#e9d8b4;opacity:.9} .coach-svg .c-scale{fill:var(--muted,#6b7d8f)}
    .coach-svg .c-bucket path,.coach-svg .c-bucket ellipse{fill:#c9a66b;stroke:#8a6a3a;stroke-width:1}
    .coach-bubble{position:absolute;top:-6px;left:50%;transform:translate(-50%,-100%);background:var(--panel-2,#151c24);border:1px solid var(--accent,#32e0c4);
      border-radius:14px;padding:7px 12px;font-size:16px;font-weight:600;max-width:280px;text-align:center;z-index:2;white-space:normal}
    .coach-bubble::after{content:"";position:absolute;bottom:-7px;left:50%;margin-left:-6px;border:6px solid transparent;border-top-color:var(--accent,#32e0c4);border-bottom:0}
    .coach-name{font-size:12px;color:var(--muted,#6b7d8f);margin-top:-4px}`;
  root.MorningCoach = Coach;
})(typeof window !== "undefined" ? window : globalThis);
