// 📅 The calendar view in Schedule: every calendar in a month grid, add/edit events, and "did it make it to iCloud?"
let cal = null, calMonth = null, calDay = null, calEditing = null;
const ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const calTime = (iso) => new Date(iso).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });

async function loadCalendar() {
  // ⚡ show the calendar you saw last time straight away (no half-second pop-in above the reminders), then freshen it up
  if (!cal && !calMonth) { try { const c = JSON.parse(safeGet("deckos_cal") || "null"); if (c && c.month === ymd(new Date()).slice(0, 7)) cal = c; } catch {} }
  if (cal && cal.calendars.length && (!calMonth || cal.month === calMonth)) {
    $("cal-card").hidden = false;
    calMonth = cal.month;
    if (!calDay || !calDay.startsWith(calMonth)) calDay = ymd(new Date()).startsWith(calMonth) ? ymd(new Date()) : calMonth + "-01";
    drawCalendar();
  }
  try { cal = await api(`/api/calendar${calMonth ? "?month=" + calMonth : ""}`); } catch { $("cal-card").hidden = true; return; }
  if (cal.month === ymd(new Date()).slice(0, 7)) safeSet("deckos_cal", JSON.stringify(cal));
  $("cal-card").hidden = !cal.calendars.length;
  if (!cal.calendars.length) return;
  calMonth = cal.month;
  if (!calDay || !calDay.startsWith(calMonth)) calDay = ymd(new Date()).startsWith(calMonth) ? ymd(new Date()) : calMonth + "-01";
  drawCalendar();
  drawICloud();
}
// 🍎 Connect iCloud: step-by-step, paste an app-specific password, Test & connect. Owner only, at home.
let icloudOpen = false;
function drawICloud() {
  const box = $("icloud-card"), st = cal.icloud || {};
  box.hidden = !st.can_connect || !st.has_icloud;
  if (box.hidden) return;
  if (st.connected) {
    box.innerHTML = `<div class="icloud-on">🍎 <b>iCloud connected</b> <small class="muted">- edit, move and delete iCloud events right here</small>
      <button class="link-btn" data-icloud-forget>disconnect</button></div>`;
    return;
  }
  box.innerHTML = !icloudOpen ? `<button class="icloud-cta" data-icloud-open>🍎 <b>Connect iCloud</b> <small>so you can edit, move and delete your Home, Family and Work events here - 2 minutes ›</small></button>`
    : `<div class="icloud-steps"><h3>🍎 Connect iCloud <button class="link-btn" data-icloud-close>not now</button></h3>
      <p class="muted small">Apple makes you use a special one-app password for this (not your real Apple password).</p>
      <ol>
        <li>Open <a href="https://account.apple.com/account/manage" target="_blank" rel="noopener"><b>Apple Account ↗</b></a> and sign in.</li>
        <li>Tap <b>Sign-In and Security</b> → <b>App-Specific Passwords</b> → <b>＋</b>.</li>
        <li>Name it <b>Deck OS</b> → Apple shows a password like <code>abcd-efgh-ijkl-mnop</code>. Copy it.</li>
        <li>Paste it below with your Apple ID email, then tap <b>Test & connect</b>.</li>
      </ol>
      <form class="icloud-form" autocomplete="off">
        <input id="icloud-user" type="email" placeholder="Apple ID email" autocomplete="off" required>
        <input id="icloud-pass" type="password" placeholder="abcd-efgh-ijkl-mnop" autocomplete="new-password" required>
        <button class="accent-btn" id="icloud-go">🔒 Test & connect</button>
      </form>
      <small class="muted">It's checked with iCloud first and only kept if it works - on this computer, readable only by you, never shown again.
        Disconnect here any time, or delete it in your Apple account to turn it off from there.</small></div>`;
}
$("icloud-card").addEventListener("click", async (e) => {
  if (e.target.closest("[data-icloud-open]")) { icloudOpen = true; drawICloud(); $("icloud-user").focus(); }
  if (e.target.closest("[data-icloud-close]")) { icloudOpen = false; drawICloud(); }
  const f = e.target.closest("[data-icloud-forget]");
  if (f) {
    if (!f.dataset.sure) { f.dataset.sure = 1; f.textContent = "tap again to disconnect"; return; }
    try { await post("/api/icloud", { forget: true }); toast("🍎 iCloud disconnected"); loadCalendar(); } catch (err) { toast(err.message); }
  }
});
$("icloud-card").addEventListener("submit", async (e) => {
  e.preventDefault();
  const btn = $("icloud-go");
  btn.disabled = true; btn.textContent = "Checking with iCloud…";
  try {
    const r = await post("/api/icloud", { user: $("icloud-user").value, password: $("icloud-pass").value });
    $("icloud-pass").value = "";
    icloudOpen = false;
    toast(`🍎 Connected - found ${r.calendars} iCloud calendars`);
    burstAt($("icloud-card"), ["🍎", "📅", "✨"], 14, 120);
    loadCalendar();
  } catch (err) { toast(err.message); btn.disabled = false; btn.textContent = "🔒 Test & connect"; }
});
// 🎨 tap a calendar in the legend: its color (pick one - it changes on your iPhone too once iCloud's linked) + is it linked?
const CAL_SWATCHES = ["#3987e5", "#1badf8", "#199e70", "#63da38", "#c98500", "#ff9500", "#d95926", "#ff2968", "#d55181", "#cc73e1", "#9085e9", "#a2845e", "#8e8e93"];
let calSheetFor = null;
function openCalSheet(id) {
  const c = calOf(id), st = cal.icloud || {};
  calSheetFor = id;
  const link = c.linked ? `<p class="small">🔗 <b>Linked from ${esc(CAL_LINK_KINDS[c.linked] ? CAL_LINK_KINDS[c.linked].name : "a link")}</b> - shows here and updates every few minutes. Add or change these events in ${esc(CAL_LINK_KINDS[c.linked] ? CAL_LINK_KINDS[c.linked].app : "its own app")}.</p>`
    : !c.icloud ? `<p class="muted small">✅ This calendar lives in Deck OS - add, change and delete anything.</p>`
    : c.apple ? `<p class="small">🍎 <b>Linked to iCloud</b> - add, change, move and delete events here. Colors match your iPhone.</p>`
    : st.can_connect ? `<div class="cal-howto"><p class="small">🔗 <b>Not linked yet</b> - right now Deck OS can only <i>add</i> to ${esc(c.name)}. Link iCloud to change and delete events here too:</p>
        <ol class="small"><li>Open <a href="https://account.apple.com/account/manage" target="_blank" rel="noopener"><b>Apple Account ↗</b></a> → <b>Sign-In and Security</b> → <b>App-Specific Passwords</b> → <b>＋</b></li>
        <li>Name it <b>Deck OS</b> and copy the password</li><li>Paste it in <b>🍎 Connect iCloud</b>:</li></ol>
        <button class="accent-btn small-btn" data-cal-link>🍎 Connect iCloud</button></div>`
    : `<p class="muted small">This is an iCloud calendar - you can add to it here.</p>`;
  $("calsheet-title").textContent = `🎨 ${c.name}`;
  $("calsheet-body").innerHTML = `<h4>Color</h4>
    <div class="cal-swatches">${CAL_SWATCHES.map((x) => `<button type="button" class="${x.toLowerCase() === (c.color || "").toLowerCase() ? "on" : ""}" style="background:${x}" data-cal-color="${x}" aria-label="${x}"></button>`).join("")}
      <label class="cal-custom" title="Any color"><input type="color" value="${c.color || "#3987e5"}" data-cal-color-any>🎨</label></div>
    ${c.icloud && !c.apple ? `<small class="muted">Changes the color in Deck OS. Link iCloud and it changes on your iPhone too.</small>` : ""}
    <h4>Linked?</h4>${link}
    ${c.linked ? `<button class="link-btn danger" data-cal-remove>Unlink this calendar</button>`
      : c.removable ? `<button class="link-btn danger" data-cal-remove>Delete this calendar</button><small class="muted"> - its events go too</small>`
      : c.kind === "icloud" ? `<small class="muted">To delete an iCloud calendar, use the Calendar app (it's removed from every iPhone too).</small>` : ""}`;
  $("calsheet-modal").hidden = false;
}
// ＋ Calendar: make a brand-new one, or link one you already have (Apple, Google, Outlook, Samsung, any link)
const CAL_LINK_KINDS = {
  google: { name: "Google Calendar", app: "Google Calendar", icon: "🟦", steps: [
    `On a computer, open <a href="https://calendar.google.com/calendar/r/settings" target="_blank" rel="noopener"><b>Google Calendar settings ↗</b></a> (the phone app can't do this part)`,
    `On the left, under <b>Settings for my calendars</b>, click the calendar you want`,
    `Scroll to <b>Integrate calendar</b> → copy <b>Secret address in iCal format</b>`,
    `Paste it below → <b>Link it</b>`] },
  outlook: { name: "Outlook", app: "Outlook", icon: "🟦", steps: [
    `Open <a href="https://outlook.live.com/calendar/0/options/calendar/SharedCalendars" target="_blank" rel="noopener"><b>Outlook calendar sharing ↗</b></a> (work or school account? use Outlook on the web → ⚙️ → Calendar → Shared calendars)`,
    `Under <b>Publish a calendar</b>, pick the calendar and <b>Can view all details</b> → <b>Publish</b>`,
    `Copy the <b>ICS</b> link`, `Paste it below → <b>Link it</b>`] },
  samsung: { name: "Samsung Calendar", app: "Samsung Calendar", icon: "🟪", steps: [
    `Samsung Calendar can't share a link by itself - but it can keep everything in your Google account, and Google can:`,
    `On the Samsung phone: <b>Settings → Accounts and backup → Manage accounts</b> → your Google account → <b>Sync account</b> → turn on <b>Calendar</b>`,
    `In Samsung Calendar, when you make an event, tap the calendar name and pick your <b>Google</b> one`,
    `Now do the <b>Google</b> steps (button above) - those events show up here`] },
  other: { name: "a calendar link", app: "its own app", icon: "🔗", steps: [
    `School, sports team, work, holidays - look for <b>Subscribe</b>, <b>iCal</b>, <b>ICS</b> or <b>webcal</b>`,
    `Copy that address`, `Paste it below → <b>Link it</b>`] },
};
let calNewKind = null;
function openCalNew(kind) {
  calNewKind = kind || null;
  const st = cal.icloud || {};
  $("calsheet-title").textContent = "＋ Add a calendar";
  const k = CAL_LINK_KINDS[calNewKind];
  $("calsheet-body").innerHTML = !calNewKind ? `
    ${cal.can_make ? `<h4>✨ Make a new one</h4>
    <form class="cal-new-form" data-cal-make autocomplete="off">
      <input id="calnew-name" maxlength="40" placeholder="Name it - Sports, Bills, Date night…" required>
      <div class="cal-swatches cal-swatches-sm">${CAL_SWATCHES.slice(0, 10).map((x, i) => `<button type="button" class="${i ? "" : "on"}" style="background:${x}" data-calnew-color="${x}"></button>`).join("")}</div>
      ${st.connected ? `<div class="chips"><label><input type="radio" name="calnew-where" value="deckos" checked> In Deck OS</label><label><input type="radio" name="calnew-where" value="icloud"> In iCloud (on every iPhone)</label></div>` : ""}
      <button class="accent-btn">Make it</button>
    </form>` : ""}
    <h4>🔗 Link one you already have</h4>
    <div class="cal-kinds">
      ${st.can_connect ? `<button data-cal-kind="apple">🍎<b>Apple / iCloud</b><small>${st.connected ? "connected ✓" : "change events too"}</small></button>` : ""}
      <button data-cal-kind="google">🟦<b>Google</b><small>see events</small></button>
      <button data-cal-kind="outlook">📧<b>Outlook</b><small>see events</small></button>
      <button data-cal-kind="samsung">📱<b>Samsung</b><small>through Google</small></button>
      <button data-cal-kind="other">🔗<b>Any link</b><small>school, team…</small></button>
    </div>`
    : `<button class="link-btn" data-cal-kind="">‹ back</button>
    <h4>${k.icon} Link ${esc(k.name)}</h4>
    <ol class="small cal-steps">${k.steps.map((x) => `<li>${x}</li>`).join("")}</ol>
    ${calNewKind === "samsung" ? `<button class="small-btn" data-cal-kind="google">🟦 Show me the Google steps</button>`
      : `<form class="cal-new-form" data-cal-link-form autocomplete="off">
      <input id="callink-url" placeholder="https://… or webcal://…" required inputmode="url">
      <input id="callink-name" maxlength="40" placeholder="Name (optional) - e.g. Work">
      <button class="accent-btn">Link it</button></form>
      <small class="muted">Deck OS shows these events and keeps them up to date. Add or change them in ${esc(k.app)}. Keep the link private - anyone with it can see that calendar.</small>`}`;
  $("calsheet-modal").hidden = false;
}
$("cal-card").addEventListener("click", (e) => { if (e.target.closest("[data-cal-new]")) openCalNew(); });
$("calsheet-modal").addEventListener("click", async (e) => {
  const kind = e.target.closest("[data-cal-kind]");
  if (kind) {
    if (kind.dataset.calKind === "apple") { $("calsheet-modal").hidden = true; icloudOpen = !(cal.icloud || {}).connected; drawICloud(); $("icloud-card").scrollIntoView({ behavior: "smooth", block: "center" }); return; }
    return openCalNew(kind.dataset.calKind);
  }
  const sw = e.target.closest("[data-calnew-color]");
  if (sw) { e.target.closest(".cal-swatches").querySelectorAll("button").forEach((b) => b.classList.toggle("on", b === sw)); return; }
  const rm = e.target.closest("[data-cal-remove]");
  if (rm) {
    const c = calOf(calSheetFor);
    if (!rm.dataset.sure) { rm.dataset.sure = 1; rm.textContent = c.linked ? "Tap again to unlink" : `Tap again - delete ${c.name} and its events`; return; }
    try { await post("/api/calendar/remove", { calendar: calSheetFor }); $("calsheet-modal").hidden = true; toast(c.linked ? `🔗 ${c.name} unlinked` : `🗑 ${c.name} deleted`); loadCalendar(); }
    catch (err) { toast(err.message); }
  }
});
$("calsheet-modal").addEventListener("submit", async (e) => {
  e.preventDefault();
  const btn = e.target.querySelector(".accent-btn");
  btn.disabled = true;
  try {
    if (e.target.matches("[data-cal-make]")) {
      const color = (e.target.querySelector("[data-calnew-color].on") || {}).dataset?.calnewColor;
      const where = (e.target.querySelector('input[name="calnew-where"]:checked') || {}).value || "deckos";
      btn.textContent = "Making it…";
      const r = await post("/api/calendar/new", { name: $("calnew-name").value, color, where });
      toast(`📅 ${$("calnew-name").value} is ready${r.note ? " - " + r.note : ""}`);
    } else {
      btn.textContent = "Checking the link…";
      const r = await post("/api/calendar/links", { provider: calNewKind, url: $("callink-url").value, name: $("callink-name").value });
      toast(`🔗 ${r.name} linked - ${r.events} event${r.events === 1 ? "" : "s"}`);
    }
    $("calsheet-modal").hidden = true;
    setTimeout(loadCalendar, 800);
  } catch (err) { toast(err.message); btn.disabled = false; btn.textContent = e.target.matches("[data-cal-make]") ? "Make it" : "Link it"; }
});
async function setCalColor(color) {
  const c = calOf(calSheetFor);
  try {
    const r = await post("/api/calendar/color", { calendar: calSheetFor, color });
    c.color = color; drawCalendar(); openCalSheet(calSheetFor);
    toast(r.synced ? `🎨 ${c.name} - changed on your iPhone too` : `🎨 ${c.name} recolored`);
  } catch (err) { toast(err.message); }
}
$("cal-legend").addEventListener("click", (e) => { const b = e.target.closest("[data-cal-sheet]"); if (b) openCalSheet(b.dataset.calSheet); });
$("calsheet-modal").addEventListener("click", (e) => {
  if (e.target === $("calsheet-modal") || e.target.closest("#calsheet-close")) $("calsheet-modal").hidden = true;
  const sw = e.target.closest("[data-cal-color]");
  if (sw) setCalColor(sw.dataset.calColor);
  if (e.target.closest("[data-cal-link]")) {
    $("calsheet-modal").hidden = true; icloudOpen = true; drawICloud();
    $("icloud-card").scrollIntoView({ behavior: "smooth", block: "center" }); setTimeout(() => $("icloud-user") && $("icloud-user").focus(), 400);
  }
});
$("calsheet-modal").addEventListener("change", (e) => { if (e.target.matches("[data-cal-color-any]")) setCalColor(e.target.value); });
function calOf(id) { return cal.calendars.find((c) => c.id === id) || { name: id, color: "#888" }; }
function eventsOn(day) {
  return cal.events.filter((e) => (e.all_day ? e.start <= day && day < e.end : e.start.slice(0, 10) === day));
}
function drawCalendar() {
  const [y, m] = calMonth.split("-").map(Number);
  $("cal-title").textContent = new Date(y, m - 1, 1).toLocaleDateString([], { month: "long", year: "numeric" });
  $("cal-legend").innerHTML = cal.calendars.map((c) => `<button type="button" class="cal-chip" data-cal-sheet="${esc(c.id)}"><i style="background:${c.color}"></i>${esc(c.name)}${c.icloud ? ` <small class='muted'>${c.apple ? "🍎" : "iCloud"}</small>` : c.linked ? ` <small class='muted'>🔗</small>` : ""}</button>`).join("")
    + (cal.failed.length ? `<small class="muted">⚠️ couldn't load ${cal.failed.map(esc).join(", ")}</small>` : "");
  const start = new Date(cal.grid_start + "T12:00"), today = ymd(new Date());
  let html = ["S", "M", "T", "W", "T", "F", "S"].map((d) => `<b class="cal-dow">${d}</b>`).join("");
  for (let i = 0; i < 42; i++) {
    const d = new Date(start); d.setDate(start.getDate() + i);
    const day = ymd(d), evs = eventsOn(day);
    html += `<button class="cal-cell ${day.startsWith(calMonth) ? "" : "out"} ${day === today ? "today" : ""} ${day === calDay ? "sel" : ""}" data-cal-day="${day}">
      <span class="cal-num">${d.getDate()}${cal.wake && cal.wake.one_off[day] ? `<small class="cal-wake-dot" title="Wake-up ${clock12(cal.wake.one_off[day])} this day">⏰</small>` : ""}</span>
      <span class="cal-evs">${evs.slice(0, 3).map((e) => `<i style="background:${calOf(e.calendar).color}" title="${esc(e.summary)}"><em>${esc(e.summary)}</em></i>`).join("")}${evs.length > 3 ? `<small>+${evs.length - 3}</small>` : ""}</span></button>`;
  }
  $("cal-grid").innerHTML = html;
  drawCalDay();
  const added = cal.added;
  $("cal-added").innerHTML = added.length ? `<h3 class="cal-h">✅ Did it make it? <small class="muted">events Deck OS added</small></h3>${added.map((a) => {
    const c = calOf(a.calendar);
    const state = a.found ? `<b class="good">✅ in ${esc(c.name)}${c.icloud ? " (iCloud)" : ""}</b>` : a.fresh ? `<b class="ok">⏳ on its way</b><small class="muted">iCloud checks about every 15 min</small>` : `<b class="low">⚠️ not showing in ${esc(c.name)}</b><small class="muted">check your Calendar app</small>`;
    return `<div class="cal-added-row"><span><i style="background:${c.color}"></i>${esc(a.summary)} <small class="muted">${new Date(a.start).toLocaleDateString([], { month: "short", day: "numeric" })} ${calTime(a.start)}</small></span><span class="cal-state">${state}</span></div>`;
  }).join("")}` : "";
}
function drawCalDay() {
  const evs = eventsOn(calDay);
  const label = new Date(calDay + "T12:00").toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" });
  $("cal-day").innerHTML = `<h3 class="cal-h">${label}</h3>` + (evs.length ? evs.map((e) => {
    const c = calOf(e.calendar);
    return `<div class="cal-ev" style="--cal:${c.color}"><span class="cal-ev-time">${e.all_day ? "all day" : calTime(e.start)}</span>
      <span class="cal-ev-main"><b>${esc(e.summary)}</b><small class="muted">${esc(c.name)}${c.icloud ? " · iCloud" : ""}${e.location ? " · " + esc(e.location) : ""}${e.rrule ? " · repeats" : ""}</small></span>
      <button class="small-btn" data-cal-edit="${esc(e.uid || "")}" data-cal-rid="${esc(e.rid || "")}" data-cal-cal="${esc(e.calendar)}">${c.can_edit ? "✏️ Edit" : "👁"}</button></div>`;
  }).join("") : `<p class="muted small">Nothing on this day.</p>`) + calWakeRow();
}
// ⏰ The owner's wake-up for the picked day: a different time for just that day, then it's back to the normal alarm the next day
function calWakeOn(day) {
  const w = cal && cal.wake;
  if (!w) return null;
  const once = w.one_off[day], dow = (new Date(day + "T12:00").getDay() + 6) % 7;
  const normal = w.enabled && w.days.includes(dow) && !w.skip.includes(day) ? w.time : null;
  return { once, normal, at: once || normal };
}
const clock12 = (t) => new Date(`2000-01-01T${t}`).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
function calWakeRow() {
  const w = calWakeOn(calDay);
  if (!w || calDay < ymd(new Date())) return "";
  const now = w.once ? `<b>${clock12(w.once)}</b> <small class="muted">just this day${w.normal ? ` · normally ${clock12(w.normal)}` : ""}</small>`
    : w.normal ? `<b>${clock12(w.normal)}</b> <small class="muted">your normal alarm</small>` : `<span class="muted">no alarm this day</span>`;
  return `<div class="cal-wake"><span class="cal-wake-now">⏰ Wake-up: ${now}</span>
    <span class="cal-wake-set"><input type="time" id="cal-wake-time" value="${w.at || "06:30"}" aria-label="Wake-up time for this day">
    <button class="small-btn" data-cal-wake>${w.once ? "Change" : "Set for this day"}</button>
    ${w.once ? `<button class="small-btn" data-cal-wake-clear>↩ Back to normal</button>` : ""}</span></div>`;
}
async function calWakeSave(clear) {
  const time = $("cal-wake-time").value;
  if (!clear && !time) return toast("Pick a time first");
  try {
    const r = await post("/api/calendar/wake", clear ? { date: calDay, clear: true } : { date: calDay, time });
    cal.wake = r.wake;
    const label = new Date(calDay + "T12:00").toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" });
    toast(clear ? `⏰ ${label} is back to your normal alarm` : `⏰ Wake-up ${clock12(time)} on ${label} - the next day goes back to normal`);
    drawCalendar();
  } catch (err) { toast(err.message || "Couldn't change the alarm"); }
}
$("cal-card").addEventListener("click", (e) => {
  const mv = e.target.closest("[data-cal-move]");
  if (mv) {
    const [y, m] = calMonth.split("-").map(Number), d = new Date(y, m - 1 + Number(mv.dataset.calMove), 1);
    calMonth = ymd(d).slice(0, 7); calDay = null; return loadCalendar();
  }
  if (e.target.closest("[data-cal-today]")) { calMonth = null; calDay = null; return loadCalendar(); }
  const cell = e.target.closest("[data-cal-day]");
  if (cell) {
    calDay = cell.dataset.calDay;
    if (!calDay.startsWith(calMonth)) { calMonth = calDay.slice(0, 7); return loadCalendar(); }
    document.querySelectorAll(".cal-cell.sel").forEach((x) => x.classList.remove("sel")); cell.classList.add("sel");
    return drawCalDay();
  }
  if (e.target.closest("[data-cal-wake]")) return calWakeSave(false);
  if (e.target.closest("[data-cal-wake-clear]")) return calWakeSave(true);
  if (e.target.closest("[data-cal-add]")) return openCalEvent(null);
  const ed = e.target.closest("[data-cal-edit]");
  if (ed) openCalEvent(cal.events.find((x) => x.uid === ed.dataset.calEdit && (x.rid || "") === ed.dataset.calRid && x.calendar === ed.dataset.calCal && eventsOn(calDay).includes(x)));
});

function openCalEvent(ev) {
  calEditing = ev;
  const c = ev ? calOf(ev.calendar) : null, readOnly = ev && !c.can_edit;
  $("calev-title").textContent = ev ? (readOnly ? "📅 Event" : "✏️ Edit event") : "📅 New event";
  const addable = cal.calendars.filter((x) => x.can_add);
  const movable = ev && c.can_delete && !ev.rrule && !ev.rid;
  $("calev-cal").innerHTML = (ev ? (movable ? [c, ...addable.filter((x) => x.id !== c.id)] : [c]) : addable).map((x) => `<option value="${esc(x.id)}">${esc(x.name)}${x.icloud ? " (iCloud)" : ""}</option>`).join("");
  $("calev-cal").disabled = !!ev && !movable;
  $("calev-summary").value = ev ? ev.summary : "";
  $("calev-date").value = ev ? ev.start.slice(0, 10) : calDay;
  $("calev-allday").checked = ev ? ev.all_day : false;
  $("calev-time").value = ev && !ev.all_day ? new Date(ev.start).toTimeString().slice(0, 5) : "09:00";
  const mins = ev && !ev.all_day ? Math.round((new Date(ev.end) - new Date(ev.start)) / 60000) : 60;
  if (![...$("calev-mins").options].some((o) => +o.value === mins)) $("calev-mins").insertAdjacentHTML("beforeend", `<option value="${mins}">${mins} min</option>`);
  $("calev-mins").value = String(mins);
  $("calev-loc").value = ev ? ev.location : "";
  document.querySelectorAll("#calev-modal input, #calev-modal select:not(#calev-cal)").forEach((i) => (i.disabled = !!readOnly));
  $("calev-save").hidden = !!readOnly;
  $("calev-delete").hidden = !ev || !c.can_delete;
  $("calev-note").textContent = readOnly ? `${c.name} is an iCloud calendar - ${cal.icloud && cal.icloud.can_connect ? "connect iCloud (button under the calendar) to change it here" : "change this one in your Calendar app"}.`
    : ev && ev.rrule ? "This one repeats - changes apply to just this day." : !ev && addable.some((x) => x.icloud) ? "Events added to an iCloud calendar show up on your iPhone within about 15 minutes." : "";
  calTimedToggle();
  $("calev-modal").hidden = false;
}
function calTimedToggle() { document.querySelectorAll(".calev-timed").forEach((r) => (r.hidden = $("calev-allday").checked)); }
$("calev-allday").addEventListener("change", calTimedToggle);
$("calev-close").addEventListener("click", () => ($("calev-modal").hidden = true));
$("calev-save").addEventListener("click", async () => {
  const body = { calendar: $("calev-cal").value, summary: $("calev-summary").value, date: $("calev-date").value, all_day: $("calev-allday").checked,
    time: $("calev-time").value, minutes: +$("calev-mins").value, location: $("calev-loc").value };
  const old = calEditing && { calendar: calEditing.calendar, uid: calEditing.uid, rid: calEditing.rid, old_summary: calEditing.summary, old_start: calEditing.all_day ? calEditing.start.slice(0, 10) + "T00:00" : calEditing.start.slice(0, 16) };
  const moving = calEditing && body.calendar !== calEditing.calendar;
  if (calEditing && !moving) Object.assign(body, { uid: old.uid, rid: old.rid, old_summary: old.old_summary, old_start: old.old_start });
  try {
    await post("/api/calendar/event", body);
    if (moving) await post("/api/calendar/event", { ...old, delete: true });  // re-filed: now it's only in the new calendar
    $("calev-modal").hidden = true; calDay = body.date; calMonth = body.date.slice(0, 7);
    toast(calEditing ? "✏️ Changed" : "📅 Added"); loadCalendar(); if (typeof loadToday === "function") loadToday(true);
  } catch (err) { toast(err.message); }
});
$("calev-delete").addEventListener("click", async () => {
  const b = $("calev-delete");
  if (!b.dataset.sure) { b.dataset.sure = 1; b.textContent = "Tap again to delete"; setTimeout(() => { delete b.dataset.sure; b.textContent = "Delete event"; }, 2500); return; }
  try { await post("/api/calendar/event", { calendar: calEditing.calendar, uid: calEditing.uid, rid: calEditing.rid, delete: true, old_summary: calEditing.summary, old_start: calEditing.all_day ? calEditing.start.slice(0, 10) + "T00:00" : calEditing.start.slice(0, 16) }); $("calev-modal").hidden = true; toast("🗑 Deleted"); loadCalendar(); if (typeof loadToday === "function") loadToday(true); }
  catch (err) { toast(err.message); }
});

// tap an event in Home's "coming up" list -> the same editor as the calendar view
$("today-events").addEventListener("click", async (e) => {
  const li = e.target.closest("[data-home-ev]");
  if (!li) return;
  const start = li.dataset.homeStart, month = start.slice(0, 7);
  try {
    if (!cal || cal.month !== month) { calMonth = month; cal = await api(`/api/calendar?month=${month}`); }
  } catch (err) { return toast(err.message); }
  const ev = cal.events.find((x) => (x.uid || "") === li.dataset.homeEv && (x.rid || "") === li.dataset.homeRid && x.calendar === li.dataset.homeCal)
    || cal.events.find((x) => x.calendar === li.dataset.homeCal && x.start.slice(0, 16) === start.slice(0, 16));
  if (!ev) return toast("Couldn't find that event - it may have just changed");
  calDay = ev.start.slice(0, 10);
  openCalEvent(ev);
});
