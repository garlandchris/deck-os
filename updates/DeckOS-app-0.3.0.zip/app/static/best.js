// 💪 Best me (owner only): a week of real-world things - workouts, your team, sleep, steps, weigh-ins, trading calls, money.
// No points and nothing for screen time. Blank days are just blank - no red X's. Numbers come only from real sources;
// where there's no automatic source you log it with one tap (tap a day on the page to fix a day you forgot).
let best = null, bestAt = 0;
const bestOk = () => typeof isOwnerHere === "function" && isOwnerHere() && !status.door;

async function loadBest(force) {
  if (!force && best && Date.now() - bestAt < 5 * 60000) return best;
  bestAt = Date.now();
  try { best = await api("/api/best"); } catch { best = null; }
  return best;
}
async function bestLog(what, day) {
  try { best = await post("/api/best/log", { what, day }); bestAt = Date.now(); } catch (err) { return toast(err.message); }
  drawHomeBest(); if (currentPanel === "best") drawBest();
}

// Home card: 7 little days + today's one-tap logs + the best real win
async function drawHomeBest() {
  const box = $("best-card"); if (!box) return;
  if (!status || status.demo || !bestOk()) { box.hidden = true; return; }
  const b = await loadBest(); box.hidden = !b; if (!b) return;
  const t = b.today, team = b.team;
  const dots = b.grid.map((g) => `<span class="best-dot${g.run || g.gym || g.game || g.reps ? " on" : ""}" title="${esc(g.label)}">${esc(g.label[0])}</span>`).join("");
  const chip = (what, label, on) => `<button class="small-btn${on ? " on" : ""}" data-best-log="${what}">${on ? "✓ " : ""}${label}</button>`;
  box.innerHTML = `<h2>💪 Best me ${b.streak >= 2 ? `<small class="muted">🔥 ${b.streak} days moving</small>` : ""}</h2>
    ${nudgeCard(b.nudge)}${sleepLine(b.lastnight) && !(b.nudge && b.lastnight && b.lastnight.mins >= 600) ? `<p>${sleepLine(b.lastnight)}</p>` : ""}
    <div class="best-dots">${dots}</div>${ytChip(b.youtube)}${incomeHomeChip(b)}
    <p class="muted">${esc(b.wins[0] || "New week - any one real thing counts.")}</p>
    <div class="quiz-row">${t.run ? '<span class="small-btn on">✓ ☀️ Morning Run</span>' : ""}${chip("gym", "🏋️ Gym", t.gym)}${team ? chip("game", "🏒 Game", t.game) : ""}
      ${b.pushups ? `<button class="small-btn${b.pushups.today ? " on" : ""}" data-best-push-go>💪 ${b.pushups.today ? `${b.pushups.today} push-ups` : "Push-ups"}</button>` : ""}
      <button class="small-btn${b.grid[b.grid.length - 1].reps ? " on" : ""}" data-best-reps-go>🔢 ${b.grid[b.grid.length - 1].reps ? `${b.grid[b.grid.length - 1].reps} reps today` : "Log reps"}</button>
      ${t.sleep_auto || (b.lastnight && b.lastnight.mins) ? "" : chip("sleep_good", "😴 Slept 7h+", t.sleep_log === "good")}
      <button class="accent-btn small-btn" data-go="best">Open</button></div>`;
}
if ($("best-card")) $("best-card").addEventListener("click", (e) => {
  const l = e.target.closest("[data-best-log]"); if (l) return bestLog(l.dataset.bestLog);
  if (e.target.closest("[data-best-reps-go]")) { repsFocus = true; return go("best"); }
  if (e.target.closest("[data-best-push-go]")) { pushFocus = true; return go("best"); }
  if (e.target.closest("[data-inc-go]")) { incFocus = true; return go("best"); }
  const g = e.target.closest("[data-go]"); if (g) go(g.dataset.go);
});

async function loadBestPage() {
  $("best-body").innerHTML = '<p class="muted">Loading…</p>';
  await loadBest(true);
  drawBest();
}
function drawBest() {
  const box = $("best-body"), b = best;
  if (!b) { box.innerHTML = '<p class="muted">Couldn\'t load this right now.</p>'; return; }
  const G = b.grid, team = b.team;
  const head = `<tr><th></th>${G.map((g) => `<th>${esc(g.label === "Today" ? "Today" : g.label)}<small>${g.n}</small></th>`).join("")}</tr>`;
  const tap = (g, what, inner) => `<td><button class="best-cell" data-best-log="${what}" data-day="${g.day}">${inner || '<span class="best-blank">·</span>'}</button></td>`;
  const row = (label, cells) => { const [e, ...r] = label.split(" "); return `<tr><th title="${r.join(" ")}">${e}<span class="best-lbl"> ${r.join(" ")}</span></th>${cells}</tr>`; };
  const sleepCell = (g) => g.sleep ? `<td><span class="${g.sleep >= 7 ? "best-good" : ""}" title="${g.sleep_src === "measured" ? "bed → up, measured" : "iPhone Health"}">${g.sleep}h</span></td>`
    : tap(g, g.sleep_log === "good" ? "sleep_short" : g.sleep_log === "short" ? "sleep_short" : "sleep_good",
      g.sleep_log === "good" ? '<span class="best-good">7h+</span>' : g.sleep_log === "short" ? "🥱" : "");
  const rows = [
    row("☀️ Morning Run", G.map((g) => `<td>${g.run ? '<span class="best-good">✓</span>' : '<span class="best-blank">·</span>'}</td>`).join("")),
    row("🏋️ Gym", G.map((g) => tap(g, "gym", g.gym ? '<span class="best-good">✓</span>' : "")).join("")),
    team ? row(`🏒 ${esc(team.name)}`, G.map((g) => tap(g, "game", g.game ? '<span class="best-good">✓</span>' : "")).join("")) : "",
    row("🔢 Reps", G.map((g) => `<td><button class="best-cell" data-reps-day="${g.day}">${g.reps ? `<span class="best-good">${g.reps}</span>` : '<span class="best-blank">·</span>'}</button></td>`).join("")),
    row("😴 Sleep", G.map(sleepCell).join("")),
    G.some((g) => g.wake) ? row("⏰ Up in", G.map((g) => { const w = g.wake; return `<td>${!w ? '<span class="best-blank">·</span>' : w.how === "missed" ? '<span title="the alarm gave up">✗</span>'
      : w.mins == null ? '<span class="best-good" title="beat the alarm">✓</span>' : `<span class="${w.mins <= 5 ? "best-good" : ""}" title="minutes from the alarm to beating it">${w.mins}m</span>`}</td>`; }).join("")) : "",
    row("👟 Steps", G.map((g) => `<td>${g.steps == null ? '<span class="best-blank">·</span>' : `<span class="${g.steps >= 8000 ? "best-good" : ""}">${g.steps >= 1000 ? (g.steps / 1000).toFixed(1) + "k" : g.steps}</span>`}</td>`).join("")),
    row("⚖️ Weigh-in", G.map((g) => `<td>${g.weigh ? '<span class="best-good">✓</span>' : '<span class="best-blank">·</span>'}</td>`).join("")),
    b.youtube && b.youtube.loaded ? row("🎬 Upload", G.map((g) => `<td>${g.upload ? `<span class="best-good">✓${g.upload > 1 ? g.upload : ""}</span>` : '<span class="best-blank">·</span>'}</td>`).join("")) : "",
    row("📈 Calls", G.map((g) => `<td>${g.calls ? `<span title="right / early / wrong">✅${g.calls.right}${g.calls.early ? ` ⏰${g.calls.early}` : ""}${g.calls.wrong ? ` ❌${g.calls.wrong}` : ""}</span>` : '<span class="best-blank">·</span>'}</td>`).join("")),
    b.phone_calls ? row("📞 Phone calls", G.map((g) => `<td>${g.phone ? `<span class="best-good">${g.phone}</span>` : '<span class="best-blank">·</span>'}</td>`).join("")) : "",
  ].join("");
  const pc = b.phone_calls, callsCard = pc && pc.recent.length ? `<div class="card best-calls"><h4>📞 Calls you logged</h4><ul>${pc.recent.map((c) =>
      `<li>${esc(c.name)} <small class="muted">${new Date(c.day + "T12:00").toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" })} · ${esc(c.time)}</small></li>`).join("")}</ul>
      <p class="muted small">Say "Hey Elara, log a call with Mom" after you hang up.</p><button class="small-btn" data-go="calls">📞 Call notes</button></div>` : "";
  const m = b.money, d = (x) => x ? new Date(x + "T12:00").toLocaleDateString([], { month: "short", year: "numeric" }) : "";
  const money = m ? `<div class="card best-money"><h4>💰 Money</h4><p>Debt <b>$${m.debt.toLocaleString()}</b>${m.change == null ? "" : m.change < 0 ? ` · <span class="best-good">down $${(-m.change).toLocaleString()} this week</span>` : m.change > 0 ? ` · up $${m.change.toLocaleString()} this week` : " · same as last week"}</p>
      ${m.next ? `<p>Next: ${esc(m.next.e || "")} <b>${esc(m.next.t)}</b>${m.next.date ? ` by ${d(m.next.date)}` : ""}</p>` : ""}
      <button class="small-btn" data-go="money">🪜 Money plan</button></div>`
    : `<div class="card best-money"><h4>💰 Money</h4><p class="muted">I don't have your budget numbers right now, so nothing to show.</p></div>`;
  const teamCard = team ? `<div class="card best-team"><h4>🏒 ${esc(team.name)}</h4><p>${[team.league, team.starts && `starts ${team.starts}`, team.paid && `✅ ${team.paid}`].filter(Boolean).map(esc).join(" · ")}</p>
      <details><summary class="muted">Edit team</summary>${teamForm(team)}</details></div>`
    : `<details class="card best-team"><summary>🏒 Add your team (games show up here)</summary>${teamForm({})}</details>`;
  const src = b.sources;
  box.innerHTML = `${b.nudge ? `<div class="card">${nudgeCard(b.nudge)}</div>` : ""}${sleepCard(b)}<div class="card best-wins"><h4>🏆 Your last 7 days</h4>${b.wins.length ? `<ul>${b.wins.map((w) => `<li>${esc(w)}</li>`).join("")}</ul>` : '<p class="muted">Fresh week - any one real thing counts. Tap a box below when you do it.</p>'}</div>${incomeCard(b)}
    <div class="card best-week"><table class="best-table">${head}${rows}</table>
      <p class="muted small">Tap a box under 🏋️ Gym${team ? ", 🏒" : ""} or 😴 Sleep to log a day (tap again to undo). The rest fills in by itself.</p></div>
    ${pushupsCard(b)}${repsCard(b)}${ytCard(b.youtube)}${callsCard}<div id="best-places"></div>${money}${teamCard}
    <details class="card best-src"><summary class="muted">Where these numbers come from</summary><ul class="muted small">
      <li>☀️ Morning Run sets you finished in Deck OS</li>
      <li>😴 Sleep: bed → up from real signals (Elara goodnight or your phone going on the charger at home; the wake alarm's photo or the phone coming off the charger), else ${src.sleep ? "your iPhone's Health app on nights it reported" : "your iPhone's Health app (nothing this week)"}, else your tap. A tap or a fix always wins.</li>
      <li>📍 Places: your iPhone's location in Home Assistant - stays on this PC</li>
      <li>👟 Steps: ${src.steps ? "your iPhone (the day's total)" : "not coming in from your iPhone right now"}</li>
      <li>⚖️ Weigh-ins: ${src.health ? "the ❤️ Health page" : "the ❤️ Health page isn't running right now"}</li>
      <li>📈 Calls: your trading calls as graded (right / early / wrong)</li>
      <li>📞 Phone calls: only the ones you log by voice with Elara (nothing reads your phone's call list)</li>
      <li>🎬 Uploads: your YouTube channel's public list of its latest videos (checked every 30 min, no login)</li>
      <li>💸 Income goal: the Sell page (things marked sold) plus what you log here or tell Elara - no bank is read for it</li>
      <li>💰 Money: the budget coach (your bank, read only) and your money plan</li>
      <li>🏋️ Gym${team ? " and 🏒 games" : ""}, 🔢 reps: only what you tap</li></ul></details>`;
  drawBestAfter();
  if (pushFocus) { pushFocus = false; const c = $("best-push"); if (c) { c.scrollIntoView({ block: "center" }); } }
  if (incFocus) { incFocus = false; const c = $("best-income"); if (c) { c.scrollIntoView({ block: "start" }); } }
  if (repsFocus) { repsFocus = false; const c = $("best-reps"); if (c) { c.scrollIntoView({ block: "center" }); } }
}
function drawBestAfter() { drawPlaces(); }

// 💪 Push-ups: today's total big, slide (or tap a chip / − +) to how many, Log. 1-200 a set; sets add up into the 🔢 Reps log.
// Reminders: Elara once when you're home after a time with none logged, a phone ping late if still none.
let pushN = 20, pushFocus = false;
function pushupsCard(b) {
  const p = b.pushups; if (!p) return "";
  pushN = Math.max(1, Math.min(p.max, pushN));
  return `<div class="card best-push" id="best-push"><h4>💪 Push-ups <small class="muted">${p.week ? `${p.week.toLocaleString()} this week` : ""}</small></h4>
    <p class="best-push-total"><b>${p.today.toLocaleString()}</b> today${p.sets.length > 1 ? ` <span class="muted small">(${p.sets.join(" + ")})</span>` : ""}</p>
    <div class="quiz-row">${[5, 10, 15, 20, 25, 30, 40, 50, 75, 100].map((n) => `<button class="small-btn${n === pushN ? " on" : ""}" data-push-pick="${n}">${n}</button>`).join("")}</div>
    <div class="quiz-row"><button class="small-btn" data-push-step="-1">−</button>
      <input id="push-range" type="range" min="1" max="${p.max}" step="1" value="${pushN}" style="flex:1;min-width:120px">
      <button class="small-btn" data-push-step="1">+</button></div>
    <div class="quiz-row"><button class="accent-btn" data-push-log>Log <span id="push-n">${pushN}</span> push-ups</button></div>
    <p class="muted small">🎙 Or tell Elara: "log 25 push-ups" · "have I logged my push-ups today?"</p>
    <details class="muted small"><summary>🔔 Reminders</summary>
      <label><input type="checkbox" data-push-set="on"${p.on ? " checked" : ""}> Remind me when none are logged</label><br>
      Elara says it once I'm home after <input type="time" data-push-set="home_after" value="${esc(p.home_after)}"><br>
      Phone ping if still none by <input type="time" data-push-set="last_call" value="${esc(p.last_call)}"></details></div>`;
}
function pushShow() {
  const r = $("push-range"); if (r) r.value = pushN;
  if ($("push-n")) $("push-n").textContent = pushN;
  document.querySelectorAll("[data-push-pick]").forEach((x) => x.classList.toggle("on", +x.dataset.pushPick === pushN));
}
async function pushPost(body) {
  try { best = await post("/api/best/pushups", body); bestAt = Date.now(); } catch (err) { return toast(err.message); }
  drawBest(); drawHomeBest();
}
if ($("best-body")) {
  $("best-body").addEventListener("input", (e) => { if (e.target.id === "push-range") { pushN = +e.target.value; pushShow(); } });
  $("best-body").addEventListener("change", (e) => {
    const s = e.target.closest("[data-push-set]"); if (!s) return;
    const k = s.dataset.pushSet;
    if (k !== "on" && !s.value) return;
    pushPost({ [k]: k === "on" ? s.checked : s.value });
  });
  $("best-body").addEventListener("click", (e) => {
    const pk = e.target.closest("[data-push-pick]"); if (pk) { pushN = +pk.dataset.pushPick; return pushShow(); }
    const st = e.target.closest("[data-push-step]");
    if (st) { pushN = Math.max(1, Math.min(best.pushups.max, pushN + +st.dataset.pushStep)); return pushShow(); }
    if (e.target.closest("[data-push-log]")) { toast(`💪 ${pushN} push-ups logged`); return pushPost({ n: pushN }); }
  });
}

// 🔢 Reps you count yourself (no camera needed): pick the exercise, type how many, Add. Adds stack up through the day.
let repsDay = "", repsEx = "Push-ups", repsFocus = false;
function repsCard(b) {
  const r = b.reps; if (!r) return "";
  const days = b.grid.map((g) => g.day), day = days.includes(repsDay) ? repsDay : days[days.length - 1];
  const picks = [...new Set([...r.picks, ...Object.keys(r.week)])];
  const tot = r.days[day] || {}, list = r.entries[day] || [];
  const label = (d) => { const g = b.grid.find((x) => x.day === d); return g.label === "Today" ? "Today" : `${g.label} ${g.n}`; };
  return `<div class="card best-reps" id="best-reps"><h4>🔢 Reps</h4>
    <div class="quiz-row">${days.slice().reverse().map((d) => `<button class="small-btn${d === day ? " on" : ""}" data-reps-day="${d}">${esc(label(d))}</button>`).join("")}</div>
    <div class="quiz-row">${picks.map((x) => `<button class="small-btn${x === repsEx ? " on" : ""}" data-reps-ex="${esc(x)}">${esc(x)}</button>`).join("")}</div>
    <div class="quiz-row"><input id="reps-ex" maxlength="30" placeholder="Exercise" value="${esc(repsEx)}">
      <input id="reps-n" type="number" inputmode="numeric" min="1" max="2000" placeholder="How many">
      <button class="accent-btn small-btn" data-reps-add>Add</button></div>
    ${Object.keys(tot).length ? `<p>${esc(label(day))}: ${Object.entries(tot).map(([x, n]) => `<b>${n.toLocaleString()}</b> ${esc(x.toLowerCase())}`).join(" · ")}</p>
      <ul class="muted small">${list.map((e) => `<li>${e.n} ${esc(e.ex.toLowerCase())} <button class="link-btn small" data-reps-del="${e.i}" title="take this one back">✕</button></li>`).join("")}</ul>`
      : `<p class="muted">Nothing logged ${day === days[days.length - 1] ? "today" : "that day"} yet. Did a set? Type the number and tap Add - sets add up.</p>`}
    ${Object.keys(r.week).length ? `<p class="muted small">Last 7 days: ${Object.entries(r.week).sort((a, b2) => b2[1] - a[1]).map(([x, n]) => `${n.toLocaleString()} ${esc(x.toLowerCase())}`).join(" · ")}</p>` : ""}</div>`;
}
async function repsPost(body) {
  try { best = await post("/api/best/reps", body); bestAt = Date.now(); } catch (err) { return toast(err.message); }
  drawBest(); drawHomeBest();
}
if ($("best-body")) $("best-body").addEventListener("click", (e) => {
  const d = e.target.closest("[data-reps-day]");
  if (d) { repsDay = d.dataset.repsDay; repsFocus = !d.closest("#best-reps"); return drawBest(); }
  const x = e.target.closest("[data-reps-ex]");
  if (x) { repsEx = x.dataset.repsEx; $("reps-ex").value = repsEx; document.querySelectorAll("[data-reps-ex]").forEach((b) => b.classList.toggle("on", b === x)); return $("reps-n").focus(); }
  const del = e.target.closest("[data-reps-del]");
  if (del) return repsPost({ day: repsDay || best.grid[best.grid.length - 1].day, remove: +del.dataset.repsDel });
  if (e.target.closest("[data-reps-add]")) {
    const ex = $("reps-ex").value.trim(), n = +$("reps-n").value;
    if (!ex) return toast("Which exercise?");
    if (!n || n < 1) { $("reps-n").focus(); return toast("How many?"); }
    repsEx = ex; toast(`🔢 ${n} ${ex.toLowerCase()} logged`);
    return repsPost({ ex, n, day: repsDay || best.grid[best.grid.length - 1].day });
  }
});
if ($("best-body")) $("best-body").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && e.target.id === "reps-n") { e.preventDefault(); document.querySelector("[data-reps-add]").click(); }
});
function teamForm(t) {
  return `<div class="route-form best-team-form"><input id="bt-name" maxlength="40" placeholder="Team name" value="${esc(t.name || "")}">
    <input id="bt-league" maxlength="40" placeholder="League" value="${esc(t.league || "")}">
    <input id="bt-starts" maxlength="30" placeholder="Season starts (e.g. November)" value="${esc(t.starts || "")}">
    <input id="bt-paid" maxlength="40" placeholder="Paid? (e.g. $230 paid)" value="${esc(t.paid || "")}">
    <div class="quiz-row"><button class="accent-btn small-btn" data-best-team="save">Save</button>${t.name ? '<button class="small-btn" data-best-team="clear">Remove team</button>' : ""}</div></div>`;
}
if ($("best-body")) $("best-body").addEventListener("click", async (e) => {
  const l = e.target.closest("[data-best-log]"); if (l) return bestLog(l.dataset.bestLog, l.dataset.day);
  const g = e.target.closest("[data-go]"); if (g) return go(g.dataset.go);
  const t = e.target.closest("[data-best-team]"); if (!t) return;
  const body = t.dataset.bestTeam === "clear" ? { clear: true } : { name: $("bt-name").value, league: $("bt-league").value, starts: $("bt-starts").value, paid: $("bt-paid").value };
  try { best = await post("/api/best/team", body); toast(body.clear ? "Team removed" : "🏒 Saved"); drawBest(); drawHomeBest(); } catch (err) { toast(err.message); }
});

// 📍 Where you've been + 😴 last night (owner only, stays on the PC). From the iPhone's Home Assistant app location and the
// real bed/up signals (Elara goodnight, phone on/off the charger, the wake alarm's photo). Wrong? fix it with one tap.
const hm = (m) => `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, "0")}m`;
const clock = (iso) => new Date(iso).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }).replace(" ", "").toLowerCase();
function sleepLine(n) {
  if (!n) return "";
  if (n.none) return "😴 Last night: marked as no sleep to count";
  if (n.mins) return `😴 You slept <b>${hm(n.mins)}</b> <span class="muted">(${clock(n.bed)} → ${clock(n.wake)})</span>`;
  if (n.bed && n.awake_unknown) return `😴 Went to bed ${clock(n.bed)} <span class="muted">- not sure when you got up</span>`;
  if (n.health_mins) return `😴 iPhone Health: <b>${hm(n.health_mins)}</b> asleep`;
  return "";
}
function nudgeCard(nd) {
  return nd ? `<div class="best-nudge"><p><b>${esc(nd.head)}</b> Here's what you could do today:</p><ul>${nd.ideas.map((i) => `<li>${esc(i)}</li>`).join("")}</ul></div>` : "";
}
function sleepCard(b) {
  const n = b.lastnight, today = b.grid[b.grid.length - 1].day;
  const how = n && n.mins ? `<p class="muted small">Bed: ${esc(n.bed_how)} · Up: ${esc(n.wake_how)}${n.health_mins ? ` · iPhone Health counted ${hm(n.health_mins)} actually asleep` : ""}</p>` : "";
  const t = (iso, dflt) => iso ? new Date(iso).toTimeString().slice(0, 5) : dflt;
  return `<div class="card best-sleep"><h4>😴 Last night</h4>
    <p>${sleepLine(n) || '<span class="muted">No bed/up signal yet for last night - say "Elara goodnight", or charge your phone by the bed, and it fills in.</span>'}</p>${how}
    <details><summary class="muted">${n && n.mins ? "Not right? Fix it" : "Set it yourself"}</summary>
      <div class="quiz-row"><label>Bed <input type="time" id="sf-bed" value="${t(n && n.bed, "23:30")}"></label>
        <label>Up <input type="time" id="sf-wake" value="${t(n && n.wake, "07:30")}"></label>
        <button class="accent-btn small-btn" data-sleep-fix="save" data-day="${today}">Save</button>
        ${n && n.fixed ? `<button class="small-btn" data-sleep-fix="clear" data-day="${today}">Back to automatic</button>` : ""}</div></details></div>`;
}
let placesDay = "";
async function drawPlaces() {
  const box = $("best-places"); if (!box) return;
  let p; try { p = await api("/api/places" + (placesDay ? `?day=${placesDay}` : "")); } catch { box.innerHTML = ""; return; }
  if (!p.phone) { box.innerHTML = '<div class="card"><h4>📍 Where you\'ve been</h4><p class="muted">Pick your phone in Settings (phone notifications) and this fills in from its location.</p></div>'; return; }
  const dayChips = p.days.slice(0, 7).map((d) => `<button class="small-btn${d === p.day ? " on" : ""}" data-places-day="${d}">${d === p.days[0] ? "Today" : new Date(d + "T12:00").toLocaleDateString([], { weekday: "short", day: "numeric" })}</button>`).join("");
  const rows = p.timeline.map((x) => `<li class="place-${x.kind}"><span class="place-time">${clock(x.start)}–${clock(x.end)}</span>
      <b>${esc(x.label)}</b> <span class="muted">${hm(x.mins)}${x.addr ? " · " + esc(x.addr) : ""}</span>
      ${x.kind === "stop" ? `<button class="link-btn small" data-place-name="${esc(x.place + (x.addr ? "|" + x.addr : ""))}" data-place-town="${esc(x.place)}">name it</button>` : ""}</li>`).join("");
  box.innerHTML = `<div class="card best-places-card"><h4>📍 Where you've been</h4><div class="quiz-row">${dayChips}</div>
    ${p.totals.length ? `<p>${p.totals.map(([l, m]) => `${esc(l)} <b>${hm(m)}</b>`).join(" · ")}</p>` : ""}
    ${rows ? `<ol class="place-list">${rows}</ol>` : '<p class="muted">Nothing from your phone for this day.</p>'}
    <p class="muted small">🔒 Only you see this. It comes from your iPhone's Home Assistant app (the address is the one your iPhone looks up) and stays on your PC - nothing is sent anywhere. Kept 120 days.</p></div>`;
}
if ($("best-body")) $("best-body").addEventListener("click", async (e) => {
  const d = e.target.closest("[data-places-day]"); if (d) { placesDay = d.dataset.placesDay; return drawPlaces(); }
  const n = e.target.closest("[data-place-name]");
  if (n) {
    const li = n.closest("li"); if (li.querySelector(".place-name-form")) return;
    li.insertAdjacentHTML("beforeend", `<div class="quiz-row place-name-form"><input maxlength="30" placeholder="e.g. 🏢 Work or 🏒 Rink">
      <button class="accent-btn small-btn" data-place-save="${esc(n.dataset.placeName)}">Just this address</button>
      <button class="small-btn" data-place-save="${esc(n.dataset.placeTown)}">All of ${esc(n.dataset.placeTown)}</button></div>`);
    li.querySelector("input").focus(); return;
  }
  const s = e.target.closest("[data-place-save]");
  if (s) {
    const name = s.closest(".place-name-form").querySelector("input").value.trim();
    try { await post("/api/places/name", { key: s.dataset.placeSave, name, day: placesDay }); toast(name ? "📍 Saved" : "Name removed"); } catch (err) { return toast(err.message); }
    return drawPlaces();
  }
  const f = e.target.closest("[data-sleep-fix]"); if (!f) return;
  const body = f.dataset.sleepFix === "clear" ? { day: f.dataset.day, clear: true } : { day: f.dataset.day, bed: $("sf-bed").value, wake: $("sf-wake").value };
  try { best = await post("/api/sleep/fix", body); bestAt = Date.now(); toast("😴 Saved"); drawBest(); drawHomeBest(); } catch (err) { toast(err.message); }
});

// 🎬 Uploads: goal = 2 YouTube videos a week (Mon-Sun). From the channel's public feed - no login. Encouraging, never a red X.
function ytChip(y) {
  if (!y || !y.loaded) return "";
  return `<p class="best-yt-chip"><span class="small-btn${y.this_week >= y.goal ? " on" : ""}">🎬 ${Math.min(y.this_week, 99)}/${y.goal} this week</span></p>`;
}
function ytCard(y) {
  if (!y) return "";
  if (!y.loaded) return `<div class="card best-yt"><h4>🎬 Uploads</h4><p class="muted">Couldn't reach YouTube yet${y.checked ? ` (tried ${esc(y.checked)})` : ""} - it tries again every 30 minutes.</p></div>`;
  const n = y.this_week, g = y.goal;
  const pips = Array.from({ length: Math.max(g, n) }, (_, i) => `<span class="best-dot${i < n ? " on" : ""}">${i < n ? "✓" : i + 1}</span>`).join("");
  const kind = n ? ` <span class="muted">(${[y.videos && `${y.videos} video${y.videos > 1 ? "s" : ""}`, y.shorts && `${y.shorts} Short${y.shorts > 1 ? "s" : ""}`].filter(Boolean).join(" + ")})</span>` : "";
  const day = new Date().getDay(); // 0 Sun ... 6 Sat
  const say = n >= g ? "🎉 Goal hit this week - anything else is a bonus."
    : n === g - 1 ? "One more this week and the goal's done."
    : day >= 1 && day <= 3 ? "Fresh week - Creator mode is one key away (Super+Alt+Home)."
    : "Still time this week - a quick Short counts too.";
  const streak = y.streak >= 2 ? `<p>🔥 <b>${y.streak} weeks in a row</b> at ${g}+</p>` : y.last_week != null ? `<p class="muted">Last week: ${y.last_week} upload${y.last_week !== 1 ? "s" : ""}</p>` : "";
  const latest = y.latest.map((v) => `<li><a href="${esc(v.link)}" target="_blank" rel="noopener">${v.short ? "📱 " : ""}${esc(v.title)}</a>
      <span class="muted small">${new Date(v.when + "T12:00").toLocaleDateString([], { month: "short", day: "numeric", year: v.when.slice(0, 4) === String(new Date().getFullYear()) ? undefined : "numeric" })}${v.views != null ? ` · ${v.views.toLocaleString()} views` : ""}</span></li>`).join("");
  return `<div class="card best-yt"><h4>🎬 Uploads this week: ${n} / ${g}${kind}</h4><div class="best-dots">${pips}</div>
    <p>${esc(say)}</p>${streak}
    ${latest ? `<p class="muted small">Latest on your channel:</p><ol class="best-yt-list">${latest}</ol>` : ""}
    <p class="muted small">${y.error ? `⚠ Couldn't reach YouTube just now - showing what it said at ${esc(y.ok_at)}.` : `Checked ${esc(y.ok_at)}.`} Weeks are Mon–Sun.${y.known_since ? ` Counting back to ${new Date(y.known_since + "T12:00").toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" })}.` : ""}
    <a href="${esc(y.channel)}" target="_blank" rel="noopener">Your channel</a></p></div>`;
}

// 💸 Income goal: this month vs the goal (30k for the warehouse), every stream in one place, today's money moves, your goals.
// 🏷 Selling counts by itself from the Sell page; the rest is one tap here or by voice ("log 200 dollars from 3D prints").
const incUsd = (n) => "$" + Math.round(n || 0).toLocaleString();
function incomeHomeChip(b) {
  const v = b.income; if (!v || !v.goal) return "";
  return `<p class="best-yt-chip"><button class="small-btn${v.total >= v.goal ? " on" : ""}" data-inc-go>💸 ${incUsd(v.total)} / ${incUsd(v.goal)} · ${Math.round(v.pct)}%</button> <span class="muted small">${esc(v.pep)}</span></p>`;
}
function incomeCard(b) {
  const v = b.income; if (!v) return "";
  const live = v.streams.filter((s) => !s.hide);
  const opts = live.map((s) => `<option value="${esc(s.id)}">${esc(s.e)} ${esc(s.name)}</option>`).join("");
  const top = Math.max(v.goal, ...v.months.map((m) => m.total), 1);
  const bars = v.months.map((m) => `<div class="inc-mo${m.now ? " now" : ""}" title="${esc(m.m)}: ${incUsd(m.total)}"><i style="height:${Math.max(2, m.total / top * 100)}%"></i><small>${esc(m.m)}</small></div>`).join("");
  const streams = live.map((s) => `<li><span>${esc(s.e)} ${esc(s.name)}${s.auto === "sell" ? ' <small class="muted">(from the Sell page)</small>' : ""}</span>
      <b>${incUsd(s.month)}</b>${s.each ? `<small class="muted"> · ${s.units} × ${incUsd(s.each)}${s.gap_units ? ` · ${s.gap_units.toLocaleString()} more = goal` : ""}</small>` : ""}</li>`).join("");
  const goals = v.goals.map((g) => `<li class="inc-goal"><div>${esc(g.t)} <small class="muted">${g.unit === "$" ? `${incUsd(g.have)} / ${incUsd(g.target)}` : `${g.have} / ${g.target}`}</small>
      ${g.unit === "#" ? `<button class="small-btn" data-inc-bump="${g.id}">+1</button>` : ""}<button class="small-btn" data-inc-goal-del="${g.id}" title="Delete">✕</button></div>
      <div class="inc-bar"><i style="width:${g.pct}%"></i></div></li>`).join("");
  const moves = v.moves.map((m, i) => `<li><details${i ? "" : " open"}><summary><b>${esc(m.t)}</b></summary><p class="muted small">${esc(m.d)}</p></details></li>`).join("");
  const recent = v.recent.map((x) => `<li>${esc(x.name)} <b>${incUsd(x.amt)}</b> <small class="muted">${new Date(x.day + "T12:00").toLocaleDateString([], { month: "short", day: "numeric" })}${x.note ? " · " + esc(x.note) : ""}</small>
      <button class="small-btn" data-inc-del="${x.id}" title="Take it back">✕</button></li>`).join("");
  const today = new Date().toISOString().slice(0, 10);
  return `<div class="card best-income" id="best-income"><h4>💸 Income goal <small class="muted">${v.for ? "for " + esc(v.for) : ""}</small></h4>
    <p class="inc-total"><b>${incUsd(v.total)}</b> <span class="muted">of ${incUsd(v.goal)} in ${esc(v.month)}</span></p>
    <div class="inc-bar big"><i style="width:${Math.min(100, v.pct)}%"></i><span class="inc-mark" style="left:${v.day / v.days * 100}%" title="where you'd be on an even pace"></span></div>
    <p>${esc(v.pep)}</p>
    <p class="muted small">Day ${v.day} of ${v.days} · on pace for ${incUsd(v.pace)}${v.last_month ? ` · last month ${incUsd(v.last_month)}` : ""}</p>
    <div class="inc-months">${bars}</div>
    <h5>🌊 Your streams this month</h5><ul class="inc-streams">${streams}</ul>
    <div class="quiz-row"><select id="inc-s">${opts}</select><input id="inc-amt" type="number" min="0" step="0.01" inputmode="decimal" placeholder="$" style="width:90px">
      <input id="inc-day" type="date" max="${today}" value="${today}" style="width:140px"><input id="inc-note" placeholder="what for (optional)" maxlength="80" style="flex:1;min-width:120px">
      <button class="accent-btn small-btn" data-inc-add>Log it</button></div>
    <p class="muted small">🎙 Or tell Elara: "log 200 dollars from 3D prints" · "how close am I to my income goal?" Sold something through the 🏷 Sell page? It counts by itself - don't log it twice.</p>
    <h5>💡 Today's money moves <small class="muted">(free, with what you've got)</small></h5><ul class="inc-moves">${moves}</ul>
    <h5>🎯 Your money goals</h5>${v.ask ? `<p><b>${esc(v.ask)}</b></p>` : ""}${goals ? `<ul class="inc-goals">${goals}</ul>` : ""}
    <details${v.goals.length ? "" : " open"}><summary class="muted">➕ Add a goal</summary><div class="quiz-row">
      <input id="inc-g-t" placeholder="like: sell 5 Deck OS licenses" maxlength="80" style="flex:1;min-width:160px">
      <input id="inc-g-n" type="number" min="1" placeholder="target" style="width:90px">
      <select id="inc-g-u"><option value="#">things I count (+1)</option><option value="$:all">$ - all income this month</option>${live.map((s) => `<option value="$:${esc(s.id)}">$ - ${esc(s.e)} ${esc(s.name)}</option>`).join("")}</select>
      <button class="small-btn" data-inc-goal-add>Add</button></div></details>
    ${recent ? `<details><summary class="muted">🧾 Recent entries</summary><ul class="inc-recent">${recent}</ul></details>` : ""}
    <details><summary class="muted">⚙️ Goal, streams & daily ping</summary>
      <div class="quiz-row"><label>Monthly goal $<input id="inc-goal" type="number" min="0" value="${v.goal}" style="width:110px"></label>
        <label>for <input id="inc-for" value="${esc(v.for || "")}" maxlength="60" style="width:150px"></label><button class="small-btn" data-inc-save>Save</button></div>
      <p class="muted small">Price per sale (optional) - then I'll show how many sales close the gap:</p>
      ${live.map((s) => `<div class="quiz-row"><span style="min-width:150px">${esc(s.e)} ${esc(s.name)}</span><input type="number" min="0" step="0.01" placeholder="$ each" value="${s.each || ""}" data-inc-each="${s.id}" style="width:90px">
        ${s.id === "other" || s.auto ? "" : `<button class="small-btn" data-inc-hide="${s.id}" title="Hide this stream">Hide</button>`}</div>`).join("")}
      ${v.streams.some((s) => s.hide) ? `<p class="muted small">Hidden: ${v.streams.filter((s) => s.hide).map((s) => `<button class="small-btn" data-inc-unhide="${s.id}">${esc(s.e)} ${esc(s.name)}</button>`).join(" ")}</p>` : ""}
      <div class="quiz-row"><input id="inc-new-e" placeholder="💵" maxlength="8" style="width:50px"><input id="inc-new-n" placeholder="New stream (like: weekend side work)" maxlength="40" style="flex:1;min-width:150px"><button class="small-btn" data-inc-stream>Add stream</button></div>
      <label><input type="checkbox" data-inc-ping${v.ping && v.ping.on ? " checked" : ""}> 📲 Ping me once a day with where I'm at + one money move</label>
      at <select data-inc-hour>${[6, 7, 8, 9, 10, 12, 15, 18, 20].map((h) => `<option value="${h}"${(v.ping && v.ping.hour) === h ? " selected" : ""}>${h > 12 ? h - 12 : h}${h >= 12 ? "pm" : "am"}</option>`).join("")}</select>
    </details></div>`;
}
let incFocus = false;
async function incPost(body, msg) {
  try { best = await post("/api/best/income", body); bestAt = Date.now(); } catch (err) { return toast(err.message); }
  if (msg) toast(msg);
  drawHomeBest(); if (currentPanel === "best") drawBest();
}
if ($("best-body")) {
  $("best-body").addEventListener("click", (e) => {
    const t = e.target, q = (sel) => t.closest(sel), val = (id) => ($(id) || {}).value;
    if (q("[data-inc-add]")) {
      const amt = +val("inc-amt"); if (!(amt > 0)) return toast("How much came in?");
      return incPost({ add: { s: val("inc-s"), amt, day: val("inc-day"), note: val("inc-note") } }, `💸 ${incUsd(amt)} logged`);
    }
    if (q("[data-inc-del]")) return incPost({ remove: q("[data-inc-del]").dataset.incDel }, "Taken back");
    if (q("[data-inc-bump]")) return incPost({ goal_id: q("[data-inc-bump]").dataset.incBump, bump: 1 });
    if (q("[data-inc-goal-del]")) { if (!confirm("Delete this goal?")) return; return incPost({ goal_id: q("[data-inc-goal-del]").dataset.incGoalDel, remove: true }); }
    if (q("[data-inc-goal-add]")) {
      const [unit, s] = String(val("inc-g-u")).split(":");
      return incPost({ goal_add: { t: val("inc-g-t"), target: val("inc-g-n"), unit, s } }, "🎯 Goal added - I'll track it");
    }
    if (q("[data-inc-save]")) return incPost({ goal: val("inc-goal"), for: val("inc-for") }, "Saved");
    if (q("[data-inc-hide]")) return incPost({ stream_id: q("[data-inc-hide]").dataset.incHide, hide: true });
    if (q("[data-inc-unhide]")) return incPost({ stream_id: q("[data-inc-unhide]").dataset.incUnhide, hide: false });
    if (q("[data-inc-stream]")) return incPost({ stream: { name: val("inc-new-n"), e: val("inc-new-e") } }, "Stream added");
  });
  $("best-body").addEventListener("change", (e) => {
    const t = e.target;
    if (t.dataset.incEach) return incPost({ stream_id: t.dataset.incEach, each: t.value });
    if (t.matches("[data-inc-ping]")) return incPost({ ping: { on: t.checked } }, t.checked ? "📲 Daily ping on" : "Daily ping off");
    if (t.matches("[data-inc-hour]")) return incPost({ ping: { hour: +t.value } });
  });
}
