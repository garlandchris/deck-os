// Deck OS service worker: shows Deck OS's own notifications, and tapping one opens
// Deck OS right in the family chat (or switches an open Deck OS to it).
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));

self.addEventListener("push", (event) => {
  let note = {};
  try { note = event.data ? event.data.json() : {}; } catch { note = { body: event.data ? event.data.text() : "" }; }
  event.waitUntil(self.registration.showNotification(note.title || "Deck OS", {
    body: note.body || "",
    icon: note.icon || "/static/apple-touch-icon.png",
    badge: "/static/icon-512.png",
    tag: note.tag,
    data: { url: note.url || "/#chat" },
    // how loud you picked for this kind: quiet = no sound/buzz, loud = buzzes hard and stays until you tap it
    silent: note.level === "quiet",
    renotify: note.level === "loud" && !!note.tag,
    requireInteraction: note.level === "loud",
    vibrate: note.level === "loud" ? [300, 120, 300, 120, 600] : note.level === "quiet" ? [] : [200],
  }));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = new URL(event.notification.data.url || "/#chat", self.location.origin);
  const panel = url.hash.slice(1) || "chat";
  event.waitUntil((async () => {
    const open = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    for (const client of open) {
      if (new URL(client.url).origin !== self.location.origin) continue;
      client.postMessage({ go: panel });
      if ("focus" in client) return client.focus();
    }
    return self.clients.openWindow(url.href);
  })());
});
