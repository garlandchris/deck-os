// 🎨 pages that open inside Deck OS (Sell stuff, 3D prints, ...) wear the theme you picked - and follow along live
// when you change it. Load it with a plain <script src="/static/frame-theme.js"></script> in the <head>.
// It sets the same --bg / --panel / --accent ... colors as the main app, including --on-accent (readable text on an
// accent-colored button), plus a "light-theme" class on <html> for the white/paper themes, and fires "deckos-theme".
(() => {
  const VARS = ["--bg", "--panel", "--panel-2", "--line", "--text", "--muted", "--accent", "--on-accent", "--warn", "--good", "--bad"];
  const root = document.documentElement;
  const lum = (hex) => {
    const m = /^#?([0-9a-f]{6})$/i.exec(hex || ""); if (!m) return 0;
    return [0, 2, 4].map((i) => parseInt(m[1].slice(i, i + 2), 16) / 255)
      .map((c) => c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4)
      .reduce((s, c, i) => s + c * [0.2126, 0.7152, 0.0722][i], 0);
  };
  let last = "";
  if (parent === window) return;  // opened on its own: keep the page's colors
  function sync() {
    let cs;
    try { cs = parent.getComputedStyle(parent.document.documentElement); } catch { return; }
    const vals = VARS.map((v) => cs.getPropertyValue(v).trim()), key = vals.join();
    if (key === last) return;
    last = key;
    VARS.forEach((v, i) => { if (vals[i]) root.style.setProperty(v, vals[i]); });
    const get = (v) => vals[VARS.indexOf(v)];
    const light = lum(get("--bg")) > 0.4;
    root.classList.toggle("light-theme", light);
    root.style.colorScheme = light ? "light" : "dark";
    dispatchEvent(new Event("deckos-theme"));
  }
  sync();
  try { new MutationObserver(sync).observe(parent.document.documentElement, { attributes: true, attributeFilter: ["style"] }); } catch {}
})();
