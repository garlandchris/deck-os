// 🎛 Deck (owner only, home PC): Stream-Deck style buttons on the phone.
//  🖥 PC  - PC modes, clip that, lock, goodnight, music, room lights, Rundown, desk to-do, 📤 send files / links to the PC.
//  📱 Phone - buttons that happen ON the iPhone: call / text / FaceTime, directions, open an app, run an Apple Shortcut,
//             a website, or a Deck OS one-tap. Build your own with ＋ Add button.
// Every tap shows what really happened (the PC's own answer) - never a pretend "done".
let deck = null, deckTab = "pc", deckEditing = false, deckBusy = false;
const deckOk = () => typeof isOwnerHere === "function" && isOwnerHere() && status && !status.door && !status.demo;

const PC_TILE = {
  "mode:creator": { e: "🎬", t: "Creator" }, "mode:edit": { e: "✂️", t: "Edit" }, "mode:studio": { e: "🎵", t: "Studio" }, "mode:learn": { e: "📚", t: "Learn" },
  "mode:chill": { e: "🎮", t: "Chill" }, "mode:trading": { e: "📈", t: "Trading" },
  clip: { e: "✂️", t: "Clip that" }, close: { e: "💾", t: "Save + close" }, lock: { e: "🔒", t: "Lock PC" }, night: { e: "🌙", t: "Goodnight" },
  "music:toggle": { e: "⏯", t: "Play / pause" }, "music:lofi": { e: "☕", t: "Lofi" }, "music:next": { e: "⏭", t: "Next song" },
  "light:room": { e: "💡", t: "Room lights" }, "scene:relax": { e: "🛋", t: "Relax" }, "scene:concentrate": { e: "🎯", t: "Focus light" },
  "scene:nightlight": { e: "🌃", t: "Nightlight" }, rundown: { e: "🎧", t: "Rundown" }, todo: { e: "✅", t: "Desk to-do" },
  send: { e: "📤", t: "Send to PC" }, link: { e: "🔗", t: "Open link" },
};
const MODE_NAMES = { creator: "🎬 Creator", edit: "✂️ Edit", studio: "🎵 Studio", learn: "📚 Learn", chill: "🎮 Chill", trading: "📈 Trading" };
const ROOM_LIGHT = (window.DECKOS_ROOM_LIGHT || "");   // the owner's room light, set in the setup wizard
const DECK_ACTS = { gym: "🏋️ Log gym", sleep_good: "😴 Slept 7h+", todo: "✅ Add a desk to-do", buy: "🛒 Should I buy this?", best: "💪 Best me", money: "💰 Money", rundown: "🎧 Rundown" };
const PHONE_KIND = { call: "📞 Call someone", text: "💬 Text someone", facetime: "📹 FaceTime", maps: "🗺 Directions", app: "📱 Open an app",
  shortcut: "⚡ Run a Shortcut", link: "🌐 Website", deck: "🎛 Deck OS one-tap" };
const APP_PRESETS = [
  ["🎵", "Spotify", "https://open.spotify.com/", "spotify://"], ["▶️", "YouTube", "https://www.youtube.com/", "youtube://"],
  ["📸", "Instagram", "https://www.instagram.com/", "instagram://"], ["🎶", "TikTok", "https://www.tiktok.com/", "snssdk1233://"],
  ["👻", "Snapchat", "https://www.snapchat.com/", "snapchat://"], ["💬", "Discord", "https://discord.com/app", "discord://"],
  ["📈", "Robinhood", "https://robinhood.com/", "robinhood://"], ["🏠", "Home (HA)", "", "homeassistant://"],
];

async function loadDeck(force) {
  if (!force && deck && Date.now() - deck._at < 20000) return deck;
  try { deck = await api("/api/pcdeck"); deck._at = Date.now(); } catch { deck = null; }
  return deck;
}

function pcTiles() {
  const order = deck.pc_order.length ? deck.pc_order.concat(deck.pc_tiles.filter((t) => !deck.pc_order.includes(t))) : deck.pc_tiles;
  return order.filter((t) => PC_TILE[t] && (deckEditing || !deck.pc_hidden.includes(t)) && pcTileAvailable(t));
}
function deckScene(key) {
  const want = key.split(":")[1];
  return (status.scenes || []).find((s) => s.name.toLowerCase().replace(/\s+/g, "") === want);
}
function pcTileAvailable(t) {
  if (t.startsWith("scene:")) return !!deckScene(t);
  if (t === "light:room") return (status.lights || []).some((l) => l.id === ROOM_LIGHT);
  return true;
}
function pcTileState(t) {
  const m = deck.modes || {}, mus = deck.music || {};
  if (t.startsWith("mode:")) return (m[t.slice(5)] || {}).open ? '<em class="deck-on">● open</em>' : "";
  if (t === "clip") return deck.obs && deck.obs.replay_buffer ? '<em class="deck-on">● recording</em>' : '<em>Chill mode first</em>';
  if (t === "music:toggle") return mus.status === "playing" ? `<em class="deck-on">▶ ${esc((mus.title || "playing").slice(0, 18))}</em>` : mus.status ? `<em>${esc(mus.status)}</em>` : "";
  if (t === "light:room") { const l = (status.lights || []).find((x) => x.id === ROOM_LIGHT); return l && l.on ? '<em class="deck-on">on</em>' : "<em>off</em>"; }
  return "";
}
function pcTileHtml(t, small) {
  const d = PC_TILE[t], hidden = deck.pc_hidden.includes(t);
  const edit = deckEditing ? `<span class="deck-edit"><button data-deck-move="-1" data-id="${t}">◀</button><button data-deck-hide="${t}">${hidden ? "🙈" : "👁"}</button><button data-deck-move="1" data-id="${t}">▶</button></span>` : "";
  const tag = deckEditing ? "div" : "button";      // (edit buttons can't sit inside a button)
  return `<${tag} class="deck-tile${hidden ? " deck-hidden" : ""}${small ? " small" : ""}" data-pc="${t}"><b>${d.e}</b><span>${d.t}</span>${small ? "" : pcTileState(t)}${edit}</${tag}>`;
}

// --- 📱 phone buttons: real links the iPhone opens itself ---
function phoneUrl(p) {
  const v = p.value || "";
  if (p.kind === "call") return "tel:" + v;
  if (p.kind === "text") return "sms:" + v + (p.body ? "&body=" + encodeURIComponent(p.body) : "");
  if (p.kind === "facetime") return "facetime:" + v;
  if (p.kind === "maps") return (p.via === "scheme" ? "maps://?daddr=" : "https://maps.apple.com/?daddr=") + encodeURIComponent(v);
  if (p.kind === "app") return p.via === "scheme" && p.scheme ? p.scheme : p.link || p.scheme;
  if (p.kind === "shortcut") return "shortcuts://run-shortcut?name=" + encodeURIComponent(v);
  if (p.kind === "link") return v;
  return "";
}
function phoneTileHtml(p, i) {
  const url = phoneUrl(p);
  const edit = deckEditing ? `<span class="deck-edit"><button data-ph-move="-1" data-i="${i}">◀</button><button data-ph-edit="${i}">✎</button><button data-ph-del="${i}">✕</button><button data-ph-move="1" data-i="${i}">▶</button></span>` : "";
  const sub = p.kind === "app" ? `<em>${p.via === "scheme" ? "app scheme" : "app link"}</em>` : p.kind === "shortcut" ? "<em>Shortcut</em>" : "";
  return url && !deckEditing
    ? `<a class="deck-tile" href="${esc(url)}"${p.kind === "link" ? ' target="_blank" rel="noopener"' : ""}><b>${esc(p.emoji)}</b><span>${esc(p.label)}</span>${sub}</a>`
    : `<${deckEditing ? "div" : "button"} class="deck-tile" data-ph="${i}"><b>${esc(p.emoji)}</b><span>${esc(p.label)}</span>${sub}${edit}</${deckEditing ? "div" : "button"}>`;
}

// --- Home card: the first 6 PC buttons ---
async function drawHomeDeck() {
  const box = $("pcdeck-card"); if (!box) return;
  if (!status || !deckOk()) { box.hidden = true; return; }
  const d = await loadDeck(); box.hidden = !d || !d.pc_up; if (box.hidden) return;
  box.innerHTML = `<h2>🎛 Deck <small class="muted">tap to run it on your PC</small></h2>
    <div class="deck-grid home">${pcTiles().slice(0, 6).map((t) => pcTileHtml(t, true)).join("")}</div>
    <div class="quiz-row"><button class="accent-btn small-btn" data-go="pcdeck">Open the Deck</button></div>`;
}
if ($("pcdeck-card")) $("pcdeck-card").addEventListener("click", (e) => {
  const t = e.target.closest("[data-pc]"); if (t) return pcPress(t.dataset.pc, t);
  const g = e.target.closest("[data-go]"); if (g) go(g.dataset.go);
});

// --- the page ---
async function loadDeckPage() {
  $("pcdeck-body").innerHTML = '<p class="muted">Loading…</p>';
  await loadDeck(true); drawDeck();
}
function drawDeck() {
  const box = $("pcdeck-body"), d = deck;
  if (!d) { box.innerHTML = '<p class="muted">Couldn\'t load the Deck right now.</p>'; return; }
  if (d.lockdown && d.lockdown.on && !d.lockdown.ok) { screensStop(); box.innerHTML = lockdownHtml(d.lockdown); return; }
  const tabs = `<div class="deck-tabs"><button class="${deckTab === "pc" ? "on" : ""}" data-deck-tab="pc">🖥 PC</button><button class="${deckTab === "phone" ? "on" : ""}" data-deck-tab="phone">📱 Phone</button>
    <button class="${deckTab === "screens" ? "on" : ""}" data-deck-tab="screens">📺 Screens</button>
    ${deckTab === "screens" ? "" : `<button class="small-btn deck-editbtn" data-deck-editing>${deckEditing ? "✓ Done" : "✏️ Edit"}</button>`}</div>`;
  let body;
  if (deckTab === "pc") {
    body = (d.pc_up ? "" : '<p class="card muted">⚠ The PC isn\'t answering right now, so these buttons may not work.</p>')
      + `<div class="deck-grid">${pcTiles().map((t) => pcTileHtml(t)).join("")}</div>
      ${deckEditing ? '<p class="muted small">◀ ▶ move a button, 👁 hides it (🙈 = hidden). Tap ✓ Done to save.</p>' : ""}
      <p class="muted small deck-last" id="deck-last"></p>${sendCard()}`;
  } else if (deckTab === "screens") {
    body = screensHtml();
  } else {
    body = `<div class="deck-grid">${d.phone.map(phoneTileHtml).join("")}${deckEditing ? '<button class="deck-tile deck-add" data-ph-add><b>＋</b><span>Add button</span></button>' : ""}</div>
      ${deckEditing ? "" : '<p class="muted small">✏️ Edit → ＋ Add button to make your own: call or text someone, directions, open an app, run an Apple Shortcut, a website.</p>'}
      <details class="card deck-help"><summary>⚡ Make your phone do anything (Shortcuts)</summary>${shortcutHelp()}</details>
      <p class="muted small">Good to know: iPhone sometimes asks "Open in …?" for app buttons - app buttons use the app's normal web link first,
      which usually opens the app with no question (✎ edit a button to switch to the app scheme if one acts up). Running a Shortcut
      jumps to the Shortcuts app for a second, then you're done. The camera can't be opened by a link - make a Shortcut for it.</p>`;
  }
  box.innerHTML = tabs + body;
  if (deckTab === "screens") screensStart(); else screensStop();
}

// --- 🔒 Lockdown: away from home, remote control needs the one-time code pushed to the owner's Deck OS app ---
function lockdownHtml(l) {
  return `<div class="card deck-lockdown"><h3>🔒 Lockdown</h3>
    <p class="small">You're away from home, so remote control of the PC needs the 6-digit code sent to your Deck OS app
      (check your notifications). A new code comes each time you leave; it stops mattering once you're home.</p>
    ${l.has_code ? `<form class="row" data-ld-form><input id="ld-code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="6-digit code">
      <button class="btn primary">Unlock</button></form><p class="muted small">${l.tries_left} tries left.</p>` : '<p class="small">That code is used up.</p>'}
    <div class="row"><button class="small-btn" data-ld-resend>📨 Send a new code</button>
      <button class="small-btn" data-pc="lock">🔒 Lock PC</button></div>
    <p class="muted small">Someone types a wrong password on the PC, or unlocks it, while you're away? You get a ping. Your PC password never changes.</p></div>`;
}
document.addEventListener("submit", async (e) => {
  if (!e.target.closest("[data-ld-form]")) return;
  e.preventDefault();
  try { await post("/api/lockdown/code", { code: $("ld-code").value }); toast("🔓 Remote control unlocked"); }
  catch (err) { toast(err.message); }
  await loadDeck(true); drawDeck();
});
document.addEventListener("click", async (e) => {
  if (!e.target.closest("[data-ld-resend]")) return;
  try { toast((await post("/api/lockdown/resend")).say); } catch (err) { toast(err.message); }
  await loadDeck(true); drawDeck();
});

// --- 📺 Screens: a live look at the PC's monitors (view only) ---
let scrMon = "all", scrList = null, scrOn = false, scrUrl = "", lockIn = false;
function screensHtml() {
  const mons = scrList || [];
  const pick = [["all", `Both${mons.length > 2 ? " / all" : ""}`], ...mons.map((m, i) => [String(i), `${i ? "▶" : "◀"} Screen ${i + 1}`])];
  return `<div class="deck-dests scr-pick">${pick.map(([v, l]) => `<button class="${scrMon === v ? "on" : ""}" data-scr-mon="${v}"><b>${l}</b></button>`).join("")}</div>
    <button class="btn ${lockIn ? "primary" : ""} lockin-btn" data-lockin>${lockIn ? "🎮 Lock in is ON - tap to stop" : "🎮 Lock in (control the PC)"}</button>
    <div class="card scr-box ${lockIn ? "lockin" : ""}"><img id="scr-img" alt="Your PC screen"><p class="muted small" id="scr-note">Connecting to your PC…</p></div>
    ${lockIn ? `<div class="lockin-bar">
        <button class="btn" data-li-scroll="-3">▲ Scroll</button><button class="btn" data-li-scroll="3">▼ Scroll</button>
        <button class="btn" data-li-key="esc">Esc</button><button class="btn" data-li-key="enter">Enter</button>
        <button class="btn" data-li-key="backspace">⌫</button><button class="btn" data-li-key="tab">Tab</button>
        <button class="btn" data-li-key="ctrl+c">Copy</button><button class="btn" data-li-key="ctrl+v">Paste</button>
        <button class="btn" data-li-key="ctrl+z">Undo</button><button class="btn" data-li-key="alt+tab">Switch app</button>
      </div>
      <form class="lockin-type" data-li-type><input id="li-text" placeholder="Type on the PC…" autocomplete="off" autocapitalize="off"><button class="btn primary">Send</button></form>
      <p class="muted small">Tap = click · hold = right-click · double-tap = double-click. Only you can use this, and only on your home PC.</p>`
    : `<p class="muted small">Live, about once a second - nothing on the PC changes. Tap the picture to see it full size.
      Turn your phone sideways for both screens. It stops when you leave this tab.</p>`}`;
}
async function screensStart() {
  if (!scrList) { try { scrList = (await api("/api/pcdeck/screens")).screens || []; if (deckTab === "screens") return drawDeck(); } catch (e) { scrList = []; } }
  if (scrOn) return;
  scrOn = true; screensNext();
}
function screensStop() { scrOn = false; }
function screensNext() {
  const img = $("scr-img");
  if (!scrOn || !img || currentPanel !== "pcdeck" || deckTab !== "screens") { scrOn = false; return; }
  if (document.hidden) { setTimeout(screensNext, 1000); return; }
  const w = Math.min(3840, Math.max(scrMon === "all" ? 2400 : 1280, Math.round(img.parentElement.clientWidth * (window.devicePixelRatio || 1))));  // sharp enough to pinch-zoom
  const t0 = Date.now(), pic = new Image();
  pic.onload = () => {
    if (scrUrl) URL.revokeObjectURL(scrUrl);
    const el = $("scr-img"); if (!el) return;
    el.src = pic.src; scrUrl = pic.src;
    const n = $("scr-note"); if (n) n.textContent = `🟢 Live · ${new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit", second: "2-digit" })}`;
    setTimeout(screensNext, Math.max(lockIn ? 120 : 300, (lockIn ? 350 : 1000) - (Date.now() - t0)));
  };
  pic.onerror = () => { const n = $("scr-note"); if (n) n.textContent = "⚠ Can't see the PC screen right now - trying again…"; setTimeout(screensNext, 4000); };
  fetch(`/api/pcdeck/screen?mon=${scrMon}&w=${w}`, { cache: "no-store", headers: deviceId ? { "X-Deck-Device": deviceId } : {} })
    .then((r) => (r.status === 423 ? (scrOn = false, loadDeck(true).then(drawDeck), Promise.reject("ld")) : r.ok ? r.blob() : Promise.reject()))
    .then((b) => { pic.src = URL.createObjectURL(b); }).catch((x) => { if (x !== "ld") pic.onerror(); });
}
function shortcutHelp() {
  return `<ol class="small">
    <li>Open the <b>Shortcuts</b> app on your iPhone → tap <b>＋</b>.</li>
    <li>Tap <b>Add Action</b> and search what you want: <i>Set Focus</i> (Do Not Disturb), <i>Start Timer</i>, <i>Create Alarm</i>, <i>Take Photo</i>, <i>Set Volume</i>…</li>
    <li>Tap the name at the top and call it something short, like <b>Gym Focus</b>. Tap Done.</li>
    <li>Back here: <b>✏️ Edit → ＋ Add button → ⚡ Run a Shortcut</b> and type the exact same name.</li></ol>
    <p class="muted small">The first time, iPhone may ask to allow it - tap Allow.</p>`;
}
function sendCard() {
  const dests = Object.entries(deck.dests || {});
  return `<div class="card deck-send" id="deck-send"><h3>📤 Send to PC</h3>
    <p class="muted small">Pick where it goes, then choose videos or photos from your phone.</p>
    <div class="deck-dests">${dests.map(([k, v]) => `<button class="${k === (deck._dest || "footage") ? "on" : ""}" data-dest="${k}" ${v.ready ? "" : "disabled"}><b>${esc(v.label)}</b><small>${esc(v.note)}</small></button>`).join("")}</div>
    <label class="accent-btn deck-pick">📎 Choose files<input type="file" id="deck-files" multiple accept="video/*,image/*,audio/*" hidden></label>
    <div class="deck-progress" id="deck-progress" hidden><div></div><span></span></div>
    <p class="small" id="deck-sent"></p>
    <h3>🔗 Open a link on the PC</h3>
    <div class="row"><input id="deck-url" placeholder="Paste a link" inputmode="url"><button class="small-btn" data-deck-openlink>Open</button></div></div>`;
}

function deckSay(r, fallback) {
  const msg = (r && (r.say || (r.opening ? `Setting up: ${r.opening}` : ""))) || fallback || (r && r.ok === false ? "That didn't work." : "Done.");
  toast(msg);
  const last = $("deck-last"); if (last) last.textContent = (r && r.ok === false ? "✗ " : "✓ ") + msg;
}
function deckSheet(title, buttons, extra = "") {
  return new Promise((resolve) => {
    const box = document.createElement("div");
    box.className = "modal";
    box.innerHTML = `<div class="modal-box deck-sheet"><h3>${title}</h3>${extra}
      ${buttons.map(([v, label, cls]) => `<button class="${cls || ""}" data-v="${esc(v)}">${label}</button>`).join("")}
      <button class="link-btn" data-v="">Cancel</button></div>`;
    document.body.appendChild(box);
    box.addEventListener("click", (e) => {
      const b = e.target.closest("[data-v]");
      if (e.target === box || b) { const input = box.querySelector("input,textarea"); box.remove(); resolve(b ? (b.dataset.v && input ? { v: b.dataset.v, text: input.value } : b.dataset.v) : ""); }
    });
    const input = box.querySelector("input"); if (input) setTimeout(() => input.focus(), 50);
  });
}
async function deckDo(body, fallback) {
  try { const r = await post("/api/pcdeck/do", body); if (!r.needs_choice && !r.pick) deckSay(r, fallback); return r; }
  catch (err) { deckSay({ ok: false, say: err.message }); return null; }
}

async function pcPress(t, el) {
  if (deckEditing || deckBusy) return;
  deckBusy = true; if (el) el.classList.add("busy");
  try {
    if (t.startsWith("mode:")) {
      const mode = t.slice(5), open = ((deck.modes || {})[mode] || {}).open;
      if (open) {
        const a = await deckSheet(`${MODE_NAMES[mode]} mode is open`, [["go", "↪ Go there"], ["close", "💾 Save + close", "accent"]]);
        if (a) await deckDo({ act: "mode", mode, action: a === "close" ? "close" : "open" }, a === "go" ? "Switched to it on the PC" : "");
      } else {
        let r = await deckDo({ act: "mode", mode });
        if (r && r.needs_choice) {
          const c = await deckSheet(`${MODE_NAMES[mode]} mode`, [["continue", `↪ Continue <small>${esc(r.last_work)}</small>`], ["new", `✨ Start new <small>${esc((r.new_would_be || "").replace("[Long] ", ""))}</small>`, "accent"]]);
          if (c) await deckDo({ act: "mode", mode, choice: c });
        }
      }
    } else if (t === "close") {
      const r = await deckDo({ act: "close" });
      if (r && r.pick) { const m = await deckSheet("Which one?", r.pick.map((x) => [x, `💾 ${MODE_NAMES[x]}`])); if (m) await deckDo({ act: "mode", mode: m, action: "close" }); }
    } else if (t === "clip") await deckDo({ act: "clip" }, "");
    else if (t === "lock") await deckDo({ act: "lock" });
    else if (t === "night") { if (await deckSheet("🌙 Goodnight? This locks the PC and turns the screens off.", [["y", "🌙 Goodnight", "accent"]])) await deckDo({ act: "night" }); }
    else if (t === "music:toggle") await deckDo({ act: "music", value: (deck.music || {}).status === "playing" ? "pause" : "resume" });
    else if (t.startsWith("music:")) await deckDo({ act: "music", value: t.slice(6) === "next" ? "next" : "lofi" });
    else if (t === "light:room") { await post(`/api/lights/${ROOM_LIGHT}/toggle`); deckSay({ ok: true, say: "💡 Room lights switched" }); if (typeof refreshSoon === "function") refreshSoon(); }
    else if (t.startsWith("scene:")) { const s = deckScene(t); await post(`/api/scenes/${s.id}`); deckSay({ ok: true, say: `💡 ${s.name}` }); }
    else if (t === "rundown") openRundown();
    else if (t === "todo") await deckTodo();
    else if (t === "send") { if (currentPanel !== "pcdeck") { deckTab = "pc"; go("pcdeck"); setTimeout(() => $("deck-send") && $("deck-send").scrollIntoView({ behavior: "smooth" }), 600); } else $("deck-send").scrollIntoView({ behavior: "smooth" }); }
    else if (t === "link") { const a = await deckSheet("🔗 Open a link on the PC", [["open", "Open on PC", "accent"]], '<input id="deck-link-in" placeholder="https://…" inputmode="url">'); if (a && a.text) await deckDo({ act: "link", value: a.text.trim() }, "Opened on the PC"); }
  } catch (err) { deckSay({ ok: false, say: err.message }); }
  finally {
    deckBusy = false; if (el) el.classList.remove("busy");
    setTimeout(async () => { await loadDeck(true); if (currentPanel === "pcdeck") drawDeck(); drawHomeDeck(); }, 1500);
  }
}
async function deckTodo() {
  const a = await deckSheet("✅ Add to your desk to-dos", [["add", "Add", "accent"]], '<input id="deck-todo-in" placeholder="What needs doing?" maxlength="120">');
  if (a && a.text && a.text.trim()) await deckDo({ act: "todo", value: a.text.trim() });
}
async function deckAct(v) {          // 📱 Deck OS one-taps
  if (v === "gym" || v === "sleep_good") {
    try { await post("/api/best/log", { what: v }); toast(v === "gym" ? "🏋️ Gym logged" : "😴 Logged"); } catch (err) { toast(err.message); }
  } else if (v === "todo") await deckTodo();
  else if (v === "buy" || v === "money") go("money");
  else if (v === "best") go("best");
  else if (v === "rundown") openRundown();
}

// --- 📤 send files to the PC (with progress) ---
function deckUpload(files) {
  const dest = deck._dest || "footage", form = new FormData();
  [...files].forEach((f) => form.append("files", f));
  form.append("dest", dest);
  const bar = $("deck-progress"), out = $("deck-sent");
  bar.hidden = false; out.textContent = "";
  const xhr = new XMLHttpRequest();
  xhr.open("POST", "/api/pcdeck/send");
  if (typeof deviceId !== "undefined" && deviceId) xhr.setRequestHeader("X-Deck-Device", deviceId);
  xhr.upload.onprogress = (e) => {
    if (!e.lengthComputable) return;
    const pct = Math.round(e.loaded / e.total * 100);
    bar.firstElementChild.style.width = pct + "%";
    bar.lastElementChild.textContent = pct < 100 ? `${pct}% · ${(e.loaded / 1e6).toFixed(0)} of ${(e.total / 1e6).toFixed(0)} MB` : "Saving on the PC…";
  };
  xhr.onload = () => {
    bar.hidden = true;
    let r = {}; try { r = JSON.parse(xhr.responseText); } catch {}
    if (xhr.status >= 400) { out.textContent = "✗ " + (r.detail || "Upload failed"); return; }
    out.innerHTML = (r.ok ? "✓ " : "✗ ") + esc(r.say) + (r.saved && r.saved.length ? `<br><span class="muted">${r.saved.map((s) => esc(s.name)).join(", ")} → ${esc(r.folder)}</span>` : "")
      + (r.skipped && r.skipped.length ? `<br><span class="muted">Skipped: ${esc(r.skipped.join(", "))}</span>` : "");
    toast(r.say || "Done");
  };
  xhr.onerror = () => { bar.hidden = true; out.textContent = "✗ Lost the connection - try again on home Wi-Fi."; };
  xhr.send(form);
}

// --- ✏️ editing ---
async function deckSaveLayout(body) {
  try { deck = await post("/api/pcdeck/layout", body); deck._at = Date.now(); } catch (err) { toast(err.message); }
  drawDeck(); drawHomeDeck();
}
function pcOrderNow() { return deck.pc_order.length ? deck.pc_order.concat(deck.pc_tiles.filter((t) => !deck.pc_order.includes(t))) : [...deck.pc_tiles]; }
async function phoneForm(p) {
  p = p || { kind: "app", via: "link", emoji: "", label: "" };
  const box = document.createElement("div");
  box.className = "modal";
  const people = (deck.people || []).map((x) => `<option value="${esc(x.phone)}">${esc(x.name)}</option>`).join("");
  box.innerHTML = `<div class="modal-box deck-sheet deck-form"><h3>${p.id ? "✎ Edit button" : "＋ New button"}</h3>
    <label>What it does <select id="ph-kind">${Object.entries(PHONE_KIND).map(([k, v]) => `<option value="${k}" ${k === p.kind ? "selected" : ""}>${v}</option>`).join("")}</select></label>
    <div id="ph-fields"></div>
    <div class="row"><label>Emoji <input id="ph-emoji" maxlength="8" value="${esc(p.emoji)}" style="width:4em"></label><label>Name <input id="ph-label" maxlength="24" value="${esc(p.label)}"></label></div>
    <div class="row"><button class="link-btn" data-x>Cancel</button><button class="accent" data-save>Save</button></div></div>`;
  document.body.appendChild(box);
  const F = box.querySelector("#ph-fields");
  const fields = () => {
    const k = box.querySelector("#ph-kind").value;
    if (["call", "text", "facetime"].includes(k)) F.innerHTML = `${people ? `<label>Person <select id="ph-person"><option value="">- type a number -</option>${people}</select></label>` : '<p class="muted small">Nobody in the family has shared a phone number on their Deck OS card yet - type it.</p>'}
      <label>Number <input id="ph-value" inputmode="tel" value="${esc(p.value || "")}"></label>${k === "text" ? `<label>Message (optional) <input id="ph-body" value="${esc(p.body || "")}" placeholder="On my way!"></label>` : ""}`;
    else if (k === "maps") F.innerHTML = `<label>Address or place <input id="ph-value" value="${esc(p.value || "")}" placeholder="Rink name, work address…"></label>${viaPick(p, "Apple Maps link", "maps:// scheme")}`;
    else if (k === "app") F.innerHTML = `<div class="deck-presets">${APP_PRESETS.map(([e, n, l, s], i) => `<button data-preset="${i}">${e} ${n}</button>`).join("")}</div>
      <label>App web link (opens the app, no question) <input id="ph-link" value="${esc(p.link || "")}" placeholder="https://open.spotify.com/"></label>
      <label>App scheme (backup) <input id="ph-scheme" value="${esc(p.scheme || "")}" placeholder="spotify://"></label>${viaPick(p, "app link (no prompt)", "app scheme")}`;
    else if (k === "shortcut") F.innerHTML = `<label>Shortcut name (exactly as in the Shortcuts app) <input id="ph-value" value="${esc(p.value || "")}" placeholder="Gym Focus"></label><details><summary class="small">How do I make one?</summary>${shortcutHelp()}</details>`;
    else if (k === "link") F.innerHTML = `<label>Website <input id="ph-value" inputmode="url" value="${esc(p.value || "")}" placeholder="https://…"></label>`;
    else F.innerHTML = `<label>Deck OS one-tap <select id="ph-value">${Object.entries(DECK_ACTS).map(([v, n]) => `<option value="${v}" ${v === p.value ? "selected" : ""}>${n}</option>`).join("")}</select></label>`;
  };
  const viaPick = (q, a, b) => `<label>Open with <select id="ph-via"><option value="link" ${q.via !== "scheme" ? "selected" : ""}>${a}</option><option value="scheme" ${q.via === "scheme" ? "selected" : ""}>${b}</option></select></label>`;
  fields();
  box.querySelector("#ph-kind").addEventListener("change", fields);
  return new Promise((resolve) => {
    box.addEventListener("change", (e) => { if (e.target.id === "ph-person" && e.target.value) box.querySelector("#ph-value").value = e.target.value; });
    box.addEventListener("click", (e) => {
      const pre = e.target.closest("[data-preset]");
      if (pre) { const [em, n, l, s] = APP_PRESETS[+pre.dataset.preset]; box.querySelector("#ph-link").value = l; box.querySelector("#ph-scheme").value = s;
        if (!box.querySelector("#ph-emoji").value) box.querySelector("#ph-emoji").value = em; if (!box.querySelector("#ph-label").value) box.querySelector("#ph-label").value = n; return; }
      if (e.target === box || e.target.closest("[data-x]")) { box.remove(); return resolve(null); }
      if (e.target.closest("[data-save]")) {
        const v = (id) => (box.querySelector("#" + id) || {}).value || "";
        const k = v("ph-kind"), out = { id: p.id, kind: k, value: v("ph-value"), body: v("ph-body"), link: v("ph-link"), scheme: v("ph-scheme"),
          via: v("ph-via") || "link", emoji: v("ph-emoji") || (PHONE_KIND[k] || "⭐").split(" ")[0], label: v("ph-label") || (PHONE_KIND[k] || "").split(" ").slice(1).join(" ") };
        box.remove(); resolve(out);
      }
    });
  });
}

document.addEventListener("click", async (e) => {
  if (!e.target.closest("#panel-pcdeck")) return;
  const tab = e.target.closest("[data-deck-tab]"); if (tab) { deckTab = tab.dataset.deckTab; return drawDeck(); }
  const sm = e.target.closest("[data-scr-mon]"); if (sm) { scrMon = sm.dataset.scrMon; document.querySelectorAll("[data-scr-mon]").forEach((b) => b.classList.toggle("on", b === sm)); return; }
  if (e.target.closest("[data-lockin]")) { lockIn = !lockIn; return drawDeck(); }
  const sc = e.target.closest("[data-li-scroll]"); if (sc) return liSend({ act: "scroll", dy: +sc.dataset.liScroll });
  const lk = e.target.closest("[data-li-key]"); if (lk) return liSend({ act: "key", keys: lk.dataset.liKey });
  if (e.target.id === "scr-img" && e.target.src && lockIn) return;      // Lock in: handled by liTap (pointer events)
  if (e.target.id === "scr-img" && e.target.src) { e.target.closest(".scr-box").classList.toggle("scr-full"); return; }
  if (e.target.closest("[data-deck-editing]")) {
    if (deckEditing && deckTab === "pc") await deckSaveLayout({ pc_order: pcOrderNow(), pc_hidden: deck.pc_hidden });
    deckEditing = !deckEditing; return drawDeck();
  }
  const mv = e.target.closest("[data-deck-move]");
  if (mv) { const o = pcOrderNow(), i = o.indexOf(mv.dataset.id), j = i + +mv.dataset.deckMove;
    if (j >= 0 && j < o.length) { [o[i], o[j]] = [o[j], o[i]]; deck.pc_order = o; drawDeck(); } return; }
  const hd = e.target.closest("[data-deck-hide]");
  if (hd) { const id = hd.dataset.deckHide; deck.pc_hidden = deck.pc_hidden.includes(id) ? deck.pc_hidden.filter((x) => x !== id) : [...deck.pc_hidden, id]; drawDeck(); return; }
  const pm = e.target.closest("[data-ph-move]");
  if (pm) { const ph = [...deck.phone], i = +pm.dataset.i, j = i + +pm.dataset.phMove;
    if (j >= 0 && j < ph.length) { [ph[i], ph[j]] = [ph[j], ph[i]]; await deckSaveLayout({ phone: ph }); } return; }
  const pd = e.target.closest("[data-ph-del]");
  if (pd) { const ph = deck.phone.filter((_, i) => i !== +pd.dataset.phDel); await deckSaveLayout({ phone: ph }); return; }
  const pe = e.target.closest("[data-ph-edit]");
  if (pe) { const i = +pe.dataset.phEdit, n = await phoneForm(deck.phone[i]); if (n) { const ph = [...deck.phone]; ph[i] = n; await deckSaveLayout({ phone: ph }); } return; }
  if (e.target.closest("[data-ph-add]")) { const n = await phoneForm(); if (n) await deckSaveLayout({ phone: [...deck.phone, n] }); return; }
  const ph = e.target.closest("[data-ph]");
  if (ph && !deckEditing) { const p = deck.phone[+ph.dataset.ph]; if (p && p.kind === "deck") deckAct(p.value); return; }
  const pc = e.target.closest("[data-pc]"); if (pc) return pcPress(pc.dataset.pc, pc);
  const ds = e.target.closest("[data-dest]"); if (ds) { deck._dest = ds.dataset.dest; drawDeck(); return; }
  if (e.target.closest("[data-deck-openlink]")) { const u = $("deck-url").value.trim(); if (u) await deckDo({ act: "link", value: u }, "Opened on the PC"); }
});
document.addEventListener("change", (e) => { if (e.target.id === "deck-files" && e.target.files.length) deckUpload(e.target.files); });

// --- 🎮 Lock in: tap = click, hold = right-click, double-tap = double-click; typing + keys from the bar ---
async function liSend(body) {
  try { await post("/api/pcdeck/input", { mon: scrMon, ...body }); if (navigator.vibrate) navigator.vibrate(10); }
  catch (err) { toast(err.message); if (err.message.startsWith("🔒 Lockdown")) { await loadDeck(true); drawDeck(); } }
}
let liDown = null, liLast = 0, liTimer = null;
function liPos(e) { const r = e.target.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height }; }
document.addEventListener("pointerdown", (e) => {
  if (!lockIn || e.target.id !== "scr-img") return;
  liDown = { ...liPos(e), at: Date.now(), cx: e.clientX, cy: e.clientY, held: false };
  clearTimeout(liTimer);
  liTimer = setTimeout(() => { if (liDown) { liDown.held = true; liSend({ act: "right", x: liDown.x, y: liDown.y }); } }, 550);
});
document.addEventListener("pointermove", (e) => {
  if (liDown && Math.hypot(e.clientX - liDown.cx, e.clientY - liDown.cy) > 12) { clearTimeout(liTimer); liDown = null; }   // a pan/zoom, not a tap
});
document.addEventListener("pointerup", (e) => {
  clearTimeout(liTimer);
  if (!lockIn || !liDown || e.target.id !== "scr-img") { liDown = null; return; }
  const d = liDown; liDown = null;
  if (d.held) return;
  const now = Date.now();
  if (now - liLast < 350) { liLast = 0; liSend({ act: "double", x: d.x, y: d.y }); }
  else { liLast = now; liSend({ act: "click", x: d.x, y: d.y }); }
});
document.addEventListener("contextmenu", (e) => { if (lockIn && e.target.id === "scr-img") e.preventDefault(); });
document.addEventListener("submit", (e) => {
  if (!e.target.closest("[data-li-type]")) return;
  e.preventDefault();
  const i = $("li-text"); if (!i || !i.value) return;
  liSend({ act: "type", text: i.value }); i.value = "";
});
