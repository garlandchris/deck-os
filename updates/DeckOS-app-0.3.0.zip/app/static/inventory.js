// 🏠 Inventory: what the house has, +/- as it's used, flag "need more", put it on a list - and 📢 SHOUT for it.
let inv = null, invPlace = "All", invKind = "all";
const isThing = (i) => i.kind === "thing";
async function loadInventory() {
  try { inv = await api("/api/inventory"); } catch (err) { return toast(err.message); }
  drawInventory();
}
async function invPost(body, msg) {
  try { inv = await post("/api/inventory", body); drawInventory(); if (msg) toast(msg); return true; } catch (err) { toast(err.message); return false; }
}
function invRow(i) {
  const flagged = i.need || i.low;
  return `<div class="inv-item ${flagged ? "flag" : ""}" data-inv="${i.id}">
    <span class="inv-emoji">${esc(i.emoji)}</span>
    <span class="inv-name"><b>${esc(i.name)}</b><small class="muted">${esc(i.place)}${i.need ? (isThing(i) ? " · ⚠️ need a new one" : " · ⚠️ need more") : i.low ? " · ⚠️ running low" : ""}${i.notes ? " · " + esc(i.notes) : ""}</small></span>
    ${i.pct != null ? `<span class="inv-power ${i.pct <= 15 ? "low" : i.pct <= 40 ? "mid" : ""}" title="${i.pct}% ${isThing(i) ? "condition" : "left"}"><i style="width:${i.pct}%"></i><em>${i.pct}%</em></span>` : `<span></span>`}
    ${isThing(i) ? `<span class="inv-owned">📦</span>` : `<span class="inv-qty"><button data-inv-change="-1" aria-label="one less">−</button><b>${i.qty}${i.unit ? " " + esc(i.unit) : ""}</b><button data-inv-change="1" aria-label="one more">＋</button></span>`}
    <button class="inv-more" data-inv-menu aria-label="More">⋯</button>
    <div class="inv-menu" hidden>
      ${flagged ? `<button data-inv-bought>${isThing(i) ? "✓ Replaced / fixed it" : "🛍 Bought it"}</button>` : `<button data-inv-need>⚠️ ${isThing(i) ? "Need a new one" : "Need more"}</button>`}
      ${inv.lists.map((l) => `<button data-inv-tolist="${esc(l.id)}">${esc(l.emoji)} Add to ${esc(l.name)}</button>`).join("")}
      <button data-inv-newlist>＋ New list…</button>
      <button data-inv-shout>📢 SHOUT for it</button>
      ${isThing(i) ? "" : `<label>Low at <input type="number" min="0" max="999" data-inv-low value="${i.low_at ?? ""}"></label>`}
      <div class="inv-pct"><span>🔋 ${isThing(i) ? "Condition" : "How much is left"}</span>
        <input type="range" min="0" max="100" step="5" data-inv-pct value="${i.pct ?? 100}"><b data-inv-pct-label>${i.pct != null ? i.pct + "%" : "–"}</b>
        ${i.pct != null ? `<button data-inv-pct-off title="Take the bar off">✕</button>` : ""}</div>
      <label class="inv-notes">Why <input data-inv-why maxlength="200" value="${esc(i.why || "")}" placeholder="${isThing(i) ? "cracked screen, battery dies fast…" : "half a tube, last bag…"}"></label>
      ${i.pct != null ? `<button data-inv-check>🤖 Does ${i.pct}% sound right?</button><div class="inv-check" hidden></div>` : ""}
      <label class="inv-notes">Notes <input data-inv-notes maxlength="200" value="${esc(i.notes || "")}" placeholder="${isThing(i) ? "model, serial, where it's from…" : "brand, size…"}"></label>
      <button data-inv-kind="${isThing(i) ? "supply" : "thing"}">${isThing(i) ? "🧻 Count it (supply)" : "📦 It's a thing we own"}</button>
      <label>Where <select data-inv-place>${inv.places.map((p) => `<option ${p === i.place ? "selected" : ""}>${p}</option>`).join("")}</select></label>
      <button class="danger" data-inv-remove>🗑 Remove</button>
    </div></div>`;
}
function drawInventory() {
  const q = $("inv-search").value.trim().toLowerCase();
  const places = ["All", ...inv.places.filter((p) => inv.items.some((i) => i.place === p))];
  if (!places.includes(invPlace)) invPlace = "All";
  $("inv-places").innerHTML = places.length > 2 ? places.map((p) => `<button data-inv-place-tab="${p}" class="${p === invPlace ? "on" : ""}">${p}</button>`).join("") : "";
  const kinds = [["all", "Everything"], ["supply", "🧻 Supplies"], ["thing", "📦 Things we own"]];
  $("inv-kinds").innerHTML = kinds.map(([k, n]) => `<button data-inv-kind-tab="${k}" class="${k === invKind ? "on" : ""}">${n} <small>${k === "all" ? inv.items.length : inv.items.filter((i) => (i.kind || "supply") === k).length}</small></button>`).join("");
  const shown = inv.items.filter((i) => (invKind === "all" || (i.kind || "supply") === invKind) && (invPlace === "All" || i.place === invPlace) && (!q || `${i.name} ${i.notes || ""}`.toLowerCase().includes(q)));
  const need = inv.items.filter((i) => i.need || i.low);
  $("inv-need").innerHTML = need.length && !q && invPlace === "All" ? `<div class="card inv-needcard"><b>⚠️ Need more (${need.length})</b>
    <span>${need.map((i) => `${esc(i.emoji)} ${esc(i.name)}`).join(" · ")}</span>
    <div class="row-mini"><button class="small-btn" data-inv-allist>🛒 All to my list</button><button class="small-btn" data-inv-shout-need>📢 SHOUT the list</button></div></div>` : "";
  $("inv-list").innerHTML = shown.length ? shown.map(invRow).join("")
    : inv.items.length ? `<p class="muted small">${q ? `Nothing called “${esc(q)}” - tap ＋ Add to add it.` : "Nothing here."}</p>`
    : `<p class="muted small">Nothing yet. Tap the quick start below to add what you have - it takes a minute.</p>`;
  $("inv-start").open = !inv.items.length;
  const fromLists = [...new Set(inv.lists.flatMap((l) => l.items))].filter((t) => !inv.items.some((i) => i.name.toLowerCase() === t.toLowerCase()));
  const thingStarters = Object.entries(inv.things).filter(([, v]) => v.length).map(([place, items]) => `<h4>📦 ${place}</h4><div class="inv-chips">${items.map((x) =>
      `<button data-inv-starter="${esc(x.name)}" data-emoji="${esc(x.emoji)}" data-place="${place}" data-kind="thing">${esc(x.emoji)} ${esc(x.name)}</button>`).join("")}</div>`).join("");
  $("inv-starters").innerHTML = (invKind === "thing" ? `<h3 class="inv-start-h">📦 Things you own</h3>${thingStarters}` : "") + (fromLists.length ? `<h4>From your lists</h4><div class="inv-chips">${fromLists.slice(0, 30).map((t) => `<button data-inv-starter="${esc(t)}" data-emoji="🛒" data-place="Other">${esc(t)}</button>`).join("")}</div>` : "")
    + Object.entries(inv.starters).filter(([, v]) => v.length).map(([place, items]) => `<h4>${place}</h4><div class="inv-chips">${items.map((x) =>
      `<button data-inv-starter="${esc(x.name)}" data-emoji="${esc(x.emoji)}" data-place="${place}">${esc(x.emoji)} ${esc(x.name)}</button>`).join("")}</div>`).join("")
    + (invKind !== "thing" ? `<h3 class="inv-start-h">📦 Things you own</h3>${thingStarters}` : "")
    + `<p class="muted small">Tap to add. Supplies start at 1 - use ＋/− after.</p>`;
}
$("inv-search").addEventListener("input", drawInventory);
$("inv-search").addEventListener("keydown", (e) => { if (e.key === "Enter") $("inv-add-btn").click(); });
$("inv-add-btn").addEventListener("click", async () => {
  const name = $("inv-search").value.trim();
  if (!name) return $("inv-search").focus();
  if (await invPost({ add: [{ name, place: invPlace !== "All" ? invPlace : "Other", kind: invKind === "thing" ? "thing" : "supply" }] }, "➕ Added")) $("inv-search").value = "", drawInventory();
});
$("panel-inventory").addEventListener("click", async (e) => {
  const kt = e.target.closest("[data-inv-kind-tab]");
  if (kt) { invKind = kt.dataset.invKindTab; return drawInventory(); }
  const tab = e.target.closest("[data-inv-place-tab]");
  if (tab) { invPlace = tab.dataset.invPlaceTab; return drawInventory(); }
  const st = e.target.closest("[data-inv-starter]");
  if (st) { st.disabled = true; return invPost({ add: [{ name: st.dataset.invStarter, emoji: st.dataset.emoji, place: st.dataset.place, kind: st.dataset.kind || "supply" }] }); }
  if (e.target.closest("[data-inv-shout-open]")) return openShout("");
  if (e.target.closest("[data-inv-shout-need]")) return openShout("NEED MORE " + inv.items.filter((i) => i.need || i.low).map((i) => i.name.toUpperCase()).slice(0, 3).join(", "));
  if (e.target.closest("[data-inv-allist]")) {
    for (const i of inv.items.filter((x) => x.need || x.low)) await post("/api/inventory", { to_list: i.id });
    return loadInventory().then(() => toast("🛒 All on your list"));
  }
  const row = e.target.closest("[data-inv]");
  if (!row) return;
  const id = row.dataset.inv, item = inv.items.find((i) => i.id === id);
  const ch = e.target.closest("[data-inv-change]");
  if (ch) return invPost({ id, change: +ch.dataset.invChange });
  if (e.target.closest("[data-inv-menu]")) { const m = row.querySelector(".inv-menu"); document.querySelectorAll(".inv-menu").forEach((x) => x !== m && (x.hidden = true)); m.hidden = !m.hidden; return; }
  if (e.target.closest("[data-inv-need]")) return invPost({ id, need: true }, "⚠️ Flagged - need more");
  if (e.target.closest("[data-inv-bought]")) return invPost({ id, bought: 1 }, "🛍 Stocked up");
  const tl = e.target.closest("[data-inv-tolist]");
  if (tl) return invPost({ to_list: id, list: tl.dataset.invTolist }, `🛒 On your ${(inv.lists.find((l) => l.id === tl.dataset.invTolist) || {}).name || "list"}`);
  if (e.target.closest("[data-inv-newlist]")) {
    const menu = row.querySelector(".inv-menu");
    if (!menu.querySelector(".inv-newlist")) menu.insertAdjacentHTML("beforeend", `<span class="inv-newlist"><input maxlength="30" placeholder="List name - e.g. Costco run"><button data-inv-newlist-go>Make it + add</button></span>`);
    return menu.querySelector(".inv-newlist input").focus();
  }
  if (e.target.closest("[data-inv-newlist-go]")) {
    const name = row.querySelector(".inv-newlist input").value.trim();
    if (!name) return;
    try {
      const before = new Set(inv.lists.map((l) => l.id));
      await post("/api/lists", { name, emoji: "🛒" });
      const fresh = await api("/api/inventory"), made = fresh.lists.find((l) => !before.has(l.id));
      return invPost({ to_list: id, list: made && made.id }, `🛒 Made “${name}” and added ${item.name}`);
    } catch (err) { return toast(err.message); }
  }
  if (e.target.closest("[data-inv-pct-off]")) return invPost({ id, pct: "" }, "Bar off");
  if (e.target.closest("[data-inv-check]")) {
    const box = row.querySelector(".inv-check");
    box.hidden = false; box.textContent = "🤖 thinking…";
    try {
      const r = await post("/api/inventory/check", { id });
      box.innerHTML = `<b>${r.verdict === "sounds right" ? "✅ Sounds right" : r.verdict === "probably lower" ? `⬇️ Probably lower - about ${r.suggest}%` : `⬆️ Probably higher - about ${r.suggest}%`}</b><span>${esc(r.why)}</span>${r.tip ? `<small class="muted">💡 ${esc(r.tip)}</small>` : ""}
        ${r.suggest !== item.pct ? `<button class="small-btn" data-inv-usepct="${r.suggest}">Use ${r.suggest}%</button>` : ""}`;
    } catch (err) { box.textContent = err.message; }
    return;
  }
  const up = e.target.closest("[data-inv-usepct]");
  if (up) return invPost({ id, pct: +up.dataset.invUsepct }, `🔋 ${up.dataset.invUsepct}%`).then(() => invReopen(id));
  const kd = e.target.closest("[data-inv-kind]");
  if (kd) return invPost({ id, kind: kd.dataset.invKind }, kd.dataset.invKind === "thing" ? "📦 Now a thing you own" : "🧻 Now counted as a supply");
  if (e.target.closest("[data-inv-shout]")) return openShout(`NEED MORE ${item.name.toUpperCase()}`);
  const rm = e.target.closest("[data-inv-remove]");
  if (rm) { if (!rm.dataset.sure) { rm.dataset.sure = 1; rm.textContent = "Tap again to remove"; return; } return invPost({ id, remove: true }, "Removed"); }
});
$("panel-inventory").addEventListener("change", (e) => {
  const row = e.target.closest("[data-inv]");
  if (!row) return;
  if (e.target.matches("[data-inv-low]")) invPost({ id: row.dataset.inv, low_at: e.target.value }, "Saved");
  if (e.target.matches("[data-inv-place]")) invPost({ id: row.dataset.inv, place: e.target.value }, "Moved");
  if (e.target.matches("[data-inv-notes]")) invPost({ id: row.dataset.inv, notes: e.target.value }, "Saved");
  if (e.target.matches("[data-inv-why]")) invPost({ id: row.dataset.inv, why: e.target.value }, "Saved");
  if (e.target.matches("[data-inv-pct]")) invPost({ id: row.dataset.inv, pct: +e.target.value }, `🔋 ${e.target.value}%`).then(() => invReopen(row.dataset.inv));
});

// 📢 SHOUT
function openShout(text) {
  $("shout-input").value = text;
  const need = inv ? inv.items.filter((i) => i.need || i.low).slice(0, 6) : [];
  $("shout-quick").innerHTML = ["DINNER'S READY", "COME HERE", "WHO TOOK MY CHARGER", ...need.map((i) => `NEED MORE ${i.name.toUpperCase()}`)].map((t) => `<button class="small-btn" data-shout-quick="${esc(t)}">${esc(t)}</button>`).join("");
  $("shout-modal").hidden = false;
  setTimeout(() => $("shout-input").focus(), 50);
}
$("shout-quick").addEventListener("click", (e) => { const b = e.target.closest("[data-shout-quick]"); if (b) $("shout-input").value = b.dataset.shoutQuick; });
$("shout-close").addEventListener("click", () => ($("shout-modal").hidden = true));
$("shout-go").addEventListener("click", async () => {
  try {
    const r = await post("/api/inventory/shout", { text: $("shout-input").value, speakers: $("shout-speakers").checked });
    $("shout-modal").hidden = true;
    if (status) status.shout = r.shout;
    toast(`📢 SHOUTED${r.speakers ? ` (+${r.speakers} speaker${r.speakers === 1 ? "" : "s"})` : ""}`);
    if (navigator.vibrate) navigator.vibrate([60, 40, 60]);
    drawShout();
  } catch (err) { toast(err.message); }
});
let shoutShown = null, overlayIs = null;
function sayItOutLoud(text) {  // the phone says it (works while Deck OS is open - phones won't let web apps talk when locked)
  try { if (!("speechSynthesis" in window)) return; speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(text); u.rate = 1; speechSynthesis.speak(u); } catch {}
}
function drawShout() {
  // 📱 someone announced straight to YOUR phone - comes first
  const pg = status && status.page;
  let seenPage = null; try { seenPage = localStorage.getItem("page_seen"); } catch {}
  if (pg && seenPage !== pg.id) {
    if (shoutShown !== "page:" + pg.id) {
      shoutShown = "page:" + pg.id; overlayIs = pg;
      $("shout-who").textContent = `📢 ${pg.name} says`;
      $("shout-text").textContent = pg.text;
      $("shout-onit").textContent = "👍 Coming!"; $("shout-again").hidden = false;
      $("shout-overlay").hidden = false;
      if (navigator.vibrate) navigator.vibrate([120, 60, 120]);
      sayItOutLoud(`${pg.name} says: ${pg.text}`);
    }
    return;
  }
  const s = status && status.shout;
  let seen = null; try { seen = localStorage.getItem("shout_seen"); } catch {}
  if (!s || s.mine || seen === s.id) { $("shout-overlay").hidden = true; drawMyShout(s); return; }
  if (shoutShown !== s.id) {
    shoutShown = s.id; overlayIs = s;
    $("shout-onit").textContent = "🙋 On it!"; $("shout-again").hidden = true;
    $("shout-who").textContent = `📢 ${s.name} SHOUTS`;
    $("shout-text").textContent = s.text + "!";
    $("shout-overlay").hidden = false;
    if (navigator.vibrate) navigator.vibrate([120, 60, 120, 60, 200]);
    if (typeof playTone === "function") playTone([880, 660, 880], 0.09);
  }
}
function drawMyShout(s) {  // the shouter sees who's on it
  if (!s || !s.mine || !(s.on_it || []).length) return;
  const key = s.id + ":" + s.on_it.length;
  let last = null; try { last = localStorage.getItem("shout_onit_seen"); } catch {}
  if (last === key) return;
  try { localStorage.setItem("shout_onit_seen", key); } catch {}
  toast(`🙋 ${s.on_it.join(", ")} ${s.on_it.length === 1 ? "is" : "are"} on it!`);
}
function dismissShout() {
  const pg = status && status.page;
  if (overlayIs && pg && overlayIs.id === pg.id) { try { localStorage.setItem("page_seen", pg.id); } catch {} }
  else { const s = status && status.shout; try { if (s) localStorage.setItem("shout_seen", s.id); } catch {} }
  $("shout-overlay").hidden = true;
  try { speechSynthesis.cancel(); } catch {}
  setTimeout(drawShout, 50);  // a shout might be waiting behind it
}
$("shout-again").addEventListener("click", () => { if (overlayIs) sayItOutLoud(`${overlayIs.name} says: ${overlayIs.text}`); });
$("shout-ok").addEventListener("click", dismissShout);
$("shout-onit").addEventListener("click", async () => {
  const pg = status && status.page;
  if (overlayIs && pg && overlayIs.id === pg.id) { dismissShout(); return toast("👍"); }
  const s = status && status.shout;
  dismissShout();
  if (s) try { await post("/api/inventory/shout", { ack: s.id }); toast("🙋 They'll see you're on it"); } catch (err) { toast(err.message); }
});

// double-tap an item = flag "need more" (again = clear it)
let invTap = { id: null, at: 0 };
$("inv-list").addEventListener("pointerup", (e) => {
  const row = e.target.closest("[data-inv]");
  if (!row || e.target.closest("button, input, select, label, .inv-menu")) return;
  const now = Date.now();
  if (invTap.id === row.dataset.inv && now - invTap.at < 380) {
    invTap = { id: null, at: 0 };
    const item = inv.items.find((i) => i.id === row.dataset.inv);
    const on = !(item.need || item.low);
    if (navigator.vibrate) navigator.vibrate(25);
    invPost({ id: item.id, need: on, ...(on ? {} : item.low ? { bought: 1 } : {}) }, on ? `⚠️ ${item.name}: need more` : `✓ ${item.name}: all good`);
  } else invTap = { id: row.dataset.inv, at: now };
});
$("inv-list").addEventListener("dblclick", (e) => e.preventDefault());

// keep an item's menu open after a change redraws the list
function invReopen(id) { const m = document.querySelector(`[data-inv="${id}"] .inv-menu`); if (m) m.hidden = false; }
$("inv-list").addEventListener("input", (e) => {
  if (!e.target.matches("[data-inv-pct]")) return;
  const lab = e.target.parentElement.querySelector("[data-inv-pct-label]");
  if (lab) lab.textContent = e.target.value + "%";
});
