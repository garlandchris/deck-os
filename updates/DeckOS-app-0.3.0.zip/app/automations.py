"""🤖 Automations for Deck OS - Home Assistant's own automations, drawn as
boxes joined by lines (like n8n): WHEN something happens -> ONLY IF it's the
right time -> THEN do these steps, one after another.

Two jobs:
- flow(): turn any Home Assistant automation into plain-English boxes to draw.
- build(): turn what someone made in Deck OS's builder into a real Home
  Assistant automation. Deck OS keeps the builder's version too (see server.py),
  so the same boxes can be edited again later.
"""
import os
import re
from datetime import datetime


def PF(fmt: str) -> str:
    """strftime without leading zeros: Linux/Mac say %-I, Windows says %#I."""
    return fmt.replace("%-", "%#") if os.name == "nt" else fmt

DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
DAY_NAMES = dict(zip(DAYS, ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]))
HHMM = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


def _clock(hhmmss) -> str:
    """"07:30:00" -> "7:30 AM" (anything else is shown as it is)."""
    text = str(hhmmss)
    for fmt in ("%H:%M:%S", "%H:%M"):
        try:
            return datetime.strptime(text, fmt).strftime(PF("%-I:%M %p"))
        except ValueError:
            pass
    return text


def _short(text, limit: int = 110) -> str:
    text = " ".join(str(text).split())
    return text if len(text) <= limit else text[:limit - 1] + "…"


def _ids(value) -> list[str]:
    if isinstance(value, str):
        return [v.strip() for v in value.split(",") if v.strip()]
    return [str(v) for v in value or []]


def _targets(step: dict) -> list[str]:
    """Every entity a step points at, wherever Home Assistant lets you put it."""
    found = []
    for where in (step.get("target") or {}, step.get("data") or {}, step):
        found += _ids(where.get("entity_id"))
    return found


def _node(kind: str, icon: str, title: str, detail: str = "") -> dict:
    return {"kind": kind, "icon": icon, "title": _short(title, 70), "detail": _short(detail) if detail else ""}


# ---------------------------------------------------------------- reading any automation
def flow(config: dict, name) -> list[list[dict]]:
    """An automation as columns of boxes, left to right. Every box in a column
    connects to every box in the next one. `name(entity_id)` gives a friendly name."""
    names = lambda ids: ", ".join(name(i) for i in ids) or "something"
    columns = []
    triggers = config.get("triggers") or config.get("trigger") or []
    triggers = [triggers] if isinstance(triggers, dict) else triggers
    columns.append([_trigger(t, names) for t in triggers] or [_node("trigger", "✋", "Only when you run it")])
    conditions = config.get("conditions") or config.get("condition") or []
    for c in [conditions] if isinstance(conditions, dict) else conditions:
        columns.append([_condition(c, names, "condition")])
    actions = config.get("actions") or config.get("action") or []
    for a in [actions] if isinstance(actions, dict) else actions:
        columns.append([_action(a, names)])
    return columns


def _trigger(t: dict, names) -> dict:
    kind = t.get("trigger") or t.get("platform") or ""
    who = names(_ids(t.get("entity_id")))
    if kind == "time":
        return _node("trigger", "⏰", f"At {', '.join(_clock(a) for a in _ids(t.get('at')))}")
    if kind == "sun":
        offset = str(t.get("offset") or "")
        when = "sunrise" if t.get("event") == "sunrise" else "sunset"
        extra = ""
        m = re.match(r"^([+-])?(\d+):(\d+)", offset)
        if m and (int(m[2]) or int(m[3])):
            minutes = int(m[2]) * 60 + int(m[3])
            extra = f"{minutes} min {'before' if m[1] == '-' else 'after'} "
        return _node("trigger", "🌅" if when == "sunrise" else "🌇", f"{extra}{when}".capitalize() if extra else f"At {when}")
    if kind == "state":
        to = t.get("to")
        if to in ("on", "off"):
            return _node("trigger", "💡", f"When {who} turns {to}")
        if to in ("home", "not_home"):
            return _node("trigger", "🏠", f"When {who} {'gets home' if to == 'home' else 'leaves'}")
        return _node("trigger", "🔄", f"When {who} changes" + (f" to {to}" if to is not None else ""))
    if kind == "numeric_state" and _ids(t.get("entity_id")) == ["zone.home"]:
        return _node("trigger", "🚪" if "below" in t else "🏠", "When everyone has left" if "below" in t else "When someone gets home")
    if kind == "state" and t.get("to") == "playing":
        return _node("trigger", "🎬", f"When {who} starts playing")
    if kind == "state" and t.get("from") == "playing":
        return _node("trigger", "⏹", f"When {who} stops playing")
    if kind == "numeric_state":
        what = f"{who}" + (f" ({t['attribute']})" if t.get("attribute") else "")
        limits = " and ".join(f"{w} {t[k]}" for k, w in (("above", "above"), ("below", "below")) if k in t)
        return _node("trigger", "📈", f"When {what} goes {limits}")
    if kind == "zone":
        return _node("trigger", "🏠", f"When {who} {'gets home' if t.get('event') == 'enter' else 'leaves home'}")
    if kind == "event":
        if t.get("event_type") == "nest_event":
            return _node("trigger", "📷", "When a Nest camera sees something")
        return _node("trigger", "⚡", f"When “{t.get('event_type')}” happens")
    if kind == "time_pattern":
        every = next((f"{v.lstrip('/')} {u}" for u, v in (("hours", t.get("hours")), ("minutes", t.get("minutes")),
                                                          ("seconds", t.get("seconds"))) if str(v or "").startswith("/")), "")
        return _node("trigger", "🔁", f"Every {every}" if every else "On a repeating schedule")
    if kind == "homeassistant":
        return _node("trigger", "▶", "When Home Assistant starts" if t.get("event") == "start" else "When Home Assistant stops")
    if kind == "template":
        return _node("trigger", "🧩", "When a custom check becomes true", t.get("value_template", ""))
    if kind == "webhook":
        return _node("trigger", "🔗", "When a webhook is called")
    return _node("trigger", "⚡", f"When {kind or 'something'} happens")


def _condition(c: dict, names, kind: str) -> dict:
    if isinstance(c, str):  # shorthand template condition
        return _node(kind, "🧩", "Custom check", c)
    ctype = c.get("condition", "")
    if ctype == "time":
        parts = []
        if c.get("after") or c.get("before"):
            parts.append(f"between {_clock(c.get('after', '00:00'))} and {_clock(c.get('before', '23:59'))}")
        if c.get("weekday"):
            parts.append("on " + ", ".join(DAY_NAMES.get(d, d) for d in _ids(c["weekday"])))
        return _node(kind, "🕒", "Only " + " ".join(parts) if parts else "Only at certain times")
    if ctype == "state":
        return _node(kind, "🔎", f"Only if {names(_ids(c.get('entity_id')))} is {c.get('state')}")
    if ctype == "numeric_state":
        limits = " and ".join(f"{w} {c[w]}" for w in ("above", "below") if w in c)
        return _node(kind, "📈", f"Only if {names(_ids(c.get('entity_id')))} is {limits}")
    if ctype == "sun":
        return _node(kind, "🌗", "Only " + " and ".join(f"{k} {v}" for k, v in c.items() if k in ("after", "before")))
    if ctype == "zone":
        return _node(kind, "🏠", f"Only if {names(_ids(c.get('entity_id')))} is home")
    if ctype == "template":
        return _node(kind, "🧩", "Custom check", c.get("value_template", ""))
    if ctype in ("and", "or", "not"):
        inner = c.get("conditions") or []
        if ctype == "not" and len(inner) == 1:
            return _node(kind, "🚫", "Not: " + _condition(inner[0], names, kind)["title"].removeprefix("Only "),
                         _condition(inner[0], names, kind)["detail"])
        word = {"and": "All of", "or": "Any of", "not": "None of"}[ctype]
        return _node(kind, "🚫" if ctype == "not" else "🔗", f"{word} {len(inner)} check{'s' if len(inner) != 1 else ''}",
                     "; ".join(_condition(i, names, kind)["title"] for i in inner))
    if ctype == "trigger":
        return _node(kind, "🔎", "Only for one of the triggers")
    return _node(kind, "🔎", f"Only if {ctype or 'a check'} passes")


def _action(a: dict, names) -> dict:
    service = a.get("action") or a.get("service")
    if isinstance(service, str) and "." in service:
        domain, verb = service.split(".", 1)
        who = names(_targets(a))
        data = a.get("data") or {}
        if domain == "light" and verb in ("turn_on", "turn_off", "toggle"):
            extra = f"at {data['brightness_pct']}%" if "brightness_pct" in data else ""
            return _node("action", "💡", f"{verb.replace('_', ' ').capitalize()} {who}", extra)
        if domain == "scene":
            return _node("action", "🎬", f"Set the scene {who}")
        if domain == "notify" or service == "persistent_notification.create":
            where = "Home Assistant" if domain == "persistent_notification" else verb.replace("mobile_app_", "").replace("_", " ")
            return _node("action", "📱", f"Send a notification to {where}", data.get("message", ""))
        if service in ("tts.speak", "assist_satellite.announce") or domain == "tts":
            speaker = _ids(data.get("media_player_entity_id")) or _targets(a)  # tts.speak targets the voice, not the speaker
            return _node("action", "🔊", f"Say out loud on {names(speaker)}", data.get("message", ""))
        if domain == "media_player":
            return _node("action", "🎵", f"{verb.replace('media_', '').replace('_', ' ').capitalize()} on {who}")
        if domain in ("script", "automation"):
            return _node("action", "📜", f"Run {who}" if verb == "turn_on" else f"{verb.replace('_', ' ').capitalize()} {who}")
        if domain in ("input_datetime", "input_text", "input_number", "input_boolean", "input_select"):
            return _node("action", "📝", f"Update {who}")
        return _node("action", "⚙", f"{domain.replace('_', ' ').capitalize()}: {verb.replace('_', ' ')}", who if _targets(a) else "")
    if "delay" in a:
        d = a["delay"]
        if isinstance(d, dict):
            text = " ".join(f"{v} {k}" for k, v in d.items() if v)
        else:
            text = str(d)
        return _node("action", "⏳", f"Wait {text}")
    if "wait_template" in a or "wait_for_trigger" in a:
        return _node("action", "⏳", "Wait until something happens")
    if "if" in a:
        steps = len(a.get("then") or [])
        checks = a["if"] if isinstance(a["if"], list) else [a["if"]]
        return _node("action", "🔀", f"If {'; '.join(_condition(c, names, 'action')['title'].removeprefix('Only ').removeprefix('if ') for c in checks)}",
                     f"then {steps} step{'s' if steps != 1 else ''}" + (", otherwise something else" if a.get("else") else ""))
    if "choose" in a:
        return _node("action", "🔀", f"Pick one of {len(a['choose'])} paths")
    if "repeat" in a:
        return _node("action", "🔁", "Repeat some steps")
    if "condition" in a:
        return _condition(a, names, "action")
    if "parallel" in a:
        return _node("action", "⏩", f"Do {len(a['parallel'])} things at once")
    if "variables" in a:
        return _node("action", "📝", "Remember some values")
    if "stop" in a:
        return _node("action", "⏹", "Stop here", a.get("stop", ""))
    if "event" in a:
        return _node("action", "⚡", f"Fire “{a['event']}”")
    return _node("action", "⚙", "A step")


# ---------------------------------------------------------------- building from the Deck OS builder
def _offset(minutes: int) -> str:
    sign = "-" if minutes < 0 else "+"
    minutes = abs(minutes)
    return f"{sign}{minutes // 60:02d}:{minutes % 60:02d}:00"


def build(model: dict, allowed: dict) -> tuple[dict, dict]:
    """The builder's boxes -> (a clean copy of them, the Home Assistant automation).
    `allowed` says what this person can use: {"lights", "scenes", "people"} (sets of
    entity_ids), "notify" (a notify service or None), "say" (a speaker or None).
    Anything else raises ValueError with a message to show them."""
    name = " ".join(str(model.get("name", "")).split())[:60]
    if not name:
        raise ValueError("Give the automation a name")

    when = model.get("when") or {}
    kind = when.get("kind")
    if kind == "time":
        if not HHMM.match(str(when.get("at", ""))):
            raise ValueError("Pick a time for it to start")
        clean_when = {"kind": "time", "at": when["at"]}
        trigger = {"trigger": "time", "at": when["at"] + ":00"}
    elif kind == "sun":
        event = "sunrise" if when.get("event") == "sunrise" else "sunset"
        minutes = max(-180, min(180, int(when.get("offset") or 0)))
        clean_when = {"kind": "sun", "event": event, "offset": minutes}
        trigger = {"trigger": "sun", "event": event, "offset": _offset(minutes)}
    elif kind == "light":
        entity, to = when.get("entity"), "off" if when.get("to") == "off" else "on"
        if entity not in allowed["lights"]:
            raise ValueError("Pick a light for it to watch")
        clean_when = {"kind": "light", "entity": entity, "to": to}
        trigger = {"trigger": "state", "entity_id": entity, "from": "off" if to == "on" else "on", "to": to}
    elif kind in ("arrive", "leave"):
        entity = when.get("entity")
        if entity not in allowed["people"]:
            raise ValueError("Pick who it's for")
        clean_when = {"kind": kind, "entity": entity}
        trigger = {"trigger": "zone", "entity_id": entity, "zone": "zone.home", "event": "enter" if kind == "arrive" else "leave"}
    elif kind == "tv":  # movie mode: when the TV starts (or stops) playing
        entity, to = when.get("entity"), "idle" if when.get("to") == "stops" else "playing"
        if entity not in allowed.get("tvs", ()):
            raise ValueError("Pick which TV")
        clean_when = {"kind": "tv", "entity": entity, "to": "stops" if to == "idle" else "plays"}
        trigger = ({"trigger": "state", "entity_id": entity, "to": "playing"} if to == "playing"
                   else {"trigger": "state", "entity_id": entity, "from": "playing"})
    elif kind in ("nobody_home", "somebody_home"):  # the house empties out / the first person gets back
        if not allowed.get("people"):
            raise ValueError("That one needs people's phones set up in Home Assistant")
        clean_when = {"kind": kind}
        trigger = ({"trigger": "numeric_state", "entity_id": "zone.home", "below": 1} if kind == "nobody_home"
                   else {"trigger": "numeric_state", "entity_id": "zone.home", "above": 0})
    else:
        raise ValueError("Pick what starts it")

    only = model.get("only_if") or {}
    clean_only, conditions = {}, []
    if only.get("after") or only.get("before"):
        after, before = str(only.get("after", "")), str(only.get("before", ""))
        if not (HHMM.match(after) and HHMM.match(before)):
            raise ValueError("Pick both times for “only between”")
        clean_only |= {"after": after, "before": before}
        conditions.append({"condition": "time", "after": after + ":00", "before": before + ":00"})
    days = [d for d in DAYS if d in (only.get("days") or [])]
    if days and len(days) < 7:
        clean_only["days"] = days
        conditions.append({"condition": "time", "weekday": days})

    steps, actions = [], []
    for step in (model.get("then") or [])[:20]:
        kind = step.get("kind")
        if kind in ("light_on", "light_off"):
            if step.get("entity") not in allowed["lights"]:
                raise ValueError("Pick a light for each light step")
            clean = {"kind": kind, "entity": step["entity"]}
            action = {"action": "light." + ("turn_on" if kind == "light_on" else "turn_off"),
                      "target": {"entity_id": step["entity"]}}
            if kind == "light_on" and step.get("brightness"):
                clean["brightness"] = max(1, min(100, int(step["brightness"])))
                action["data"] = {"brightness_pct": clean["brightness"]}
        elif kind == "scene":
            if step.get("entity") not in allowed["scenes"]:
                raise ValueError("Pick a scene")
            clean = {"kind": "scene", "entity": step["entity"]}
            action = {"action": "scene.turn_on", "target": {"entity_id": step["entity"]}}
        elif kind == "wait":
            minutes = max(1, min(720, int(step.get("minutes") or 1)))
            clean = {"kind": "wait", "minutes": minutes}
            action = {"delay": {"minutes": minutes}}
        elif kind in ("notify", "say"):
            message = " ".join(str(step.get("message", "")).split())[:200]
            if not message:
                raise ValueError("Type what the message should say")
            target = allowed["notify" if kind == "notify" else "say"]
            if not target:
                raise ValueError("That step isn't set up for your account")
            clean = {"kind": kind, "message": message}
            action = ({"action": target, "data": {"title": name, "message": message}} if kind == "notify" else
                      {"action": "assist_satellite.announce", "target": {"entity_id": target},
                       "data": {"message": message, "preannounce": False}})
        else:
            continue
        steps.append(clean)
        actions.append(action)
    if not actions:
        raise ValueError("Add at least one thing for it to do")

    clean_model = {"name": name, "when": clean_when, "only_if": clean_only, "then": steps}
    config = {"alias": name, "description": "Made in Deck OS", "mode": "single",
              "triggers": [trigger], "conditions": conditions, "actions": actions}
    return clean_model, config
