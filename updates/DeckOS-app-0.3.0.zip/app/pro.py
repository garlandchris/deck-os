"""Deck OS Pro: a license key bought from the Deck OS store (Lemon Squeezy).

- The home's owner types the key in System -> Pro. Deck OS "activates" it with
  Lemon Squeezy once (counts as one home), then re-checks about once a week.
- If the internet or Lemon Squeezy is down, Pro keeps working for 30 days since
  the last good check - nobody loses features because their Wi-Fi blinked.
- Nothing about the home is sent - only the key and a name for this install.
"""
import socket
import time

import httpx

from discovery import DEMO, SETTINGS, save_settings

API = "https://api.lemonsqueezy.com/v1/licenses"
RECHECK_DAYS = 7
GRACE_DAYS = 30


def _license() -> dict:
    return SETTINGS.get("license") or {}


def is_pro() -> bool:
    if DEMO:
        return True  # demos show everything
    lic = _license()
    return bool(lic.get("valid")) and time.time() - lic.get("checked", 0) < GRACE_DAYS * 86400


def summary() -> dict:
    lic = _license()
    key = lic.get("key", "")
    return {"pro": is_pro(), "key_hint": f"…{key[-4:]}" if key else "", "plan": lic.get("plan", ""),
            "error": lic.get("error")}


async def _post(endpoint: str, data: dict) -> dict:
    async with httpx.AsyncClient(timeout=15) as client:
        reply = await client.post(f"{API}/{endpoint}", data=data, headers={"Accept": "application/json"})
        return reply.json()


async def activate(key: str) -> dict:
    """First time a key is typed in: claims one activation for this home."""
    key = key.strip()
    try:
        got = await _post("activate", {"license_key": key, "instance_name": f"Deck OS on {socket.gethostname()}"})
    except (httpx.HTTPError, ValueError):
        raise ValueError("Couldn't reach the Deck OS store - check the internet and try again")
    if not got.get("activated"):
        error = got.get("error") or ""
        if "not found" in error:
            raise ValueError("That key wasn't found - copy the whole key from your receipt email")
        raise ValueError(error or "That key didn't work")
    save_settings({"license": {"key": key, "instance": got["instance"]["id"], "valid": True, "checked": time.time(),
                               "plan": got.get("meta", {}).get("variant_name") or got.get("meta", {}).get("product_name", "")}})
    return summary()


async def recheck() -> None:
    """About once a week: is the key still good (not refunded, subscription still paid)?"""
    lic = _license()
    if DEMO or not lic.get("key") or time.time() - lic.get("checked", 0) < RECHECK_DAYS * 86400:
        return
    try:
        got = await _post("validate", {"license_key": lic["key"], "instance_id": lic.get("instance", "")})
    except (httpx.HTTPError, ValueError):
        return  # offline - the grace period covers it
    status = got.get("license_key", {}).get("status")
    save_settings({"license": {**lic, "valid": bool(got.get("valid")) and status in ("active", None),
                               "checked": time.time(), "error": None if got.get("valid") else got.get("error") or status}})


def remove() -> None:
    save_settings({"license": None})
