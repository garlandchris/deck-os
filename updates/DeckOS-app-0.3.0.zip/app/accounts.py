"""Accounts, logins and invites for Deck OS.

- The first person to set up Deck OS becomes the admin (the home's owner).
- The admin invites people with a link. Opening it lets them pick their own
  password - the admin never knows it.
- Passwords are never stored, only a scrambled "hash" of them (scrypt).
- Everything lives in data/ next to this file (never committed to git).
"""
import hashlib
import hmac
import json
import os
import re
import secrets
import time
from contextvars import ContextVar
from pathlib import Path

DATA = Path(os.environ.get("DECKOS_DATA") or Path(__file__).resolve().parent / "data")
USERS_FILE = DATA / "users.json"
SESSIONS_FILE = DATA / "sessions.json"
INVITES_FILE = DATA / "invites.json"

SESSION_DAYS = 90       # stay logged in on your own phone/Mac
INVITE_DAYS = 7         # invite links expire after a week
MIN_PASSWORD = 8

# Who someone is in the home. "member" is shown as Adult.
ROLES = ("member", "kid", "guest", "relative")  # relative = family who don't live here (the family web)
FREE_GUESTS = 2         # guests a home can have without Pro
# Kids start with these turned off - the owner can change it per kid
KID_BLOCKED = ["food", "browser", "markets", "apps", "automations"]

# How someone is related to the home's owner -> their generation in the family tree
# (+1 = the owner's parents' row, -1 = the owner's kids' row, None = not in the tree)
RELATIONS = {
    "Great-grandma": 3, "Great-grandpa": 3, "Great-grandparent": 3,
    "Grandma": 2, "Grandpa": 2, "Grandparent": 2, "Great-aunt": 2, "Great-uncle": 2,
    "Mom": 1, "Dad": 1, "Parent": 1, "Stepmom": 1, "Stepdad": 1, "Aunt": 1, "Uncle": 1,
    "Mother-in-law": 1, "Father-in-law": 1,
    "Wife": 0, "Husband": 0, "Partner": 0, "Sister": 0, "Brother": 0, "Sibling": 0, "Cousin": 0,
    "Sister-in-law": 0, "Brother-in-law": 0,
    "Daughter": -1, "Son": -1, "Child": -1, "Stepdaughter": -1, "Stepson": -1, "Niece": -1, "Nephew": -1,
    "Daughter-in-law": -1, "Son-in-law": -1,
    "Granddaughter": -2, "Grandson": -2, "Grandchild": -2,
    "Friend": None, "Roommate": None, "Other": None,
}

# Who's making the current request (set per request by server.py)
current_user: ContextVar[dict | None] = ContextVar("current_user", default=None)


def _load(path: Path) -> dict:
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, ValueError):
        return {}


def _save(path: Path, data: dict) -> None:
    DATA.mkdir(exist_ok=True)
    DATA.chmod(0o700)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=1))
    tmp.chmod(0o600)
    tmp.replace(path)


def _hash(password: str, salt: bytes) -> str:
    return hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1).hex()


def clean_username(name: str) -> str:
    return re.sub(r"[^a-z0-9_.-]", "", name.strip().lower())[:24]


# ---------------------------------------------------------------- users
def users() -> dict:
    return _load(USERS_FILE)


def has_admin() -> bool:
    return any(u.get("role") == "admin" for u in users().values())


def create_user(username: str, display_name: str, password: str, role: str = "member",
                guest_days: int | None = None, relation: str | None = None, invited_by: str | None = None,
                home: str | None = None) -> dict:
    username = clean_username(username)
    if not username:
        raise ValueError("Pick a username (letters and numbers)")
    if len(password) < MIN_PASSWORD:
        raise ValueError(f"Password needs at least {MIN_PASSWORD} characters")
    all_users = users()
    if username in all_users or username in _load(PENDING_FILE):
        raise ValueError("That username is taken")
    salt = secrets.token_bytes(16)
    all_users[username] = {
        "name": " ".join(display_name.split())[:30] or username,
        "role": role,
        "salt": salt.hex(),
        "password": _hash(password, salt),
        "created": int(time.time()),
        # what the admin has shared with this person (admins get everything)
        "allowed": {"lights": [], "cameras": [], "scenes": False, "devices": []},
        "blocked": list(KID_BLOCKED) if role == "kid" else [],
        "bedtime": None,
        "relation": relation if relation in RELATIONS else None,
        "through": None,  # related via another person, e.g. an Uncle through Dad
        "invited_by": invited_by,  # "relation" is what they are to this person (the family web)
        "home": home,  # relatives: whose household space they share (their own username = their own home)
    }
    if role == "guest":
        all_users[username]["expires"] = time.time() + (guest_days or 7) * 86400
    _save(USERS_FILE, all_users)
    return public(username, all_users[username])


def login_name(typed: str) -> str:
    """Whatever someone types to sign in -> their username. The username itself (any capitals, spaces, a leading @)
    or their name - "Sam Rivera" or just "Sam" - when only one person here goes by it."""
    username, people = clean_username(typed), users()
    if username in people:
        return username
    said = " ".join(str(typed).split()).lower()
    for match in (lambda u: u["name"].lower() == said, lambda u: u["name"].lower().split()[0] == said):
        hits = [n for n, u in people.items() if said and u.get("name") and match(u)]
        if len(hits) == 1:
            return hits[0]
    return username


def check_password(username: str, password: str) -> dict | None:
    username = login_name(username)
    user = users().get(username)
    if not user:
        _hash(password, b"x" * 16)  # same time whether or not the user exists
        return None
    if hmac.compare_digest(user["password"], _hash(password, bytes.fromhex(user["salt"]))):
        return public(username, user)
    return None


def public(username: str, user: dict) -> dict:
    """A user without their password bits - safe to hand to the rest of Deck OS."""
    return {"username": username, "name": user["name"], "role": user["role"],
            "allowed": user.get("allowed", {}), "blocked": user.get("blocked", []),
            "bedtime": user.get("bedtime"), "expires": user.get("expires"),
            "relation": user.get("relation"), "through": user.get("through")}


def expired(user: dict) -> bool:
    return bool(user.get("expires")) and user["expires"] < time.time()


def active_guests() -> int:
    return sum(1 for u in users().values() if u.get("role") == "guest" and not expired(u))


def update_rules(username: str, rules: dict) -> None:
    """What the owner decided for this person: their role, features switched off,
    bedtime (kids), and for guests how many more days they have."""
    all_users = users()
    user = all_users.get(username)
    if not user or user["role"] == "admin":
        return
    if rules.get("role") in ROLES:
        if rules["role"] == "kid" and user["role"] != "kid":
            user["blocked"] = list(KID_BLOCKED)
        if rules["role"] == "guest" and not user.get("expires"):
            user["expires"] = time.time() + 7 * 86400
        if rules["role"] != "guest":
            user.pop("expires", None)
        user["role"] = rules["role"]
    if isinstance(rules.get("blocked"), list):
        user["blocked"] = [str(f) for f in rules["blocked"]][:20]
    if "bedtime" in rules:
        bed = rules["bedtime"]
        ok = isinstance(bed, dict) and all(re.fullmatch(r"\d\d:\d\d", str(bed.get(k, ""))) for k in ("start", "end"))
        user["bedtime"] = {"start": bed["start"], "end": bed["end"]} if ok else None
    if rules.get("guest_days") and user["role"] == "guest":
        user["expires"] = time.time() + max(1, min(int(rules["guest_days"]), 365)) * 86400
    if "relation" in rules:
        user["relation"] = rules["relation"] if rules["relation"] in RELATIONS else None
    if "through" in rules:
        through = rules["through"]
        user["through"] = through if through in all_users and through != username else None
    _save(USERS_FILE, all_users)


def get_user(username: str) -> dict | None:
    user = users().get(username)
    return public(username, user) if user else None


def update_allowed(username: str, allowed: dict) -> None:
    all_users = users()
    if username in all_users:
        all_users[username]["allowed"] = allowed
        _save(USERS_FILE, all_users)


# 🙋 Joining by invite: the person says who they are (name, email, why they're joining) and then WAITS - they're
# kept here, not in users.json, so they're nowhere in the family (chats, tree, lists) until the owner says yes.
PENDING_FILE = DATA / "pending_joins.json"


def pending_joins() -> dict:
    return _load(PENDING_FILE)


def add_pending(username: str, display_name: str, password: str, email: str, reason: str, invite_token: str, invite: dict) -> tuple[str, str]:
    """Returns (username, wait token) - the wait token is what their browser holds while they wait."""
    username = clean_username(username)
    if not username:
        raise ValueError("Pick a username (letters and numbers)")
    if len(password) < MIN_PASSWORD:
        raise ValueError(f"Password needs at least {MIN_PASSWORD} characters")
    if username in users() or username in pending_joins():
        raise ValueError("That username is taken")
    salt, wait = secrets.token_bytes(16), secrets.token_urlsafe(24)
    data = pending_joins()
    data[username] = {"name": " ".join(display_name.split())[:30] or username, "salt": salt.hex(), "password": _hash(password, salt),
                      "email": email, "reason": reason, "at": int(time.time()), "invite_token": invite_token, "invite": invite,
                      "wait": hashlib.sha256(wait.encode()).hexdigest()}
    _save(PENDING_FILE, data)
    return username, wait


def pending_by_wait(wait: str | None) -> tuple[str, dict] | None:
    key = hashlib.sha256((wait or "").encode()).hexdigest()
    return next(((n, p) for n, p in pending_joins().items() if wait and p["wait"] == key), None)


def drop_pending(username: str) -> dict | None:
    data = pending_joins()
    gone = data.pop(username, None)
    _save(PENDING_FILE, data)
    return gone


def approve_pending(username: str) -> dict:
    """Makes the real account (same password they chose) and returns it, plus the invite it came from."""
    p = pending_joins().get(username)
    if not p:
        raise ValueError("Nobody waiting by that name")
    inv = p["invite"]
    role = inv.get("role", "member")
    all_users = users()
    all_users[username] = {
        "name": p["name"], "role": role, "salt": p["salt"], "password": p["password"], "created": int(time.time()),
        "allowed": {"lights": [], "cameras": [], "scenes": False, "devices": []},
        "blocked": list(KID_BLOCKED) if role == "kid" else [], "bedtime": None,
        "relation": inv.get("relation") if inv.get("relation") in RELATIONS else None, "through": None,
        "invited_by": inv.get("by") if role == "relative" else None, "home": inv.get("home") if role == "relative" else None,
        "email": p["email"], "join_reason": p["reason"], "approved": int(time.time()),
    }
    if role == "guest":
        all_users[username]["expires"] = time.time() + int(inv.get("guest_days") or 7) * 86400
    all_users[username]["wait_hash"] = p["wait"]  # so their waiting screen can sign them straight in
    _save(USERS_FILE, all_users)
    drop_pending(username)
    return {"user": public(username, all_users[username]), "invite": inv, "invite_token": p["invite_token"]}


def take_waiter(wait: str | None) -> str | None:
    """Their waiting screen asks "am I in yet?" - once approved, hands back their username (one time)."""
    key = hashlib.sha256((wait or "").encode()).hexdigest()
    all_users = users()
    name = next((n for n, u in all_users.items() if wait and u.get("wait_hash") == key), None)
    if name:
        all_users[name].pop("wait_hash", None)
        _save(USERS_FILE, all_users)
    return name


def remove_user(username: str) -> None:
    all_users = users()
    if all_users.get(username, {}).get("role") == "admin":
        raise ValueError("The admin can't be removed")
    all_users.pop(username, None)
    _save(USERS_FILE, all_users)
    sessions = {t: s for t, s in _load(SESSIONS_FILE).items() if s["user"] != username}
    _save(SESSIONS_FILE, sessions)


# ---------------------------------------------------------------- sessions
def start_session(username: str) -> str:
    token = secrets.token_urlsafe(32)
    sessions = {t: s for t, s in _load(SESSIONS_FILE).items() if s["expires"] > time.time()}
    sessions[token] = {"user": username, "expires": time.time() + SESSION_DAYS * 86400}
    _save(SESSIONS_FILE, sessions)
    return token


def user_for_session(token: str | None) -> dict | None:
    if not token:
        return None
    session = _load(SESSIONS_FILE).get(token)
    if not session or session["expires"] < time.time():
        return None
    user = get_user(session["user"])
    return None if user is None or expired(user) else user


def end_session(token: str | None) -> None:
    sessions = _load(SESSIONS_FILE)
    if token in sessions:
        sessions.pop(token)
        _save(SESSIONS_FILE, sessions)


# ---------------------------------------------------------------- invites
# An invite link can be used by several people (e.g. dropped in a family group
# chat) - each person who opens it types their own name and makes their own account.
def create_invite(label: str, invited_by: str, max_uses: int = 10, role: str = "member", guest_days: int = 7,
                  relation: str | None = None, allowed: dict | None = None, first_message: str | None = None,
                  home: str | None = None) -> str:
    token = secrets.token_urlsafe(18)
    invites = {t: i for t, i in _load(INVITES_FILE).items() if _still_good(i)}
    invites[token] = {"label": " ".join(label.split())[:30], "by": invited_by, "uses": 0,
                      "role": role if role in ROLES else "member", "guest_days": max(1, min(int(guest_days), 365)),
                      "relation": relation if relation in RELATIONS else None,
                      "max_uses": max(1, min(int(max_uses), 50)), "joined": [],
                      "allowed": allowed,  # lights/cameras shared with whoever joins, from day one
                      "first_message": first_message,  # waiting for them in a private chat the moment they join
                      "home": home,  # a relative who lives with the relative who invited them shares their household
                      "expires": time.time() + INVITE_DAYS * 86400}
    _save(INVITES_FILE, invites)
    return token


def _still_good(invite: dict) -> bool:
    return invite["expires"] > time.time() and invite.get("uses", 0) < invite.get("max_uses", 1) and not invite.get("used")


def get_invite(token: str) -> dict | None:
    invite = _load(INVITES_FILE).get(token)
    return invite if invite and _still_good(invite) else None


def use_invite(token: str, username: str) -> None:
    invites = _load(INVITES_FILE)
    if token in invites:
        invites[token]["uses"] = invites[token].get("uses", 0) + 1
        invites[token].setdefault("joined", []).append(username)
        _save(INVITES_FILE, invites)


def pending_invites() -> list[dict]:
    return [{"label": i.get("label") or "Invite link", "uses": i.get("uses", 0), "max_uses": i.get("max_uses", 1),
             "role": i.get("role", "member"),
             "joined": i.get("joined", []), "expires": int(i["expires"])}
            for i in _load(INVITES_FILE).values() if _still_good(i)]


# ---------------------------------------------------------------- login rate limit
_attempts: dict[str, list[float]] = {}


def too_many_attempts(ip: str) -> bool:
    """At most 5 wrong passwords per minute from one device."""
    recent = [t for t in _attempts.get(ip, []) if time.time() - t < 60]
    _attempts[ip] = recent
    return len(recent) >= 5


def record_failed_attempt(ip: str) -> None:
    _attempts.setdefault(ip, []).append(time.time())
