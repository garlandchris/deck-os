"""Demo mode: a made-up home, so Deck OS can be shown off (screenshots, videos,
a live demo) without revealing anyone's real house, cameras or location.

Turn it on with the environment variable DECKOS_DEMO=1. Deck OS then talks to
this fake Home Assistant instead of a real one - buttons work (lights really
toggle and change color on screen), but nothing leaves the computer.

Two made-up homes (DECKOS_DEMO_HOME picks one):
  alex      - the original: a techy home with servers, markets and LED lights
  showcase  - a family house full of gear: thermostats, locks, garage, blinds,
              robot vacuum, solar + home battery + EV. Show someone what theirs
              could look like. DECKOS_DEMO_NAME sets whose home it is.
"""
import copy
import os
import random
from datetime import datetime, timedelta


def PF(fmt: str) -> str:
    """strftime without leading zeros: Linux/Mac say %-I, Windows says %#I."""
    return fmt.replace("%-", "%#") if os.name == "nt" else fmt


def _entity(entity_id: str, state: str, **attributes) -> dict:
    return {"entity_id": entity_id, "state": state, "attributes": attributes}


def _light(entity_id, name, on, brightness, rgb):
    return _entity(entity_id, "on" if on else "off", friendly_name=name,
                   brightness=round(brightness * 2.55) if on else None, rgb_color=rgb if on else None,
                   supported_color_modes=["color_temp", "xy"])


def _ticker(entity_id, name, symbol, price, change):
    return _entity(entity_id, str(price), friendly_name=name, symbol=symbol, regularMarketChangePercent=change)


_ALEX = {s["entity_id"]: s for s in [
    _entity("weather.home", "partlycloudy", friendly_name="Home", temperature=72),
    _entity("zone.home", "1", friendly_name="Home", latitude=0.0, longitude=0.0),

    _light("light.living_room", "Living Room", True, 80, [255, 180, 110]),
    _light("light.bedroom", "Bedroom", True, 45, [140, 0, 255]),
    _light("light.desk_lamp", "Desk Lamp", True, 100, [50, 225, 200]),
    _light("light.kitchen", "Kitchen", False, 0, None),
    _light("light.porch", "Porch", True, 60, [255, 210, 150]),
    _light("light.led_strip", "LED Strip", True, 70, [255, 0, 150]),

    _entity("camera.front_door", "streaming", friendly_name="Front Door"),
    _entity("camera.driveway", "streaming", friendly_name="Driveway"),
    _entity("camera.backyard", "streaming", friendly_name="Backyard"),

    *[_entity(f"scene.{key}", "scening", friendly_name=name) for key, name in [
        ("movie_night", "Movie Night"), ("focus", "Focus"), ("relax", "Relax"), ("sunset", "Sunset"),
        ("neon", "Neon"), ("nightlight", "Nightlight"), ("energize", "Energize"), ("galaxy", "Galaxy")]],

    _ticker("sensor.yahoofinance_dji", "Dow Jones", "^DJI", 44210.5, 0.62),
    _ticker("sensor.yahoofinance_ixic", "Nasdaq", "^IXIC", 19874.1, 1.14),
    _ticker("sensor.yahoofinance_spy", "S&P 500", "SPY", 598.2, 0.71),
    _ticker("sensor.yahoofinance_aapl", "Apple", "AAPL", 231.4, -0.42),
    _ticker("sensor.yahoofinance_nvda", "Nvidia", "NVDA", 142.8, 2.35),
    _ticker("sensor.yahoofinance_btc_usd", "Bitcoin", "BTC-USD", 97250.0, 1.8),
    _ticker("sensor.yahoofinance_eth_usd", "Ethereum", "ETH-USD", 3410.0, -1.1),

    *[_entity(f"binary_sensor.{key}", state, friendly_name=name, device_class="connectivity") for key, name, state in [
        ("media_server", "Media Server", "on"), ("nas", "NAS", "on"), ("ad_blocker", "Ad Blocker", "on"),
        ("vpn", "VPN", "on"), ("printer", "3D Printer", "off"), ("router", "Router", "on")]],

    _entity("media_player.living_room_tv", "playing", friendly_name="Living Room TV", device_class="tv", supported_features=24509,
            volume_level=0.32, is_volume_muted=False, app_name="Netflix", media_title="Stranger Things", source="Netflix",
            source_list=["Netflix", "YouTube", "Disney+", "Hulu", "Prime Video", "Spotify", "HDMI 1", "HDMI 2"]),
    _entity("remote.living_room_tv", "on", friendly_name="Living Room TV"),
    _entity("media_player.living_room_speaker", "playing", friendly_name="Living Room Speaker",
            device_class="speaker", media_title="Midnight City", media_artist="M83"),
    _entity("script.party_mode", "off", friendly_name="Party Mode"),
    _entity("assist_satellite.desk", "idle", friendly_name="Desk Assistant"),
    _entity("conversation.assistant", "unknown", friendly_name="Assistant"),
    _entity("sensor.market_movers", "4", top_movers=[
        "Nimbus Robotics (NMBS) up 42% at $18.20", "Quantum Grid (QGRD) up 31% at $7.45",
        "Solara Coin (SLR) up 28% at $0.84", "Harbor Freight Lines (HFL) down 26% at $12.10"],
        checked_at="7:30 PM", stocks_as_of="today"),
]}

_SHOWCASE = {s["entity_id"]: s for s in [
    _entity("weather.home", "sunny", friendly_name="Home", temperature=68),
    _entity("zone.home", "1", friendly_name="Home", latitude=0.0, longitude=0.0),

    _light("light.kitchen_pendants", "Kitchen Pendants", True, 90, [255, 214, 170]),
    _light("light.family_room", "Family Room", True, 65, [255, 190, 130]),
    _light("light.patio_string_lights", "Patio String Lights", True, 50, [255, 170, 60]),
    _light("light.primary_bedroom", "Primary Bedroom", False, 0, None),
    _light("light.kids_room", "Kids' Room", True, 30, [120, 90, 255]),
    _light("light.garage", "Garage", False, 0, None),

    _entity("camera.doorbell", "streaming", friendly_name="Doorbell"),
    _entity("camera.backyard", "streaming", friendly_name="Backyard"),
    _entity("camera.driveway", "streaming", friendly_name="Driveway"),

    *[_entity(f"scene.{key}", "scening", friendly_name=name) for key, name in [
        ("good_morning", "Good Morning"), ("dinner", "Dinner"), ("game_day", "Game Day"),
        ("movie_night", "Movie Night"), ("bedtime", "Bedtime"), ("away", "Away")]],

    _entity("climate.downstairs", "cool", friendly_name="Downstairs", current_temperature=72, temperature=70,
            hvac_action="cooling", hvac_modes=["off", "heat", "cool", "heat_cool"]),
    _entity("climate.upstairs", "heat_cool", friendly_name="Upstairs", current_temperature=69, temperature=68,
            hvac_action="idle", hvac_modes=["off", "heat", "cool", "heat_cool"]),
    _entity("lock.front_door", "locked", friendly_name="Front Door"),
    _entity("lock.back_door", "unlocked", friendly_name="Back Door"),
    _entity("cover.garage_door", "closed", friendly_name="Garage Door", device_class="garage"),
    _entity("cover.living_room_blinds", "open", friendly_name="Living Room Blinds", device_class="blind"),
    _entity("vacuum.robot_vacuum", "docked", friendly_name="Robot Vacuum", battery_level=100),
    _entity("sensor.solar_power", "4.2", friendly_name="Solar", device_class="power", unit_of_measurement="kW"),
    _entity("sensor.home_battery", "86", friendly_name="Home Battery", device_class="battery", unit_of_measurement="%"),
    _entity("sensor.ev_charger_power", "7.2", friendly_name="EV Charger", device_class="power", unit_of_measurement="kW"),
    _entity("sensor.car_battery", "64", friendly_name="Car Battery", device_class="battery", unit_of_measurement="%"),

    _ticker("sensor.yahoofinance_spy", "S&P 500", "SPY", 598.2, 0.71),
    _ticker("sensor.yahoofinance_aapl", "Apple", "AAPL", 231.4, -0.42),

    _entity("media_player.living_room_tv", "playing", friendly_name="Living Room TV", device_class="tv", supported_features=24509,
            volume_level=0.32, is_volume_muted=False, app_name="Netflix", media_title="Stranger Things", source="Netflix",
            source_list=["Netflix", "YouTube", "Disney+", "Hulu", "Prime Video", "Spotify", "HDMI 1", "HDMI 2"]),
    _entity("remote.living_room_tv", "on", friendly_name="Living Room TV"),
    _entity("media_player.kitchen_speaker", "playing", friendly_name="Kitchen Speaker",
            device_class="speaker", media_title="Here Comes the Sun", media_artist="The Beatles"),
    _entity("script.party_mode", "off", friendly_name="Party Mode"),
    _entity("conversation.assistant", "unknown", friendly_name="Assistant"),
]}

HOME = os.environ.get("DECKOS_DEMO_HOME", "alex")
_STATES = _SHOWCASE if HOME == "showcase" else _ALEX


def _person(username, name, relation, through=None, guest=False):
    return {"username": username, "name": name, "relation": relation, "through": through, "guest": guest}


# A made-up family for the Family tab (the showcase home's is bigger)
FAMILY = [
    _person("owner", os.environ.get("DECKOS_DEMO_NAME") or "Sam", "Owner"),
    _person("jess", "Jess", "Wife"),
    _person("mia", "Mia", "Daughter"), _person("leo", "Leo", "Son"),
    _person("linda", "Linda", "Mom"), _person("frank", "Frank", "Dad"),
    _person("mike", "Mike", "Uncle", through="frank"), _person("carol", "Carol", "Aunt", through="linda"),
    _person("rose", "Rose", "Grandma"),
    _person("danny", "Danny", "Brother"), _person("tyler", "Tyler", "Cousin", through="mike"),
    _person("ava", "Ava", "Niece", through="danny"),
    _person("alex_g", "Alex", "Friend", guest=True),
] if HOME == "showcase" else [
    _person("owner", "Alex", "Owner"), _person("sam", "Sam", "Partner"), _person("kim", "Kim", "Sister"),
]


def states() -> dict:
    """The fake home, with markets wiggling a little so it looks alive."""
    snapshot = copy.deepcopy(_STATES)
    for entity_id, s in snapshot.items():
        if entity_id.startswith("sensor.yahoofinance_"):
            s["attributes"]["regularMarketChangePercent"] = round(
                s["attributes"]["regularMarketChangePercent"] + random.uniform(-0.05, 0.05), 2)
    return snapshot


def call(service: str, data: dict) -> None:
    """Pretend to do what Home Assistant would, so buttons visibly work."""
    target = _STATES.get(data.get("entity_id", ""))
    if not target:
        return
    attrs = target["attributes"]
    if service == "light.toggle":
        target["state"] = "off" if target["state"] == "on" else "on"
        if target["state"] == "on":
            attrs["brightness"] = attrs.get("brightness") or 200
            attrs["rgb_color"] = attrs.get("rgb_color") or [255, 200, 140]
    elif service == "light.turn_on":
        target["state"] = "on"
        if "brightness_pct" in data:
            attrs["brightness"] = round(data["brightness_pct"] * 2.55)
        if "rgb_color" in data:
            attrs["rgb_color"] = data["rgb_color"]
        if "color_temp_kelvin" in data:
            k = data["color_temp_kelvin"]  # rough warm->cool white
            attrs["rgb_color"] = [255, int(150 + (k - 2000) / 45), int(80 + (k - 2000) / 26)]
    elif service == "media_player.media_play_pause":
        target["state"] = "paused" if target["state"] == "playing" else "playing"
    elif service in ("media_player.turn_on", "media_player.turn_off"):
        target["state"] = "playing" if service.endswith("on") else "off"
    elif service in ("media_player.volume_up", "media_player.volume_down"):
        attrs["volume_level"] = round(max(0, min(1, (attrs.get("volume_level") or 0.3) + (0.05 if service.endswith("up") else -0.05))), 2)
    elif service == "media_player.volume_set":
        attrs["volume_level"] = data.get("volume_level", attrs.get("volume_level"))
    elif service == "media_player.volume_mute":
        attrs["is_volume_muted"] = data.get("is_volume_muted")
    elif service == "media_player.select_source":
        attrs["source"] = attrs["app_name"] = data.get("source")
        attrs["media_title"] = None
    elif service in ("lock.lock", "lock.unlock"):
        target["state"] = service.split(".")[1] + "ed"
    elif service in ("cover.open_cover", "cover.close_cover"):
        target["state"] = "open" if service == "cover.open_cover" else "closed"
    elif service == "vacuum.start":
        target["state"] = "cleaning"
    elif service == "vacuum.return_to_base":
        target["state"] = "docked"
    elif service == "climate.set_temperature":
        attrs["temperature"] = data["temperature"]


# Canned answers for the assistant chat in demo mode
_ANSWERS = [
    (("server", "up", "online"), "Everything's running except the 3D printer, which is offline."),
    (("market", "stock", "nasdaq", "dow"), "The Nasdaq is up 1.1 percent and the Dow is up 0.6. Nvidia is leading, up 2.4 percent."),
    (("mover", "moving"), "Biggest movers today: Nimbus Robotics up 42 percent, Quantum Grid up 31, and Solara Coin up 28."),
    (("weather", "outside"), "It's 72 degrees and partly cloudy. Nice evening for a walk."),
    (("food", "eat", "hungry", "restaurant"), "Closest options: Slice House pizza at 0.3 miles, Taco Loco at 0.6, "
                                            "and Sakura Sushi at 1.1, which is a bit pricier. What are you in the mood for?"),
    (("light", "movie"), "Done, I've set the living room to movie night."),
]


_SHOWCASE_ANSWERS = [
    (("lock", "door"), "The front door is locked. The back door is unlocked, want me to lock it?"),
    (("garage",), "The garage door is closed."),
    (("thermostat", "temperature", "heat", "cool", "warm", "cold"),
     "Downstairs is 72 and cooling to 70. Upstairs is 69 and holding at 68."),
    (("solar", "energy", "battery", "power"), "Solar is making 4.2 kilowatts, the home battery is at 86 percent, and the car is at 64 percent and charging."),
    (("vacuum", "clean"), "The robot vacuum is docked and fully charged. Say the word and I'll start it."),
    (("weather", "outside"), "It's 68 and sunny. Great day to open the blinds."),
    (("light", "movie"), "Done, I've set the family room to movie night."),
]


def answer(text: str) -> str:
    lowered = text.lower()
    for words, reply in (_SHOWCASE_ANSWERS if HOME == "showcase" else _ANSWERS):
        if any(w in lowered for w in words):
            return reply
    return "This is demo mode, so I'm only pretending, but in a real home I'd take care of that."


DEMO_FOOD = {
    "searched_from": "home",
    "now": datetime.now().strftime(PF("%A %-I:%M %p")),
    "note": "demo data",
    "count": 5,
    "places": [
        {"name": "Slice House", "type": "pizza", "miles": 0.3, "price_guess": "$"},
        {"name": "Taco Loco", "type": "mexican", "miles": 0.6, "price_guess": "$"},
        {"name": "Golden Wok", "type": "chinese", "miles": 0.8, "price_guess": "$$"},
        {"name": "Sakura Sushi", "type": "sushi", "miles": 1.1, "price_guess": "$$$"},
        {"name": "Bean There", "type": "coffee shop", "miles": 0.2, "price_guess": "$"},
    ],
}


def events(now: datetime) -> list[dict]:
    """A believable week on the calendar, always starting from today."""
    plan = [(0, 17, 30, "Soccer practice", "Kids"), (1, 8, 0, "Trash + recycling day", "Home"),
            (2, 19, 0, "Parent-teacher night", "Kids"), (4, 18, 30, "Pizza + movie night", "Family"),
            (5, 10, 0, "HVAC filter swap", "Home")] if HOME == "showcase" else \
           [(0, 20, 0, "Server maintenance", "Home"), (2, 18, 0, "Gym", "Me"), (5, 12, 0, "Farmers market", "Me")]
    out = []
    for days, hour, minute, title, calendar in plan:
        start = (now + timedelta(days=days)).replace(hour=hour, minute=minute, second=0, microsecond=0)
        if start < now:
            start += timedelta(days=7) if days == 0 else timedelta()
        when = "Today" if start.date() == now.date() else "Tomorrow" if start.date() == (now + timedelta(days=1)).date() \
            else start.strftime("%A")
        out.append({"title": title, "start": start.isoformat(), "when": f"{when} {start.strftime(PF('%-I:%M %p'))}",
                    "calendar": calendar})
    return sorted(out, key=lambda e: e["start"])


def money_plan() -> dict:
    """🪜 Money plan for the demo: obviously made-up cards, round numbers. Real installs start empty - the owner adds their own."""
    payday = datetime.now().date() - timedelta(days=(datetime.now().date().toordinal() % 14))
    return {
        "plan_cards": [
            {"id": "demo-visa", "name": "Demo Visa", "balance": 3000, "apr": 24, "fixed": 0, "full": False},
            {"id": "demo-mc", "name": "Demo Mastercard", "balance": 1500, "apr": 20, "fixed": 50, "full": False},
            {"id": "demo-store", "name": "Demo Store Card", "balance": 100, "apr": 0, "fixed": 0, "full": True},
        ],
        "plan_goals": {"pay": 600, "cash": 500, "save": 100, "ef_goal": 1000, "goal_name": "Demo vacation fund",
                       "goal_amount": 5000, "payday": payday.isoformat(), "spend": 500},
        "pay_today": {"bank": 2000},
    }
