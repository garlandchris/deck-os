"""✉️ Mail: your unread mail inside Deck OS, plus a little pop-out when something new lands. Read-only.

Connects with an app password, kept in ~/.config/deck-os.env (never in chat, never in settings):
    MAIL_USER=you@gmail.com
    MAIL_APP_PASSWORD=abcd efgh ijkl mnop      (Gmail: myaccount.google.com/apppasswords)
    MAIL_IMAP_HOST=imap.gmail.com              (optional - worked out from the address for Gmail/Outlook/iCloud/Yahoo)
It reads who a message is from, the subject and the date - it never sends, and never downloads the message itself.
It only changes your mail when you tap: 🗑 moves it to your Trash (Gmail keeps it there 30 days), 🚩 flags it (a star in
Gmail), ✓ marks it read - and you see the same in your mail app.
Several accounts can be connected from the Mail screen (each with its own app password); their unread mail shows together.
"""
import email
import hashlib
import imaplib
import json
import os
import re
from email.header import decode_header, make_header
from email.utils import parseaddr, parsedate_to_datetime

HOSTS = {"gmail.com": "imap.gmail.com", "googlemail.com": "imap.gmail.com", "outlook.com": "outlook.office365.com",
         "hotmail.com": "outlook.office365.com", "live.com": "outlook.office365.com", "msn.com": "outlook.office365.com",
         "icloud.com": "imap.mail.me.com", "me.com": "imap.mail.me.com", "mac.com": "imap.mail.me.com",
         "yahoo.com": "imap.mail.yahoo.com", "aol.com": "imap.aol.com"}
WEB = {"imap.gmail.com": "https://mail.google.com/mail/u/0/#inbox", "outlook.office365.com": "https://outlook.live.com/mail/",
       "imap.mail.me.com": "https://www.icloud.com/mail", "imap.mail.yahoo.com": "https://mail.yahoo.com", "imap.aol.com": "https://mail.aol.com"}


ACCOUNT_FILE = None  # server.py points this at data/mail_account.json (connected from the Mail screen, owner-only, chmod 600)
MAX_ACCOUNTS = 8


def saved_accounts() -> list[dict]:
    """The accounts connected in Deck OS: [{user, password}, ...] (older single-account files still read fine)."""
    try:
        saved = json.loads(ACCOUNT_FILE.read_text()) if ACCOUNT_FILE else {}
    except (OSError, ValueError):
        return []
    found = saved.get("accounts") if isinstance(saved.get("accounts"), list) else [saved]
    return [{"user": a["user"], "password": a["password"]} for a in found if isinstance(a, dict) and a.get("user") and a.get("password")]


def save_accounts(found: list[dict]) -> None:
    if not found:
        ACCOUNT_FILE.unlink(missing_ok=True)
        return
    ACCOUNT_FILE.write_text(json.dumps({"accounts": found[:MAX_ACCOUNTS]}))
    ACCOUNT_FILE.chmod(0o600)


def all_accounts() -> list[tuple[str, str]]:
    """Every mail account: the one in deck-os.env first (if it's there), then the ones connected in Deck OS."""
    found = []
    if os.environ.get("MAIL_USER") and os.environ.get("MAIL_APP_PASSWORD"):
        found.append((os.environ["MAIL_USER"], os.environ["MAIL_APP_PASSWORD"]))
    for a in saved_accounts():
        if a["user"].lower() not in {u.lower() for u, _ in found}:
            found.append((a["user"], a["password"]))
    return found


def credentials() -> tuple[str, str]:
    """The first mail account (or blanks)."""
    return (all_accounts() or [("", "")])[0]


def configured() -> bool:
    return bool(all_accounts())


def tag(user: str) -> str:
    """A short, steady label for an account, so message ids from different inboxes never clash."""
    return hashlib.sha1(user.lower().encode()).hexdigest()[:6]


def host(user: str | None = None) -> str:
    user = user or credentials()[0]
    domain = user.rsplit("@", 1)[-1].lower()
    env_user = os.environ.get("MAIL_USER", "")
    override = os.environ.get("MAIL_IMAP_HOST") if not env_user or env_user.lower() == user.lower() else None
    return override or HOSTS.get(domain, "imap.gmail.com")


def test_login(user: str, password: str) -> None:
    """Raises if these don't sign in (wrong address / app password)."""
    box = imaplib.IMAP4_SSL(host(user), timeout=20)
    try:
        box.login(user, password.replace(" ", ""))
    finally:
        try:
            box.logout()
        except Exception:
            pass


def web_inbox(user: str | None = None) -> str | None:
    user = user or credentials()[0]
    if host(user) == "imap.gmail.com" and user:
        return f"https://mail.google.com/mail/u/{user}/#inbox"  # opens the right Gmail account, not just the first one
    return WEB.get(host(user))


def _text(value) -> str:
    try:
        return " ".join(str(make_header(decode_header(value or ""))).split())
    except Exception:
        return " ".join(str(value or "").split())


def fetch_one(user: str, password: str, limit: int = 20) -> dict:
    """Unread mail in one inbox: how many, and the newest few (from, subject, when, a link to open it)."""
    box = imaplib.IMAP4_SSL(host(user), timeout=20)
    try:
        box.login(user, password.replace(" ", ""))
        box.select("INBOX", readonly=True)  # read-only: nothing gets marked as read
        ids = box.search(None, "UNSEEN")[1][0].split()
        gmail = host(user) == "imap.gmail.com"
        messages = []
        if ids:
            what = "(UID FLAGS " + ("X-GM-THRID " if gmail else "") + "BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])"
            for part in box.fetch(b",".join(ids[-limit:]), what)[1]:
                if not isinstance(part, tuple):
                    continue
                meta, msg = part[0].decode(errors="replace"), email.message_from_bytes(part[1])
                uid, thread = re.search(r"UID (\d+)", meta), re.search(r"X-GM-THRID (\d+)", meta)
                name, addr = parseaddr(_text(msg["From"]))
                try:
                    at = int(parsedate_to_datetime(msg["Date"]).timestamp())
                except Exception:
                    at = 0
                messages.append({"id": f"{tag(user)}:{uid.group(1) if uid else meta.split()[0]}", "from": name or addr, "addr": addr,
                                 "flagged": "\\Flagged" in meta, "account": user,
                                 "subject": _text(msg["Subject"]) or "(no subject)", "at": at,
                                 "link": f"https://mail.google.com/mail/u/{user}/#inbox/{int(thread.group(1)):x}" if thread else web_inbox(user)})
        return {"unread": len(ids), "messages": messages}
    finally:
        try:
            box.logout()
        except Exception:
            pass


def fetch(limit: int = 20) -> dict:
    """Unread mail across every connected inbox, newest first. One account failing doesn't hide the others;
    if they all fail, the first error is raised."""
    total, messages, each, first_error = 0, [], [], None
    for user, password in all_accounts():
        try:
            got = fetch_one(user, password, limit)
        except (imaplib.IMAP4.error, OSError) as error:
            first_error = first_error or error
            text = str(error)
            each.append({"user": user, "unread": 0, "web": web_inbox(user),
                         "error": "Couldn't sign in - check the app password" if "AUTHENTICATIONFAILED" in text.upper() or "LOGIN" in text.upper()
                         else f"Couldn't reach it ({text[:80]})"})
            continue
        total += got["unread"]
        messages += got["messages"]
        each.append({"user": user, "unread": got["unread"], "web": web_inbox(user), "error": None})
    if first_error and not any(not a["error"] for a in each):
        raise first_error
    messages.sort(key=lambda m: m["at"], reverse=True)
    return {"unread": total, "messages": messages[:limit * 2], "accounts": each}


def _trash_folder(box, user: str) -> str:
    """Where 'delete' puts things: the folder your provider marks as Trash (Gmail: [Gmail]/Trash)."""
    for line in box.list()[1] or []:
        text = line.decode(errors="replace") if isinstance(line, bytes) else str(line)
        if "\\Trash" in text:
            name = text.rsplit(' "/" ', 1)[-1].rsplit(' "." ', 1)[-1].strip()
            return name
    return "[Gmail]/Trash" if host(user) == "imap.gmail.com" else "Trash"


def act(ids: list[str], action: str) -> int:
    """🗑 trash / 🚩 flag / unflag / ✓ read - for these messages ("<account tag>:<UID>", or a bare UID for the first
    account) in their inboxes. Returns how many."""
    if action not in ("trash", "flag", "unflag", "read"):
        return 0
    found = all_accounts()
    by_tag = {tag(u): (u, p) for u, p in found}
    groups: dict = {}
    for i in [str(i) for i in ids][:200]:
        t, _, uid = i.rpartition(":")
        account = by_tag.get(t) if t else (found[0] if found else None)
        if account and uid.isdigit() and uid not in groups.get(account, []):
            groups.setdefault(account, []).append(uid)
    return sum(_act_one(user, password, uids, action) for (user, password), uids in groups.items())


def _act_one(user: str, password: str, uids: list[str], action: str) -> int:
    box = imaplib.IMAP4_SSL(host(user), timeout=30)
    try:
        box.login(user, password.replace(" ", ""))
        box.select("INBOX")
        which = ",".join(uids)
        if action == "flag":
            box.uid("STORE", which, "+FLAGS", "(\\Flagged)")
        elif action == "unflag":
            box.uid("STORE", which, "-FLAGS", "(\\Flagged)")
        elif action == "read":
            box.uid("STORE", which, "+FLAGS", "(\\Seen)")
        else:
            trash = _trash_folder(box, user)
            folder = '"' + trash.strip('"') + '"'
            caps = box.capabilities if isinstance(box.capabilities, (tuple, list)) else ()
            if "MOVE" in caps:
                box.uid("MOVE", which, folder)
            else:  # older servers: copy to Trash, then take it out of the inbox
                box.uid("COPY", which, folder)
                box.uid("STORE", which, "+FLAGS", "(\\Deleted)")
                box.expunge()
        return len(uids)
    finally:
        try:
            box.logout()
        except Exception:
            pass
