# Deck OS - what changed

Newest first. Each version is a snapshot of the whole thing at that point - the code keeps
changing underneath, and that's fine: this is the log of what people got.

---

## v0.3.0 - "Everyone's place" (Sept 30 - Oct 1, 2026)

The version where the whole family - every household, every pet, every calendar - fits in one place,
and Deck OS starts gently nudging people toward each other instead of the screen.

### 🌳 Family tree
- **Couples** - married, engaged, dating, partners, divorced, widowed - with an emoji on the line; in-laws work themselves out
- **Arrange it yourself** - hold and drag people around; couples always stay side by side
- **Lines that explain themselves** - who's related to who, labelled, plus dashed "what they are to you" lines (Uncle → you)
  and lines it can work out on its own (Mom's brother gets a line to Grandma)
- **People who aren't on Deck OS yet** - dashed cards with an invite link that claims their spot; drag to 🕊 In memory
- **Related how?** - "Aunt · Mom's sister" on every profile, and fix a wrong relationship in two taps
- **🏷 Known nicknames** - Nana, Big J… anyone in the family can add one

### 🐾 Pets for every household
- Pets belong to people ("Mom & Dad's cat") and hang off their owners in the tree
- Family in other houses add their own pets with their own jobs - their reminders buzz their house, not yours

### 📅 Calendars
- **Month view in Schedule** - every calendar, add / edit / delete, "Did it make it?" check for what Deck OS added
- **Tap a calendar to recolor it** - and see whether it's linked
- **🍎 Connect iCloud** - 4 numbered steps in the app; then edit, move and delete iCloud events (colors match your iPhone)
- **Brain dump files to the right calendar** - "add laundry to the home calendar", "Sam has soccer at 6" → Soccer - Sam on Family;
  switch a calendar or ✏️ fix anything before adding
- **＋ Calendar** - make a new calendar (in Deck OS, or in iCloud), delete Deck OS ones, and link **Google, Outlook,
  Samsung (through Google) or any calendar link** - each with the steps on screen

### 💛 Toward each other
- **Family check-ins** - a little yellow card when someone's having a rough day, you haven't talked, or nobody's planned anything
- **Weekend mode** - Saturday and Sunday Home leads with weather, meals, food nearby, plans and challenges
- **Nudges with a note** that float onto their screen; **📢 SHOUT** for "dinner's ready" moments
- **📰 Newsroom** on Home - family statuses, joins, photos, birthdays and challenges, rotating

### 👤 Profiles & people
- **Likes & dislikes** on their own screen (❤️ love, 😡 hate, 🩺 allergic) - a short summary on profiles you can fold away
- **🥗 Diet + 🔥 calories** - recipes and food nearby respect allergies and diets
- **👥 Everyone page** with wish lists, secret dibs, ⭐ favorites and a 🎁 gift checker

### 💬 Chats
- Reply under a message, react with **any emoji (animated)**, color a single bubble, tap a photo to see their profile

### 🏠 Home & house
- **🏠 Inventory** - what's running low, add to lists, things you own
- **🧠 Brain dump** - always there; results stack into a "To file" list you can pop out
- **A layout per device** - phone, tablet and PC can each look different
- **Themes** - White and Paper light modes plus Rose, Gold, Crimson, Midnight, Mono; pick your home-screen icon color
- **🎨 Creativity studio** - draw, boards, flowcharts, writing help, scan a paper drawing
- **💰 Money** - goals, subscriptions, budgets (share one with someone), family pots
- **Markets** - make your own stock scanners in plain words
- **🔔 Notifications** - choose what buzzes you, how loud, and quiet hours
- **🌐 Fewer apps on your phone** - Get apps only asks you to download what truly needs an app; YouTube, Netflix, Spotify,
  DoorDash, Amazon and friends are one tap to add as web links (and a 💡 suggestion shows now and then)

### ⬆️ Updates & your data
- **One-tap updates** - System shows "New version ready" → What's new → Update now; it checks the download is genuine,
  restarts itself, and "Undo last update" puts the old one back
- **Deck OS's home** - everything your family makes lives in one `data` folder, outside the app, so updates never touch it;
  System shows where it is, how big it is and how much room is left (with a heads-up before it runs low)
- Real requirements in the guides: storage, memory, an always-on PC

### 🛠 Fixes
- A brand-new install no longer trips over the Apps setup checklist
- A Home Assistant without a home location set explains how to fix it instead of failing
- Every action checked with bad input: Home Assistant hiccups answer politely instead of failing, and an empty stock search
  can no longer remove your first stock
- iPhone no longer zooms into text boxes; Home fits the phone width

---

## v0.2.0 - "The family update" (Sept 29-30, 2026)

The version where Deck OS turned from a home screen into the family's place.

### 💬 Talking to each other
- **Family Chat** with reactions, polls, a daily question, photos, and who-sent-it labels (Mom, Brother…)
- **Private & group chats** - every two people in the house already have one; make groups for anything
- **Chats page** (More → Chats) and a chat strip on Home - swipe between chats
- **Message button** on everyone's profile
- **Bubble colors** - pick yours and everyone else's, per chat, only on your screen
- **Notifications** on the lock screen (Deck OS's own, or through the Home Assistant app)
- **Presence** - 🟢 online / 🟡 away / 🔴 do not disturb / 🌙 asleep / ⚫ offline (the last three hold buzzes)
- **Statuses** - any emoji + your own words; set it from Home

### 🌳 The family web
- **Invite family** - anyone can invite their relatives (the other side of the family too)
- **Relationships work themselves out** - Mom's mom is your Grandma, her son is your Uncle
- **Relatives** get their own space: chats, the tree, memories, notes, lists, meal plan, chores
  and food nearby - never the house's lights, cameras, locks or location
- **The family door** - a family web address (e.g. https://family.yourdomain.com) works from anywhere (Cloudflare tunnel)
- **Whole family** group chat that keeps itself up to date
- **Welcome gifts** on invites (coins + badges) and the 😎 OG badge
- **Contact cards** - phone, email, address; Call / Text / Directions / Save to contacts

### 🕊 In memory
- A page for the people and pets we miss - photos (of you with them), stories, "how they still
  shape me", a daily candle. In the family tree, and a 🌈 Rainbow bridge row. No points, ever.

### 🏠 Home & the house
- **Customize Home** - press and hold; hide, move, add cards and ⭐ shortcuts
- **Make your own cards** - sticky notes, countdowns, your own photo
- **Photo of the day** - your own each day; shuffle, 📌 keep, or minimize
- **🧠 Brain dump** - type what's in your head, get an animated vibe (Claude picks it)
- **Family updates, pets (with jobs + reminders), chores (coins, thanks, milestones), meal plan →
  groceries, photo wall filed by year, family challenges**
- **Announce** to the house speakers + shared timers
- **Network check** + Wi-Fi QR for guests
- **Market movers** - tap one: what it is, why it's moving, where it trades (info, not advice)

### 🧭 Getting around
- **Bottom bar** - any 7 things, pages *or apps* (YouTube on the bar!) - hold it to change
- **Swipe** left/right between your bottom-bar pages
- **Top bar** - a looping strip of widgets you pick with ✏: music, clock, weather, messages,
  timers, lights, servers, stocks, dinner, vibe, level, date
- **🎵 Music** - album cover with bouncing bars + play/pause; tap it to open Spotify
- **🔮 Floating Elara** - drag the orb anywhere; tap to talk; messages pop out of it
- **Elara knows you** - your likes, family, pets and things you asked it to remember
- **Pull down to refresh** anywhere (in More it opens search)
- **Apps** - tap the open tab again to close it and your pinned apps go big; Gmail + Outlook

### ⭐ Fun (the small-dopamine kind)
- XP + levels with a color-changing shield, badges, loadout (title, banner, photo ring),
  status styles, a coin shop, funny greetings, little celebrations when you finish something
- XP just for having Deck OS open tapers off after the first weeks - the goal is to help, not to hook

### 🛠 Fixes & polish
- iPhone: no more zooming in when you tap a box; the screen snaps back after visiting another app;
  Home never wider than the phone; big ✕ buttons; typing on Home isn't interrupted
- Setup wizard for new homes, a getting-started tour, and a lived-in demo
- Safety: relatives and the family door only ever reach an allowlist; the house's own
  chat can't be written from a relative's household; private chats are private (even from the admin)

---

## v0.1.0 - First release (Sept 28, 2026)
- Home screen over Home Assistant: lights, devices, cameras, weather, calendar, servers, markets
- Elara (voice + typed), Watch (movies), Traffic, Food, Lists, Schedule, Clips, Browser, Apps
- Family accounts (admin / adult / kid / guest), bedtime for kids, Deck OS Pro, Windows download
