"""📷 Scan worker: turns a folder of photos of one object into a 3D model. Deck OS runs this in the background (one scan
at a time, at low priority) with the scan engine's own Python - it is NOT imported by server.py, so its heavy libraries
(pycolmap, numpy, trimesh) never load into Deck OS itself.

    <engine python> scan_worker.py --job <job folder> --engine colmap-openmvs --quality normal --threads 3

The job folder has photos/ (JPEGs). The worker writes progress.json as it goes ({stage, pct, note}) and, when it
finishes, out/model.stl (+ out/model.obj) and out/info.json. Exit code 0 = made a model.

Engine "colmap-openmvs" (all CPU, free): pycolmap finds where each photo was taken (SfM) -> OpenMVS builds the dense
surface (DensifyPointCloud -> ReconstructMesh) -> trimesh cuts away the table and loose bits and saves an .stl.
A new/faster engine is just another function in ENGINES (or its own program in a manifest) that fills the same out/.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

QUALITY = {  # photo size (px) for finding cameras, OpenMVS --resolution-level (higher = smaller = faster)
    "quick": {"px": 1200, "level": 2, "faces": 150_000},
    "normal": {"px": 1600, "level": 1, "faces": 300_000},
    "fine": {"px": 2400, "level": 1, "faces": 600_000},
}


class Job:
    def __init__(self, folder: Path):
        self.dir = folder
        self.out = folder / "out"
        self.work = folder / "work"
        self.started = time.time()

    def say(self, stage: str, pct: int, note: str = "") -> None:
        tmp = self.dir / ".progress.json"
        tmp.write_text(json.dumps({"stage": stage, "pct": pct, "note": note, "at": int(time.time()),
                                   "secs": int(time.time() - self.started)}))
        os.replace(tmp, self.dir / "progress.json")
        print(f"[{pct:3d}%] {stage} {note}", flush=True)


def run(cmd: list, job: Job, log: str) -> None:
    with open(job.work / f"{log}.log", "w") as f:
        r = subprocess.run([str(c) for c in cmd], cwd=job.work, stdout=f, stderr=subprocess.STDOUT)
    if r.returncode:
        tail = (job.work / f"{log}.log").read_text(errors="replace")[-600:]
        raise RuntimeError(f"{Path(str(cmd[0])).name} stopped ({r.returncode}): {tail}")


def shrink_photos(job: Job, px: int) -> Path:
    """Copies the photos at most px on the long side (big phone photos only slow it down, they don't help much)."""
    from PIL import Image, ImageOps
    src, dst = job.dir / "photos", job.work / "images"
    dst.mkdir(parents=True, exist_ok=True)
    names = sorted(p for p in src.iterdir() if p.suffix.lower() in (".jpg", ".jpeg", ".png"))
    for i, p in enumerate(names):
        im = ImageOps.exif_transpose(Image.open(p)).convert("RGB")
        im.thumbnail((px, px))
        im.save(dst / f"{i:04d}.jpg", quality=92)
    if len(names) < 8:
        raise RuntimeError(f"Only {len(names)} photos - it needs at least 8 (30-50 is best)")
    return dst


def find_cameras(job: Job, images: Path, threads: int, px: int) -> Path:
    import pycolmap
    db, sparse = job.work / "database.db", job.work / "sparse"
    db.unlink(missing_ok=True)
    sparse.mkdir(exist_ok=True)
    ext = pycolmap.FeatureExtractionOptions()
    ext.max_image_size, ext.num_threads = px, threads
    job.say("Finding details in the photos", 10)
    pycolmap.extract_features(db, images, camera_mode=pycolmap.CameraMode.SINGLE, extraction_options=ext, device=pycolmap.Device.cpu)
    job.say("Matching the photos to each other", 20)
    n = len(list(images.iterdir()))
    if n <= 80:
        pycolmap.match_exhaustive(db, device=pycolmap.Device.cpu)
    else:  # (a walk-around in order: each photo vs its neighbours is much faster for lots of photos)
        pycolmap.match_sequential(db, device=pycolmap.Device.cpu)
    job.say("Working out where each photo was taken", 30)
    recs = pycolmap.incremental_mapping(db, images, sparse)
    if not recs:
        raise RuntimeError("Couldn't line the photos up - try more photos with more overlap, and something patterned under it")
    best = max(recs, key=lambda k: recs[k].num_reg_images())
    rec = recs[best]
    if rec.num_reg_images() < max(6, n // 3):
        raise RuntimeError(f"Only {rec.num_reg_images()} of {n} photos lined up - go slower with more overlap")
    job.say("Straightening the photos", 40, f"{rec.num_reg_images()} of {n} photos placed")
    dense = job.work / "dense"
    shutil.rmtree(dense, ignore_errors=True)
    pycolmap.undistort_images(dense, sparse / str(best), images)
    centre, radius = object_sphere(rec)
    (job.work / "sphere.json").write_text(json.dumps({"centre": centre, "radius": radius}))
    return dense


def object_sphere(rec) -> tuple[list, float]:
    """Where the object is: the spot every camera was pointing at (least squares on their view lines), and a radius
    a bit under the cameras' distance - everything outside it is room, not object."""
    import numpy as np
    origins, dirs = [], []
    for img in rec.images.values():
        if not img.has_pose:
            continue
        pose = img.cam_from_world()
        R = pose.rotation.matrix()
        origins.append(-R.T @ pose.translation)
        dirs.append(R.T @ np.array([0, 0, 1.0]))
    A, b = np.zeros((3, 3)), np.zeros(3)
    for o, d in zip(origins, dirs):
        d = d / np.linalg.norm(d)
        P = np.eye(3) - np.outer(d, d)
        A += P
        b += P @ o
    c = np.linalg.lstsq(A, b, rcond=None)[0]
    dist = float(np.median([np.linalg.norm(o - c) for o in origins]))
    return c.tolist(), dist * 0.6


def openmvs(job: Job, dense: Path, quality: dict, threads: int, bins: Path) -> Path:
    t = ["--max-threads", threads]
    job.say("Loading into OpenMVS", 45)
    run([bins / "InterfaceCOLMAP", "-i", dense, "-o", "scene.mvs", "--image-folder", dense / "images"] + t, job, "1-interface")
    job.say("Building the dense surface (the slow part)", 50)
    run([bins / "DensifyPointCloud", "scene.mvs", "--resolution-level", quality["level"], "--number-views", 5] + t, job, "2-densify")
    job.say("Making the mesh", 85)
    run([bins / "ReconstructMesh", "scene_dense.mvs", "-p", "scene_dense.ply"] + t, job, "3-mesh")
    for name in ("scene_dense_mesh.ply", "scene_mesh.ply"):
        if (job.work / name).exists():
            return job.work / name
    raise RuntimeError("OpenMVS didn't make a mesh")


def clean_up(job: Job, mesh_file: Path, quality: dict) -> dict:
    """Keeps the object: cuts away what's outside the object's sphere and the flat table under it, keeps the biggest
    piece, lays it on its base and saves .stl + .obj. The size is in 'scan units' - measure a real edge and resize."""
    import numpy as np
    import trimesh
    job.say("Cutting away the table and loose bits", 92)
    m = trimesh.load(mesh_file, force="mesh", process=False)
    s = json.loads((job.work / "sphere.json").read_text())
    c, r = np.array(s["centre"]), s["radius"]
    keep = np.linalg.norm(m.triangles_center - c, axis=1) < r
    m.update_faces(keep)
    m.remove_unreferenced_vertices()
    plane = table_plane(m.vertices, c)
    if plane is not None:
        n, d = plane
        m.update_faces((m.triangles_center @ n + d) > r * 0.01)  # (a hair above the table)
        m.remove_unreferenced_vertices()
    parts = m.split(only_watertight=False)
    if len(parts):
        m = max(parts, key=lambda p: len(p.faces))
    if len(m.faces) < 200:
        raise RuntimeError("The model came out almost empty - try brighter light and a patterned cloth under it")
    if len(m.faces) > quality["faces"]:
        try:
            m = m.simplify_quadric_decimation(face_count=quality["faces"])
        except Exception as e:  # (needs fast_simplification; a big file is fine too)
            print("simplify skipped:", e, flush=True)
    if plane is not None:  # stand it up the way it sat on the table, base at z=0
        m.apply_transform(trimesh.geometry.align_vectors(plane[0], [0, 0, 1]))
    m.apply_translation([-m.bounds[0][0], -m.bounds[0][1], -m.bounds[0][2]])
    scale = 100.0 / max(m.extents)  # (scan units are arbitrary - start at 100 mm across; fix it with 📏 Measure)
    m.apply_scale(scale)
    job.out.mkdir(exist_ok=True)
    m.export(job.out / "model.stl")
    m.export(job.out / "model.obj")
    return {"faces": len(m.faces), "watertight": bool(m.is_watertight), "size_mm": [round(x, 1) for x in m.extents]}


def table_plane(v, centre):
    """The biggest flat surface near the bottom of the object (RANSAC) - the table. Returns (normal pointing up at the
    object, d) or None."""
    import numpy as np
    if len(v) < 500:
        return None
    rng = np.random.default_rng(1)
    tol = np.ptp(v, axis=0).max() * 0.01
    best, best_n = None, 0
    for _ in range(300):
        p = v[rng.choice(len(v), 3, replace=False)]
        n = np.cross(p[1] - p[0], p[2] - p[0])
        if np.linalg.norm(n) < 1e-12:
            continue
        n = n / np.linalg.norm(n)
        d = -n @ p[0]
        count = int((np.abs(v @ n + d) < tol).sum())
        if count > best_n:
            best, best_n = (n, d), count
    if best is None or best_n < len(v) * 0.15:  # (no big flat patch - maybe the table was already cut away)
        return None
    n, d = best
    if centre @ n + d < 0:
        n, d = -n, -d
    return n, d


def colmap_openmvs(job: Job, args) -> dict:
    q = QUALITY.get(args.quality, QUALITY["normal"])
    bins = Path(os.environ.get("DECKOS_OPENMVS") or Path.home() / ".local/share/deckos-scan/openmvs")
    job.work.mkdir(exist_ok=True)
    job.say("Getting the photos ready", 3)
    images = shrink_photos(job, q["px"])
    dense = find_cameras(job, images, args.threads, q["px"])
    mesh = openmvs(job, dense, q, args.threads, bins)
    return clean_up(job, mesh, q)


ENGINES = {"colmap-openmvs": colmap_openmvs}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--job", required=True)
    ap.add_argument("--engine", default="colmap-openmvs")
    ap.add_argument("--quality", default="normal")
    ap.add_argument("--threads", type=int, default=max(1, (os.cpu_count() or 2) - 1))
    ap.add_argument("--keep-work", action="store_true")
    args = ap.parse_args()
    job = Job(Path(args.job))
    try:
        info = ENGINES[args.engine](job, args)
    except Exception as e:
        job.say("Didn't work", 100, str(e)[:500])
        print("FAILED:", repr(e), flush=True)
        return 1
    info |= {"engine": args.engine, "quality": args.quality, "secs": int(time.time() - job.started)}
    (job.out / "info.json").write_text(json.dumps(info))
    if not args.keep_work:
        shutil.rmtree(job.work, ignore_errors=True)  # (the in-between files are big - gigabytes for a fine scan)
    job.say("Done", 100)
    return 0


if __name__ == "__main__":
    sys.exit(main())
